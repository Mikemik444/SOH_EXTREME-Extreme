#pragma once

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void CrashHandler_PrintSohData(char* buffer, size_t* pos);

#ifdef __cplusplus
}
#endif
