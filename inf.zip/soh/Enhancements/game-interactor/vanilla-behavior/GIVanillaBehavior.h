#pragma once

typedef enum {
    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnKz`
    VB_ADULT_KING_ZORA_ITEM_GIVE,

    // #### `result`
    // ```c
    // requiredAge == 2
    // ```
    // #### `args`
    // - `int32_t` (entrance index) (promoted from `uint16_t` by va_arg)
    VB_ALLOW_ENTRANCE_CS_FOR_EITHER_AGE,

    // #### `result`
    // ```c
    // sPuzzleState == 0xF
    // ```
    // #### `args`
    // - None
    VB_AMY_SOLVE,

    // #### `result`
    // ```c
    // this->actor.textId == 0x401A
    // ```
    // #### `args`
    // - `*EnKz`
    VB_BE_ABLE_TO_EXCHANGE_RUTOS_LETTER,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_BE_ABLE_TO_OPEN_DOORS,

    // #### `result`
    // ```c
    // (Flags_GetEventChkInf(EVENTCHKINF_USED_DODONGOS_CAVERN_BLUE_WARP)) || BREG(2)
    // ```
    // #### `args`
    // - None
    VB_BE_ABLE_TO_PLAY_BOMBCHU_BOWLING,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_BE_ABLE_TO_SAVE,

    // #### `result`
    // ```c
    // this->currentReward == 3
    // ```
    // #### `args`
    // - `*EnTk`
    VB_BE_DAMPE_GRAVEDIGGING_GRAND_PRIZE,

    // #### `result`
    // ```c
    // (this->getItemId == GI_QUIVER_40) || (this->getItemId == GI_QUIVER_50)
    // ```
    // #### `args`
    // - `*EnSyatekiMan`
    VB_BE_ELIGIBLE_FOR_ADULT_SHOOTING_GAME_REWARD,

    // #### `result`
    // ```c
    // CUR_CAPACITY(UPG_BOMB_BAG) >= 20
    // ```
    // #### `args`
    // - `*EnGo2`
    VB_BE_ELIGIBLE_FOR_CHILD_ROLLING_GORON_REWARD,

    // #### `result`
    // ```c
    // CUR_UPG_VALUE(UPG_STRENGTH) <= 0
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_DARUNIAS_JOY_REWARD,

    // #### `result`
    // ```c
    // !CHECK_OWNED_EQUIP_ALT(EQUIP_TYPE_SWORD, EQUIP_INV_SWORD_BIGGORON)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_GIANTS_KNIFE_PURCHASE,

    // #### `result`
    // See `isEligible` logic in
    // ```c
    // BgDyYoseizo_CheckMagicAcquired()
    // ```
    // #### `args`
    // - `*BgDyYoseizo`
    VB_BE_ELIGIBLE_FOR_GREAT_FAIRY_REWARD,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_SPIRIT) &&
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_SHADOW) &&
    // LINK_IS_ADULT &&
    // !Flags_GetEventChkInf(EVENTCHKINF_RETURNED_TO_TEMPLE_OF_TIME_WITH_ALL_MEDALLIONS) &&
    // (gEntranceTable[((void)0, gSaveContext.entranceIndex)].scene == SCENE_TEMPLE_OF_TIME)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_LIGHT_ARROWS,

    // #### `result`
    // ```c
    // gSaveContext.rupees >= sPrices[BEANS_BOUGHT]
    // ```
    // #### `args`
    // - `*EnMs`
    VB_BE_ELIGIBLE_FOR_MAGIC_BEANS_PURCHASE,

    // #### `result`
    // ```c
    // (gSaveContext.entranceIndex == ENTR_KAKARIKO_VILLAGE_FRONT_GATE) &&
    // LINK_IS_ADULT &&
    // Flags_GetEventChkInf(EVENTCHKINF_USED_FOREST_TEMPLE_BLUE_WARP) &&
    // Flags_GetEventChkInf(EVENTCHKINF_USED_FIRE_TEMPLE_BLUE_WARP) &&
    // Flags_GetEventChkInf(EVENTCHKINF_USED_WATER_TEMPLE_BLUE_WARP) &&
    // !Flags_GetEventChkInf(EVENTCHKINF_BONGO_BONGO_ESCAPED_FROM_WELL)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_NOCTURNE_OF_SHADOW,

    // #### `result`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_LEARNED_PRELUDE_OF_LIGHT) &&
    // Flags_GetEventChkInf(EVENTCHKINF_USED_FOREST_TEMPLE_BLUE_WARP)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_PRELUDE_OF_LIGHT,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_SPIRIT) &&
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_SHADOW) &&
    // (INV_CONTENT(ITEM_ARROW_LIGHT) == ITEM_ARROW_LIGHT) &&
    // CheckPlayerPosition(player, play)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_RAINBOW_BRIDGE,

    // #### `result`
    // ```c
    // !CHECK_QUEST_ITEM(QUEST_SONG_SARIA)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_SARIAS_SONG,

    // #### `result`
    // ```c
    // CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, EQUIP_INV_BOOTS_IRON) &&
    // !Flags_GetEventChkInf(EVENTCHKINF_LEARNED_SERENADE_OF_WATER)
    // ```
    // #### `args`
    // - None
    VB_BE_ELIGIBLE_FOR_SERENADE_OF_WATER,

    // #### `result`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_OPENED_THE_DOOR_OF_TIME)
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_BE_ELIGIBLE_TO_OPEN_DOT,

    // #### `result`
    // ```c
    // this->validDigHere == 1
    // ```
    // #### `args`
    // - `*EnTk`
    VB_BE_VALID_GRAVEDIGGING_SPOT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - 'EnHy*'
    VB_BEGGAR_GIVE_ITEM,

    // #### `result`
    // ```c
    // this->collider.base.acFlags & 2 || blueFireArrowHit
    // ```
    // #### `args`
    // - `*BgBreakwall`
    VB_BG_BREAKWALL_BREAK,

    // #### `result`
    // ```c
    // this->cylinder1.base.acFlags & AC_HIT
    // ```
    // #### `args`
    // - `*BgIceShelter`
    VB_BG_ICE_SHELTER_HIT,

    // #### `result`
    // ```c
    // (this->cylinder1.base.ac != NULL) && (this->cylinder1.base.ac->id == ACTOR_EN_ICE_HONO)
    // ```
    // #### `args`
    // - `*BgIceShelter`
    VB_BG_ICE_SHELTER_MELT,

    // #### `result`
    // ```c
    // this->timer > 0 && this->timer <= 100
    // ```
    // #### `args`
    // - `*BgSpot06Objects`
    VB_BG_SPOT06_OBJECTS_GATE_SKIP,

    // #### `result`
    // ```c
    // gSaveContext.bgsFlag
    // ```
    // #### `args`
    // - None
    VB_BIGGORON_CONSIDER_SWORD_COLLECTED,

    // #### `result`
    // ```c
    // Environment_GetBgsDayCount() >= 3
    // ```
    // #### `args`
    // - None
    VB_BIGGORON_CONSIDER_SWORD_FORGED,

    // #### `result`
    // ```c
    // gSaveContext.bgsFlag
    // ```
    // #### `args`
    // - None
    VB_BIGGORON_CONSIDER_TRADE_COMPLETE,

    // #### `result`
    // Actor is ACTOR_EN_ELF, ACTOR_EN_FISH, ACTOR_EN_ICE_HONO, or ACTOR_EN_INSECT
    // ```c
    // i < ARRAY_COUNT(sBottleCatchInfo)
    // ```
    // #### `args`
    // - `*Actor` (interactRangeActor)
    VB_BOTTLE_ACTOR,

    // #### `result`
    // Actor is ACTOR_OBJ_BOMBIWA, or ACTOR_OBJ_HAMISHI
    // ```c
    // Flags_GetSwitch(play, this->actor.params & 0x3F)
    // ```
    // #### `args`
    // - `*Actor` (interactRangeActor)
    VB_BOULDER_BREAK_FLAG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnPoField`
    VB_BOTTLE_BIG_POE,

    // #### `result`
    // ```c
    // this->currentShield == PLAYER_SHIELD_DEKU
    // ```
    // #### `args`
    // - `*Player`
    VB_BURN_SHIELD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjWood02`
    VB_BUSH_DROP_ITEM,

    // #### `result`
    // ```c
    // ((this->actor.params == DNS_TYPE_HEART_PIECE) && (Flags_GetItemGetInf(ITEMGETINF_DEKU_SCRUB_HEART_PIECE))) ||
    // ((this->actor.params == DNS_TYPE_DEKU_STICK_UPGRADE) && (Flags_GetInfTable(INFTABLE_BOUGHT_STICK_UPGRADE))) ||
    // ((this->actor.params == DNS_TYPE_DEKU_NUT_UPGRADE) && (Flags_GetInfTable(INFTABLE_BOUGHT_NUT_UPGRADE)))
    // ```
    // #### `args`
    // - `*EnShopnuts`
    VB_BUSINESS_SCRUB_DESPAWN,

    // #### `result`
    // ```c
    // this->actor.xzDistToPlayer < 130.0f
    // ```
    // #### `args`
    // - None
    VB_BUSINESS_SCRUB_SPEAK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnHeishi2`
    VB_CAN_BRIBE_HEISHI2,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (item)
    VB_CHANGE_HELD_ITEM_AND_USE_ITEM,

    // #### `result`
    // ```c
    // gSaveContext.rupees < 200
    // ```
    // #### `args`
    // - `*EnJs`
    VB_CHECK_RANDO_PRICE_OF_CARPET_SALESMAN,

    // #### `result`
    // ```c
    // gSaveContext.rupees < 200
    // ```
    // #### `args`
    // - `*EnGm`
    VB_CHECK_RANDO_PRICE_OF_MEDIGORON,

    // #### `result`
    // ```c
    // INV_CONTENT(ITEM_TRADE_CHILD) == ITEM_SOLD_OUT
    // ```
    // #### `args`
    // - `*EnOssan` (Happy Mask Shopkeeper)
    VB_HAPPY_MASK_SHOP_CHECK_SOLD_OUT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CLIMB,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_AFTER_PROCESS_SCENE_COLLISION,

    // #### `result`
    // ```c
    // CHECK_BTN_ALL(input->press.button, BTN_START)
    // ```
    // #### `args`
    // - None
    VB_CLOSE_PAUSE_MENU,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnHorse`
    VB_CONSUME_EPONA_BOOST,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDoor`
    VB_CONSUME_SMALL_KEY,

    // #### `result`
    // ```c
    // itemDropped >= 0 && itemDropped < 0x1A
    // ```
    // #### `args`
    // - `*ObjKibako2`
    VB_CRATE_DROP_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjKibako2`
    VB_CRATE_SETUP_DRAW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CRAWL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CRAWL_SPEED_ENTER,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CRAWL_SPEED_EXIT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Camera`
    // - 'int16_t' (csId)
    // - 'int16_t' (actionParameters)
    // - 'int16_t' (initTimer)
    // - 'CutsceneCameraPoint*' (atPoints)
    // - 'CutsceneCameraPoint*' (eyePoints)
    VB_CRAWL_SPEED_EXIT_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CRAWL_SPEED_INCREASE,

    // #### `result`
    // ```c
    // this->hookshotSlotFull
    // ```
    // #### `args`
    // - None
    VB_DAMPE_AWARD_SECOND_PRIZE,

    // #### `result`
    // ```c
    // this->actionTimer == 0 && Rand_ZeroOne() < 0.03f
    // ```
    // #### `args`
    // - `*EnPoRelay`
    VB_DAMPE_DROP_FLAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*f32` (speed
    VB_DAMPE_GO_BACKWARDS,

    // #### `result`
    // ```c
    // !Flags_GetItemGetInf(ITEMGETINF_1C)
    // ```
    // #### `args`
    // - `*EnTk`
    VB_DAMPE_GRAVEDIGGING_GRAND_PRIZE_BE_HEART_PIECE,

    // #### `result`
    // ```c
    // gSaveContext.dayTime <= 0xC000 || gSaveContext.dayTime >= 0xE000 || LINK_IS_ADULT || play->sceneNum !=
    // SCENE_GRAVEYARD
    // ```
    // #### `args`
    // - `*EnTk`
    VB_DAMPE_IN_GRAVEYARD_DESPAWN,

    // #### `result`
    // ```c
    // !Flags_GetItemGetInf(ITEMGETINF_OBTAINED_NUT_UPGRADE_FROM_STAGE) && (Player_GetMask(play) != PLAYER_MASK_SKULL)
    // ```
    // #### `args`
    // - None
    VB_DEKU_SCRUBS_REACT_TO_MASK_OF_TRUTH,

    // #### `result`
    // ```c
    // (Message_GetState(&play->msgCtx) == TEXT_STATE_DONE) && Message_ShouldAdvance(play)
    // ```
    // #### `args`
    // - None
    VB_DEKU_THEATER_FINISH_GIVING_PRIZE,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_FOREST)
    // ```
    // #### `args`
    // - `*ObjDekujr`
    VB_DEKU_JR_CONSIDER_FOREST_TEMPLE_FINISHED,

    // #### `result`
    // ```c
    // this->unk_860 != 0
    // ```
    // #### `args`
    // - None
    VB_DEKU_STICK_BE_ON_FIRE,

    // #### `result`
    // ```c
    // AMMO(ITEM_STICK) != 0
    // ```
    // #### `args`
    // - None
    VB_DEKU_STICK_BREAK,

    // #### `result`
    // ```c
    // this->unk_860 < 20
    // ```
    // #### `args`
    // - None
    VB_DEKU_STICK_BURN_DOWN,

    // #### `result`
    // ##### In `Player_UpdateBurningDekuStick`
    // ```c
    // this->unk_85C == 0.0f
    // ```
    // ##### Also in `Player_UpdateBurningDekuStick`
    // ```c
    // DECR(this->unk_860) == 0;
    // ```
    // #### `args`
    // - None
    VB_DEKU_STICK_BURN_OUT,

    // #### `result`
    // ```c
    // Flags_GetItemGetInf(ITEMGETINF_30)
    // ```
    // #### `args`
    // - `*EnHs`
    VB_DESPAWN_GROG,

    // #### `result`
    // ```c
    // play->sceneNum == SCENE_LINKS_HOUSE && (!LINK_IS_ADULT ||
    // !Flags_GetEventChkInf(EVENTCHKINF_WON_COW_IN_MALONS_RACE)
    // ```
    // #### `args`
    // - `*EnCow`
    VB_DESPAWN_HORSE_RACE_COW,

    // #### `result`
    // ```c
    // (actorCategory == ACTORCAT_ENEMY) && CHECK_FLAG_ALL(actor->flags, ACTOR_FLAG_ATTENTION_ENABLED |
    // ACTOR_FLAG_HOSTILE) && (actor->xyzDistToPlayerSq < SQ(500.0f)) && (actor->xyzDistToPlayerSq < sbgmEnemyDistSq)
    // ```
    // #### `args`
    // - `*Actor`
    // - `*f32` (sbgmEnemyDistSq)
    // - `int32_t` (actorCategory)
    VB_DETECT_BGM_ENEMY,

    // #### `result`
    // ```c
    // !Flags_GetSwitch(play, this->actor.params & 0x3F)
    // ```
    // #### `args`
    // - `*EnDoor`
    VB_DOOR_BE_LOCKED,

    // #### `result`
    // ```c
    // ((doorActor->params >> 7) & 7) == 3
    // ```
    // #### `args`
    // - `*Actor`
    VB_DOOR_PLAY_SCENE_TRANSITION,
    // Vanilla condition: true
    VB_HATCH_CUCCO_OR_CHICKEN,
    // Vanilla condition: exchangeItemId == EXCH_ITEM_LETTER_ZELDA
    // Opt: s32
    VB_HEISHI2_ACCEPT_ITEM_AS_ZELDAS_LETTER,

    // #### `result`
    // ```c
    // (this->heldItemAction == PLAYER_IA_HOOKSHOT) ||
    // (this->heldItemAction == PLAYER_IA_LONGSHOT)
    // ```
    // #### `args`
    // - '*Player'
    VB_DRAW_ADDITIONAL_RETICLES,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `PlayerMask currentMask`
    // - `*PlayState play`
    VB_DRAW_PLAYER_MASK,

    // #### `result`
    // In `Interface_DrawAmmoCount`:
    // ```c
    // (i == ITEM_STICK) ||
    // (i == ITEM_NUT) ||
    // (i == ITEM_BOMB) ||
    // (i == ITEM_BOW) ||
    // (
    //     (i >= ITEM_BOW_ARROW_FIRE) &&
    //     (i <= ITEM_BOW_ARROW_LIGHT)
    // ) ||
    // (i == ITEM_SLINGSHOT) ||
    // (i == ITEM_BOMBCHU) ||
    // (i == ITEM_BEAN)
    // ```
    // In `KaleidoScope_DrawAmmoCount`:
    // ```c
    // true
    // ```
    // #### `args`
    // - `*int16_t` (item id)
    VB_DRAW_AMMO_COUNT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_DRAW_EPONA_BOOST_CARROTS,

    // #### `args`
    // - `Player*` player
    // - `PlayState*` play
    VB_DRAW_HOOKSHOT_CHAIN,
    VB_DRAW_HOOKSHOT_TIP,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - Player*
    VB_EMPTYING_BOTTLE,

    // #### `result`
    // ```c
    // (gSaveContext.inventory.items[gSaveContext.equips.cButtonSlots[button - 1]] == ITEM_MILK_BOTTLE) &&
    //     (item == ITEM_BOTTLE)
    // ```
    // #### `args`
    // - `int32_t` (button - promoted from `u8`)
    // - `int32_t` (item - promoted from `u8`)
    VB_EMPTY_BOTTLE_TO_HALF_MILK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnArrow`
    VB_EN_ARROW_MAGIC_CONSUMPTION,

    // #### `result`
    // ```c
    // i + 1 == msgCtx->textDrawPos &&
    // (msgCtx->msgMode == MSGMODE_TEXT_DISPLAYING ||
    //  (msgCtx->msgMode >= MSGMODE_OCARINA_STARTING &&
    //   msgCtx->msgMode < MSGMODE_SCARECROW_LONG_RECORDING_START))
    // ```
    // #### `args`
    // - `u16` (text position)
    VB_ENABLE_QUICKTEXT,

    // #### `result`
    // ```c
    // (Message_GetState(&play->msgCtx) == TEXT_STATE_EVENT) && Message_ShouldAdvance(play)
    // ```
    // #### `args`
    // - None
    VB_END_GERUDO_MEMBERSHIP_TALK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGe1`
    VB_END_HORSEBACK_ARCHERY,

    // #### `result`
    // ```c
    // !(this->stateFlags3 & PLAYER_STATE3_PAUSE_ACTION_FUNC)
    // ```
    // #### `args`
    // - `*Player`
    // - `*Input`
    VB_EXECUTE_PLAYER_ACTION_FUNC,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (startMode)
    VB_EXECUTE_PLAYER_STARTMODE_FUNC,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_FADE_KOKIRI,

    // #### `result`
    // ```c
    // EnKo_GetForestQuestState2(this)
    // ```
    // #### `args`
    // - `*EnKo`
    VB_KOKIRI_GET_FOREST_QUEST_STATE2,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnElf`
    VB_FAIRY_HEAL,

    // #### `result`
    // ```c
    // this->actor.xzDistToPlayer < (KREG(59) + 50.0f)
    // ```
    // Whether a hooked fish is reeled in close enough to be caught.
    // #### `args`
    // - None
    VB_FISHING_CATCH_FISH,

    // #### `result`
    // ```c
    // (this->isLoach == 0) && (sFishOnHandIsLoach == 0) && ((s16)this->fishLength < (s16)sFishOnHandLength)
    // ```
    // Whether keeping a fish smaller than the one held asks for confirmation.
    // #### `args`
    // - None
    VB_FISHING_CONFIRM_KEEPING_SMALLER_FISH,

    // #### `result`
    // ```c
    // ((this->timerArray[0] == 1) || (Rand_ZeroOne() < chance)) &&
    //     ((Rand_ZeroOne() < (this->perception * multiplier)) || ((this->isLoach + 1) == KREG(69)))
    // ```
    // Whether a fish bites the lure.
    // #### `args`
    // - None
    VB_FISHING_FISH_BITE,

    // #### `result`
    // ```c
    // ((sLureTimer & 0x7F) == 0) && (Rand_ZeroOne() < 0.05f) && (sLureEquipped != FS_LURE_SINKING) && (KREG(69) == 0)
    // ```
    // Whether a hooked fish randomly escapes the line.
    // #### `args`
    // - None
    VB_FISHING_FISH_ESCAPE,

    // #### `result`
    // ```c
    // sFishInits[thisx->params - EN_FISH_PARAM].isLoach
    // ```
    // Whether this pond fish is a loach.
    // #### `args`
    // - None
    VB_FISHING_FISH_IS_LOACH,

    // #### `result`
    // ```c
    // false
    // ```
    // Whether a caught fish snaps to Link's hand instead of drifting there.
    // #### `args`
    // - None
    VB_FISHING_INSTANT_CATCH,

    // #### `result`
    // ```c
    // false
    // ```
    // Whether the pond owner offers to quit fishing at the door.
    // #### `args`
    // - None
    VB_FISHING_QUIT_AT_DOOR,

    // #### `result`
    // ```c
    // (KREG(1) == 1) || ((sFishGameNumber & 3) == 3)
    // ```
    // Whether loaches spawn in the pond this game.
    // #### `args`
    // - None
    VB_FISHING_SPAWN_LOACHES,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether the starting fishing record uses the vanilla length.
    // A hook returning false should write its own length through the arg.
    // #### `args`
    // - `*f32` (sFishingRecordLength)
    VB_FISHING_USE_DEFAULT_RECORD_LENGTH,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_FISHING_ZERO_XZ,

    // #### `result`
    // True if the next text position must be beyond the current position; false otherwise
    // #### `args`
    // - `u16` (next text position)
    VB_FIX_TEXT_SPEED_SOFTLOCK,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - None
    VB_FIX_SAW_SOFTLOCK,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*EnFz`
    // - `*s32`
    VB_FREEZARD_SCALE_HEALTH_WITH_SIZE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_FLASH_SCREEN_FOR_FINISHING_BLOW,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - `s32` (drop id)
    VB_FLEX_DROP_AMMO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgHeavyBlock`
    VB_FREEZE_LINK_FOR_BLOCK_THROW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_FREEZE_LINK_FOR_FOREST_PILLARS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_FREEZE_ON_SKULL_TOKEN,

    // #### `result`
    // ```c
    // this->reward == GI_NONE
    // ```
    // #### `args`
    // - `*EnFr`
    VB_FROGS_GO_TO_IDLE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_FROGS_OCARINA_GAME_TIMER_TICK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GANON_HEAL_BEFORE_FIGHT,

    // #### `result`
    // ```c
    // (this->invisible && !Flags_GetSwitch(play, this->actor.home.rot.z)) || this->actor.xzDistToPlayer > 300.0f
    // ```
    // #### `args`
    // - `EnGeldB*`
    VB_GERUDO_FIGHTER_CONTINUE_WAITING,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `EnGeldB*`
    VB_GERUDO_FIGHTER_PLAY_MINIBOSS_MUSIC,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `EnGeldB*`
    VB_GERUDO_FIGHTER_THROW_LINK_TO_JAIL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGe2`
    VB_GERUDO_GUARD_SET_ACTION_AFTER_TALK,

    // #### `result`
    // See logic in
    // ```c
    // EnGe1_CheckCarpentersFreed()
    // ```
    // and
    // ```c
    // EnGe2_CheckCarpentersFreed()
    // ```
    // #### `args`
    // - None
    VB_GERUDOS_BE_FRIENDLY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnJs`
    VB_GIVE_BOMBCHUS_FROM_CARPET_SALESMAN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_FAIRY_OCARINA,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_FIRE_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_FOREST_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnNiwLady`
    VB_GIVE_ITEM_FROM_ANJU_AS_ADULT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnNiwLady`
    VB_GIVE_ITEM_FROM_ANJU_AS_CHILD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (ItemID)
    VB_GIVE_ITEM_FROM_BLUE_WARP,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnBomBowlPit`
    VB_GIVE_ITEM_FROM_BOMBCHU_BOWLING,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDns`
    VB_GIVE_ITEM_FROM_BUSINESS_SCRUB,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*EnJs`
    VB_GIVE_ITEM_FROM_CARPET_SALESMAN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnBox`
    VB_GIVE_ITEM_FROM_CHEST,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnCow`
    VB_GIVE_ITEM_FROM_COW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDntJiji`
    VB_GIVE_ITEM_FROM_DEKU_THEATER,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor` (EnDivingGame - &this->actor)
    VB_GIVE_ITEM_FROM_DIVING_MINIGAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // ##### In `EnGo2_GetItem`
    // - `*EnGo2`
    // ##### Everywhere else
    // - None
    VB_GIVE_ITEM_FROM_GORON,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDs`
    VB_GIVE_ITEM_FROM_GRANNYS_SHOP,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGe1`
    VB_GIVE_ITEM_FROM_HORSEBACK_ARCHERY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGe1`
    // - `*PlayState`
    VB_PLAY_HORSEBACK_ARCHERY,

    // #### `result`
    // ```c
    // play->sceneNum == SCENE_KOKIRI_FOREST
    // ```
    // #### `args`
    // - `*EnSa`
    VB_SARIA_GESTURE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*s32` (scoreIndex: 0=30pts, 1=60pts, 2=100pts)
    VB_SCORE_HORSEBACK_ARCHERY_TARGET,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*InterfaceContext`
    VB_SET_HORSEBACK_ARCHERY_AMMO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnItem00`
    VB_GIVE_ITEM_FROM_ITEM_00,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnMk`
    VB_GIVE_ITEM_FROM_LAB_DIVE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnHy`
    VB_GIVE_ITEM_FROM_LOST_DOG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnMs`
    VB_GIVE_ITEM_FROM_MAGIC_BEAN_SALESMAN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_FROM_MAN_ON_ROOF,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGm`
    VB_GIVE_ITEM_FROM_MEDIGORON,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSkj`
    VB_GIVE_ITEM_FROM_OCARINA_MEMORY_GAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGb`
    VB_GIVE_ITEM_FROM_POE_COLLECTOR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSyatekiMan`
    VB_GIVE_ITEM_FROM_SHOOTING_GALLERY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSkj`
    VB_GIVE_ITEM_FROM_SKULL_KID_SARIAS_SONG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSth`
    VB_GIVE_ITEM_FROM_SKULLTULA_REWARD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor` (EnTa - &this->actor)
    VB_GIVE_ITEM_FROM_TALONS_CHICKENS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor` (EnExItem - &this->actor)
    VB_GIVE_ITEM_FROM_TARGET_IN_WOODS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_GERUDO_MEMBERSHIP_CARD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_LIGHT_ARROW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_LIGHT_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_MASTER_SWORD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_OCARINA_OF_TIME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_SHADOW_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSi`
    VB_GIVE_ITEM_SKULL_TOKEN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `songItemId`
    VB_GIVE_ITEM_SONG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_SPIRIT_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_STRENGTH_1,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_WATER_MEDALLION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_WEIRD_EGG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_GIVE_ITEM_ZELDAS_LETTER,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*VBFishingData`
    VB_GIVE_RANDO_FISHING_PRIZE,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - '*Fishing'
    VB_GIVE_RANDO_GLITCH_FISHING_PRIZE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGo2`
    VB_GORON_LINK_BE_SCARED,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_GORON_RUBY)
    // ```
    // #### `args`
    // - None
    VB_GORONS_CONSIDER_DODONGOS_CAVERN_FINISHED,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_MEDALLION_FIRE)
    // ```
    // #### `args`
    // - None
    VB_GORONS_CONSIDER_FIRE_TEMPLE_FINISHED,

    // #### `result`
    // ```c
    // CHECK_OWNED_EQUIP(EQUIP_TYPE_TUNIC, EQUIP_INV_TUNIC_GORON)
    // ```
    // #### `args`
    // - None
    VB_GORONS_CONSIDER_TUNIC_COLLECTED,

    // #### `result`
    // ```c
    // gSaveContext.rupees < 100
    // ```
    // #### `args`
    // - `NULL`
    VB_GRANNY_SAY_INSUFFICIENT_RUPEES,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDs`
    VB_GRANNY_TAKE_MONEY,

    // ### `result`
    // ```c
    // false
    // ```
    // ### `args`
    // - `*EnKusa`
    VB_GRASS_DROP_ITEM,

    // ### `result`
    // ```c
    // true
    // ```
    // ### `args`
    // - `*EnKusa`
    VB_GRASS_SETUP_DRAW,

    // #### `result`
    // ```c
    // Flags_GetSwitch(play, this->dyna.actor.params & 0x3F)
    // ```
    // #### `args`
    // - None
    VB_GTG_GATE_BE_OPEN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnCrow`
    VB_GUAY_DO_DIVE_ATTACK,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*EnCrow`
    VB_GUAY_FORCE_FLY_AWAY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnCrow`
    VB_GUAY_SETUP_DAMAGED,

    // #### `result`
    // ```c
    // this->actor.colChkInfo.health != 0
    // ```
    // #### `args`
    // - `*f32` (scale)
    VB_GUAY_ALIVE_MOVE_HEIGHT_OFFSET,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HAVE_OCARINA_NOTE_A4,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HAVE_OCARINA_NOTE_B4,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HAVE_OCARINA_NOTE_D4,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HAVE_OCARINA_NOTE_D5,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HAVE_OCARINA_NOTE_F4,

    // #### `result`
    // ```c
    // var >= gSaveContext.health && gSaveContext.health > 0
    // ```
    // #### `args`
    // - None
    VB_HEALTH_METER_BE_CRITICAL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HEARTS_INCREASE_WITH_CONTAINERS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgIceTurara`
    VB_ICICLE_SETUP_DRAW,

    // #### `result`
    // ```c
    // (respawnFlag == 1) || (respawnFlag == -1)
    // ```
    // #### `args`
    // - `int32_t` (respawnFlag)
    VB_INFLICT_VOID_DAMAGE,

    // #### `result`
    // ```c
    // item >= ITEM_NONE_FE
    // ```
    // #### `args`
    // - `int32_t` (item)
    VB_ITEM_ACTION_BE_NONE,

    // #### `result`
    // ```c
    // Flags_GetCollectible(play, 0x1F)
    // ```
    // #### `args`
    // - `*ItemBHeart`
    VB_ITEM_B_HEART_DESPAWN,

    // #### `result`
    // ```c
    // Flags_GetCollectible(play, this->collectibleFlag)
    // ```
    // #### `args`
    // - `*EnItem00`
    VB_ITEM00_DESPAWN,

    // #### `result`
    // ```c
    // this->unk_15A > 0
    // ```
    // #### `args`
    // - `*EnItem00`
    VB_ITEM00_TIMER_TICK,

    // #### `result`
    // ```c
    // Math_Vec3f_DistXZ(&feedingSpot, &player->actor.world.pos) < 300.0f && play->isPlayerDroppingFish(play)
    // ```
    // #### `args`
    // - `*EnJj`
    VB_JABU_JABU_EAT_FISH,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_JABU_WOBBLE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_HOT_ROOM_DISTORTION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_KALEIDO_UNPAUSE_CLOSE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnFirefly`
    VB_KEESE_DO_DIVE_ATTACK,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*EnFirefly`
    VB_KEESE_FORCE_FLY_AWAY,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - `*EnFirefly`
    VB_KEESE_SETUP_FALL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnFirefly`
    VB_KEESE_SETUP_FROZENFALL,

    // #### `result`
    // ```c
    // Flags_GetEventChkInf(EVENTCHKINF_KING_ZORA_MOVED)
    // ```
    // #### `args`
    // - `*EnKz`
    VB_KING_ZORA_BE_MOVED,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_ZORA_SAPPHIRE)
    // ```
    // #### `args`
    // - `*EnKz`
    VB_KING_ZORA_THANK_CHILD,

    // #### `result`
    // ```c
    // CHECK_OWNED_EQUIP(EQUIP_TYPE_TUNIC, EQUIP_INV_TUNIC_ZORA)
    // ```
    // #### `args`
    // - `*EnKz`
    VB_KING_ZORA_TUNIC_CHECK,

    // #### `result`
    // ```c
    // false if in Jabu, carrying Ruto, abducted flag set, door is id 21 or 3
    // ```
    // #### `args`
    // - `*Actor` (shutter door)
    VB_JABU_PREVENT_RUTO_REENTER_BIGOCTO,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - `ObjLightswitch*`
    VB_LIGHTSWITCH_OFF,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_LINK_SPIN_WITH_GORON_POT,

    // #### `result`
    // ```c
    // gSaveContext.eventInf[0] & 0x40
    // ```
    // #### `args`
    // - None
    VB_LINK_WIN_EPONA,

    // #### `result`
    // ```c
    // !Flags_GetSwitch(play, this->dyna.actor.params & 0x3F)
    // ```
    // #### `args`
    // - `*DoorShutter`
    VB_LOCK_BOSS_DOOR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_LOST_WOODS_OCARINA_GAME_TIMER_TICK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnMs`
    VB_MAGIC_BEAN_SALESMAN_TAKE_MONEY,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_SONG_EPONA)
    // ```
    // #### `args`
    // - None
    VB_MALON_ALREADY_TAUGHT_EPONAS_SONG,

    // #### `result`
    // ```c
    // Flags_GetEventChkInf(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE)
    // ```
    // #### `args`
    // - None
    VB_MALON_RETURN_FROM_CASTLE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SEND_MALON_HOME,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_KOKIRI_EMERALD)
    // ```
    // #### `args`
    // - `*EnMd`
    VB_MIDO_CONSIDER_DEKU_TREE_DEAD,

    // #### `result`
    // ```c
    // EnMd_ShouldSpawn(this, play)
    // ```
    // #### `args`
    // - `*EnMd`
    VB_MIDO_SPAWN,

    // #### `result`
    // ```c
    // reflection[i].reflectionPoly != NULL
    // ```
    // #### `args`
    // - `*MirRayShieldReflection`
    VB_MIRRAY_DRAW_REFLECTION,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `s32` (note append position)
    VB_MODIFY_LOST_WOODS_OCARINA_GAME_NOTE_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `f32*` speed
    VB_MODIFY_WATER_TEMPLE_WATER_LEVEL_SPEED,

    // #### `result`
    // ```c
    // this->interactInfo.talkState == NPC_TALK_STATE_ACTION
    // ```
    // #### `args`
    // - `*EnMd`
    //
    // ### Note:
    // When overriding this, ensure you're not in the intro cutscene as Mido's path has not been loaded
    VB_MOVE_MIDO_IN_KOKIRI_FOREST,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_MOVE_THROWN_ACTOR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnIk`
    VB_NABOORU_KNUCKLE_DEATH_SCENE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ElfMsg`
    VB_NAVI_TALK,

    // #### `result`
    // ```c
    // Inventory_HasEmptyBottle() == 0
    // ```
    // #### `args`
    // - None
    VB_NEED_BOTTLE_FOR_GRANNYS_ITEM,

    // #### `result`
    // ```c
    // Flags_GetInfTable(INFTABLE_GREETED_BY_SARIA)
    // ```
    // #### `args`
    // - None
    VB_NOT_BE_GREETED_BY_SARIA,

    // #### `result`
    // ```c
    // gSaveContext.inventory.dungeonKeys[gSaveContext.mapIndex] <= 0
    // ```
    // #### `args`
    // - `*EnDoor`
    VB_NOT_HAVE_SMALL_KEY,

    // #### `result`
    // ```c
    // Flags_GetItemGetInf(ITEMGETINF_30)
    // ```
    // #### `args`
    // - `*EnDs`
    VB_OFFER_BLUE_POTION,

    // #### `result`
    // ```c
    // this->switchFlag >= 0
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_OKARINA_TAG_COMPLETE,

    // #### `result`
    // ```c
    // (this->switchFlag >= 0) && (Flags_GetSwitch(play, this->switchFlag))
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_OKARINA_TAG_COMPLETED,

    // #### `result`
    // ```c
    // this->getItemId != GI_NONE
    // ```
    // #### `args`
    // - `*EnBox`
    VB_OPEN_CHEST,

    // #### `result`
    // ```c
    // CHECK_QUEST_ITEM(QUEST_KOKIRI_EMERALD)
    // ```
    // #### `args`
    // - `*EnKo`
    VB_OPEN_KOKIRI_FOREST,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*uint16_t` (overrideTextId)
    VB_OVERRIDE_LINK_THE_GORON_DIALOGUE,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `None`
    VB_OWL_CHOOSE_BETTER,

    // #### `result`
    // ```c
    // this->actor.xzDistToPlayer < targetDist
    // ```
    // #### `args`
    // - `*EnOwl`
    VB_OWL_INTERACTION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_PERFORM_WALL_COLLISION_CHECK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BossGanondrof`
    VB_PHANTOM_GANON_DEATH_SCENE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_BEAN_PLANTING_CS,

    // #### `result`
    // ##### In `DoorWarp1_ChildWarpOut` - `SCENE_DODONGOS_CAVERN_BOSS`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_USED_DODONGOS_CAVERN_BLUE_WARP)
    // ```
    // ##### In `DoorWarp1_ChildWarpOut` - `SCENE_DEKU_TREE_BOSS`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_OBTAINED_KOKIRI_EMERALD_DEKU_TREE_DEAD)
    // ```
    // ##### In `DoorWarp1_RutoWarpOut`
    // ```c
    // true
    // ```
    // ##### In `DoorWarp1_AdultWarpOut` - `SCENE_FOREST_TEMPLE_BOSS`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_USED_FOREST_TEMPLE_BLUE_WARP)
    // ```
    // ##### In `DoorWarp1_AdultWarpOut` - `SCENE_FIRE_TEMPLE_BOSS`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_USED_FIRE_TEMPLE_BLUE_WARP)
    // ```
    // ##### In `DoorWarp1_AdultWarpOut` - `SCENE_WATER_TEMPLE_BOSS`
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_USED_WATER_TEMPLE_BLUE_WARP)
    // ```
    // ##### In `DoorWarp1_AdultWarpOut` - `SCENE_SPIRIT_TEMPLE_BOSS`
    // ```c
    // !CHECK_QUEST_ITEM(QUEST_MEDALLION_SPIRIT)
    // ```
    // ##### In `DoorWarp1_AdultWarpOut` - `SCENE_SHADOW_TEMPLE_BOSS`
    // ```c
    // !CHECK_QUEST_ITEM(QUEST_MEDALLION_SHADOW)
    // ```
    // #### `args`
    // - `int32_t` (EVENTCHKINF / RAND_INF_DUNGEONS_DONE)
    VB_PLAY_BLUE_WARP_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_BOLERO_OF_FIRE_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDaiku`
    VB_PLAY_CARPENTER_FREE_CS,

    // #### `result`
    // ```c
    // true if one point cutscene skip not enabled, or not randomizer
    // ```
    // #### `args`
    // - none
    VB_PLAY_TIMEBLOCK_CS,

    // #### `result`
    // Close enough & various cutscene checks
    // ```c
    // (func_80AEC5FC(this, play)) && (!Play_InCsMode(play)) &&
    // (!(player->stateFlags1 & (PLAYER_STATE1_HANGING_OFF_LEDGE | PLAYER_STATE1_CLIMBING_LEDGE |
    // PLAYER_STATE1_CLIMBING_LADDER))) &&
    // (player->actor.bgCheckFlags & 1)
    // ```
    // #### `args`
    // - `*EnRu1`
    VB_PLAY_CHILD_RUTO_INTRO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_DARUNIAS_JOY_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgTreemouth`
    VB_PLAY_DEKU_TREE_INTRO_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*DemoKekkai`
    VB_PLAY_DISPEL_BARRIER_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_PLAY_DOOR_OF_TIME_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_PLAY_DRAIN_WELL_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // ##### In `z_demo.c`:
    // - `int32_t` (entranceCutscene->flag) (promoted from `uint8_t` by va_arg)
    // - `int32_t` (entranceCutscene->entrance) (promoted from `uint16_t` by va_arg)
    // ##### In `z_bg_breakwall.c` and `z_bg_toki_swd.c`:
    // - `int32_t` (EVENTCHKINF)
    // - `int32_t` (gSaveContext.entranceIndex)
    VB_PLAY_ENTRANCE_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // ##### When called from `z_en_ds.c`
    // - `*EnDs`
    // ##### When called from `z_en_mk.c`
    // - `*EnMk`
    VB_PLAY_EYEDROP_CREATION_ANIM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_EYEDROPS_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_FIRE_ARROW_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnFr`
    VB_PLAY_FROG_OCARINA_GAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnHeishi2`
    // - `bool` (clearCamera - true if the code clears a sub-camera, false otherwise)
    VB_PLAY_GATE_OPENING_OR_CLOSING_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_GORON_FREE_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSkj`
    VB_PLAY_LOST_WOODS_OCARINA_GAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_MINUET_OF_FOREST_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_MWEEP_CS,

    // #### `result`
    // ```c
    // this->getItemId == GI_GAUNTLETS_SILVER
    // ```
    // #### `args`
    // - None
    VB_PLAY_NABOORU_CAPTURED_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BossTw`
    // - `*PlayState`
    VB_PLAY_TWINROVA_INTRO_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_TWINROVA_SPAWN_PORTAL_TRANSLATION_KOTAKE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_TWINROVA_SPAWN_PORTAL_TRANSLATION_KOUME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_PLAY_ONEPOINT_ACTOR_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*int16_t` (cutscene id)
    VB_PLAY_ONEPOINT_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (owl type)
    VB_PLAY_OWL_TRAVEL_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_PRELUDE_OF_LIGHT_CS,

    // #### `result`
    // ##### In `z_demo.c` - `Cutscene_Command_Terminator` (setting `shouldSkipCommand`)
    // ```c
    // true
    // ```
    // ##### In `z_demo.c` - `Cutscene_Command_Terminator` (inside if block and switch)
    // ```c
    // !Flags_GetEventChkInf(EVENTCHKINF_PULLED_MASTER_SWORD_FROM_PEDESTAL)
    // ```
    // #### `args`
    // - None
    VB_PLAY_PULL_MASTER_SWORD_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_RAINBOW_BRIDGE_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_PLAY_ROYAL_FAMILY_TOMB_CS,

    // #### `result`
    // ```c
    // play->csCtx.state != 0 && play->csCtx.npcActions[3] != NULL && play->csCtx.npcActions[3]->action == 2
    // ```
    // #### `args`
    // - `*BgSpot02Objects`
    VB_PLAY_ROYAL_FAMILY_TOMB_EXPLODE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSa`
    VB_PLAY_SARIAS_SONG_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_SERENADE_OF_WATER_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_SHIEK_BLOCK_MASTER_SWORD_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnSyatekiItm`
    VB_PLAY_SHOOTING_GALLERY,

    // #### `result`
    // ```c
    // (giEntry.itemId != ITEM_NONE) && (giEntry.gi >= 0) && (Item_CheckObtainability(giEntry.itemId) == ITEM_NONE)
    // ```
    // #### `args`
    // - `*EnBox`
    VB_PLAY_SLOW_CHEST_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnFu`
    VB_PLAY_SONG_OF_STORMS_CS,

    // #### `result`
    // ```c
    // !CHECK_QUEST_ITEM(QUEST_SONG_SUN)
    // ```
    // #### `args`
    // - `*EnOkarinaTag`
    VB_PLAY_SUNS_SONG_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*LinkAnimationHeader`
    VB_PLAY_THROW_ANIMATION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_PLAY_TRANSITION_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*DemoIm`
    VB_PLAY_ZELDAS_LULLABY_CS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    // - `int32_t` (magicArrowType)
    // - `*int32_t` (arrowType)
    VB_PLAYER_ARROW_MAGIC_CONSUMPTION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `void*` player (Player*)
    // - `PlayState*` play
    VB_PLAYER_DRAW_BOTTLE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    VB_PLAYER_LIMIT_DIVE_XZ_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    VB_PLAYER_LIMIT_JUMP_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    // - `f32*` speedTarget
    VB_PLAYER_MODIFY_RUN_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    // - `f32*` swimSpeed
    // - `s32` sControlInput != NULL
    VB_PLAYER_MODIFY_SWIM_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `s32` limbIndex
    // - `Gfx**` dList (write to *dList to replace the resolved display list)
    // - `void*` player (Player*)
    // - `PlayState*` play
    VB_PLAYER_OVERRIDE_LIMB_DRAW,

    // Fired from Player_OverrideLimbDrawPause (pause/equipment screen character only).
    // #### `args`
    // - `s32` limbIndex
    // - `Gfx**` dList (write to *dList to replace the resolved display list)
    // - `void*` player (Player*)
    // - `PlayState*` play
    VB_PLAYER_OVERRIDE_LIMB_DRAW_PAUSE,

    // #### `args`
    // - `*Player`
    // - `*PlayState`
    VB_PLAYER_UPDATE_BOTTLE_HELD,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*Player`
    // - `*PlayState`
    // - `*Input` (sControlInput)
    // - `s32` (sFloorType)
    VB_PLAYER_ROLL_CHAIN,

    // #### `result`
    // ```c
    // true - player may begin a roll
    // ```
    // #### `args`
    // - `Player*`
    // - `PlayState*`
    VB_PLAYER_CAN_ROLL,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*Player`
    // - `*PlayState`
    // - `s16 yawTarget` (stick world-space yaw, promoted to int in va_list)
    VB_PLAYER_ROLL_STEER,

    // #### `result`
    // ```c
    // this->ageProperties->unk_24 <= ySurface
    // ```
    // #### `args`
    // - `Player*`
    VB_PLAYER_SPAWN_SWIMMING,

    // #### `result`
    // ```c
    // item == ITEM_SAW
    // ```
    // #### `args`
    // - None
    VB_POACHERS_SAW_SET_DEKU_NUT_UPGRADE_FLAG,

    // #### `result`
    // ```c
    // (dropParams >= ITEM00_RUPEE_GREEN) && (dropParams <= ITEM00_BOMBS_SPECIAL)
    // ```
    // #### `args`
    // - `*ObjTsubo`
    VB_POT_DROP_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjTsubo`
    VB_POT_SETUP_DRAW,

    // #### `result`
    // ```c
    // dropId == ITEM00_STICK
    // ```
    // #### `args`
    // - None
    VB_PREVENT_ADULT_STICK,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - None
    VB_PREVENT_STRENGTH,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `s32` (entrance index)
    VB_RACE_INGO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnRd`
    VB_REDEAD_GIBDO_FREEZE_LINK,

    // #### `result`
    // ```c
    // this->alpha <= 0
    // ```
    // #### `args`
    // - `*BgIceShelter`
    VB_RED_ICE_DROP_ITEM,

    // #### `result`
    // ```c
    // !((this->dyna.actor.params >> 6) & 1) && (Flags_GetSwitch(play, this->dyna.actor.params & 0x3F))
    // ```
    // #### `args`
    // - `*BgIceShelter`
    VB_RED_ICE_MELTED_FLAG,

    // #### `result`
    // ```c
    // camera->xzSpeed > 0.001f || <any release button pressed> || params->interfaceFlags & 0x8
    // ```
    // #### `args`
    // - `Camera*` (`camera`)
    VB_RELEASE_DOORC_CAMERA,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_RENDER_KEY_COUNTER,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_RENDER_RUPEE_COUNTER,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `**Gfx` (`&POLY_OPA_DISP`)
    VB_RENDER_YES_ON_CONTINUE_PROMPT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*PlayState`
    // - `*Player`
    // - `*u32`
    // - `*s16`
    VB_REVALIDATE_CLIMBED_WALL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_REVERT_SPOILING_ITEMS,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - `*EnIshi`, `*ObjBombiwa`, or `*ObjHamishi`
    VB_ROCK_DROP_ITEM,

    // #### `result`
    // ```c
    // !Flags_GetInfTable(INFTABLE_145)
    // ```
    // #### `args`
    // - `*EnRu1`
    VB_RUTO_BE_CONSIDERED_NOT_KIDNAPPED,

    // #### `result`
    // Landed on the platform in the big okto room
    // ```c
    // dynaPolyActor != NULL && dynaPolyActor->actor.id == ACTOR_BG_BDAN_OBJECTS &&
    // dynaPolyActor->actor.params == 0 && !Player_InCsMode(play) && play->msgCtx.msgLength == 0
    // ```
    // #### `args`
    // - `*EnRu1`
    // - `*DynaPolyActor`
    VB_RUTO_RUN_TO_SAPPHIRE,

    // #### `result`
    // in the big okto room and flag
    // ```c
    // !Flags_GetInfTable(INFTABLE_RUTO_IN_JJ_WANTS_TO_BE_TOSSED_TO_SAPPHIRE) && (func_80AEB124(play) != 0)
    // ```
    // #### `args`
    // - `*EnRu1`
    VB_RUTO_WANT_TO_BE_TOSSED_TO_SAPPHIRE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnGb`
    VB_SELL_POES_TO_POE_COLLECTOR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `None`
    VB_SET_BOMBCHU_BOWLING_AMMO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnBomBowlMan`
    // - `s16*` (prize to show, an `ExItemType`)
    VB_SET_BOMBCHU_BOWLING_PRIZE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnBomBowlMan`
    VB_SET_BOMBCHU_BOWLING_PRIZE_SELECT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (button - promoted from `s16`)
    VB_SET_BUTTON_ITEM_FROM_C_BUTTON_SLOT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnNiwLady`
    VB_SET_CUCCO_COUNT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SET_DIVING_GAME_TIME_LIMIT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnFr`
    // - `s16` (default time limit)
    VB_SET_FROG_OCARINA_GAME_TIME_LIMIT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `s32` (round number, zero-based)
    // - `*u8` (note end position)
    VB_SET_LOST_WOODS_OCARINA_GAME_NOTES,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SET_LOST_WOODS_OCARINA_GAME_STARTING_NOTES,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*s32` (ammo count)
    VB_SET_SHOOTING_GALLERY_AMMO,

    // #### `result`
    // ```c
    // SurfaceType_GetFloorEffect(&play->colCtx, poly, bgId) == FLOOR_EFFECT_2
    // ```
    // #### `args`
    // - `*int16_t` - original next entrance index (`play->setupExitList[exitIndex - 1]`)
    VB_SET_VOIDOUT_FROM_SURFACE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - BgHakaShip*
    // - PlayState*
    VB_SHADOW_SHIP_SET_SPEED,

    // #### `result`
    // ```c
    // (!CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, EQUIP_INV_BOOTS_IRON) &&
    // !Flags_GetEventChkInf(EVENTCHKINF_LEARNED_SERENADE_OF_WATER)) && LINK_IS_ADULT
    // ```
    // #### `args`
    // - None
    VB_SHIEK_PREPARE_TO_GIVE_SERENADE_OF_WATER,

    // #### `result`
    // ```c
    // LINK_IS_ADULT
    // ```
    // #### `args`
    // - None
    VB_SHOOTING_GALLERY_SHUFFLE_ADULT_RUPEES,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - None
    VB_SHORT_CIRCUIT_GIVE_ITEM_PROCESS,

    // #### `result`
    // ```c
    // (s16)sFishingRecordLength < (s16)sFishOnHandLength
    // ```
    // #### `args`
    // - `*f32` (sFishOnHandLength)
    VB_SHOULD_CHECK_FOR_FISHING_RECORD,

    // #### `result`
    // ##### In `Fishing_HandleOwnerDialog` - `LINK_AGE_CHILD`
    // ```c
    // (sFishingRecordLength >= 50.0f) && !(HIGH_SCORE(HS_FISHING) & HS_FISH_PRIZE_CHILD)
    // ```
    // ##### In `Fishing_HandleOwnerDialog` - `!LINK_AGE_CHILD`
    // ```c
    // (sFishingRecordLength >= 60.0f) && !(HIGH_SCORE(HS_FISHING) & HS_FISH_PRIZE_ADULT)
    // ```
    // #### `args`
    // - `*VBFishingData`
    VB_SHOULD_GIVE_VANILLA_FISHING_PRIZE,

    // #### `result`
    // ```c
    // CHECK_BTN_ALL(input->press.button, BTN_B)
    // ```
    // #### `args`
    // - `*Input`
    VB_SHOULD_OSSAN_CANCEL,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*VBFishingData`
    VB_SHOULD_SET_FISHING_RECORD,

    // #### `result`
    // ```c
    // !(this->actor.bgCheckFlags & BGCHECKFLAG_GROUND) || (this->actor.world.pos.z > 1300.0f) ||
    // BgCheck_SphVsFirstPoly(&play->colCtx, &rodCheckPos, 20.0f)
    // ```
    // #### `args`
    // - `*Vec3f`
    VB_NOT_CAST_FISHING,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `*s8 iter2`
    // - `s8 sp3C[4]`
    VB_SHOULD_QUICKSPIN,

    // #### `result`
    // ```c
    // (interactedActor->id == ACTOR_BG_TOKI_SWD) && LINK_IS_ADULT
    // ```
    // #### `args`
    // - None
    VB_SHOW_MASTER_SWORD_TO_PLACE_IN_PEDESTAL,

    // #### `result`
    // ```c
    // gSaveContext.showTitleCard
    // ```
    // #### `args`
    // - None
    VB_SHOW_TITLE_CARD,

    // #### `result`
    // ```c
    // this->actor.xyzDistToPlayerSq < 900.0f
    // ```
    // #### `args`
    // - *EnGSwitch
    VB_SILVER_COLLECT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - *EnGSwitch
    VB_SILVER_COUNT_CHECK,

    // #### `result`
    // ```c
    // Flags_GetSwitch(play, this->switchFlag)
    // ```
    // #### `args`
    // - *EnGSwitch
    VB_SILVER_DESPAWN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SKIP_TALKING,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SLAY_GANON,

    // #### `result`
    // ```c
    // (collectible >= 0) && (collectible <= 0x19
    // ```
    // #### `args`
    // - `*ObjKibako`
    VB_SMALL_CRATE_DROP_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjKibako`
    VB_SMALL_CRATE_SETUP_DRAW,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - None
    VB_SKIP_SCARECROWS_SONG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjBean`
    VB_SPAWN_BEAN_STALK_FAIRIES,

    // #### `result`
    // ```c
    // this->timer >= 60
    // ```
    // #### `args`
    // - `None`
    VB_SPAWN_BEAN_SKULLTULA,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // ##### In `z_boss_dodongo.c`:
    // - `*BossDodongo`
    //
    // ##### In `z_boss_fd2.c`
    // - `*BossFd2`
    //
    // ##### In `z_boss_ganondrof.c`:
    // - `*BossGanondrof`
    //
    // ##### In `z_boss_goma.c`:
    // - `*BossGoma`
    //
    // ##### In `z_boss_mo.c`:
    // - `*BossMo`
    //
    // ##### In `z_boss_sst.c`:
    // - `*BossSst`
    //
    // ##### In `z_boss_tw.c`:
    // - `*BossTw`
    //
    // ##### In `z_boss_va.c`:
    // - `*BossVa`
    VB_SPAWN_BLUE_WARP,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `s32` (Cucco index; 0 = small, 1 = big)
    VB_SPAWN_BOMBCHU_BOWLING_CUCCOS,

    // #### `result`
    // ```c
    // this->timer == 4
    // ```
    // #### `args`
    // - `*EnButte`
    VB_SPAWN_BUTTERFLY_FAIRY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnButte`
    VB_SPAWN_BUTTERFLY_FAIRY_EASY,

    // #### `result`
    // ```c
    // INV_CONTENT(ITEM_ARROW_FIRE) == ITEM_NONE
    // ```
    // #### `args`
    // - None
    VB_SPAWN_FIRE_ARROW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnElf`
    VB_SPAWN_FOUNTAIN_FAIRIES,

    // #### `result`
    // ```c
    // this->unk_19D & 1
    // ```
    // #### `args`
    // - `*EnGs`
    VB_SPAWN_GOSSIP_STONE_FAIRY,

    // #### `result`
    // ##### In `BossFd_Fly` (`case BOSSFD_SKULL_BURN`)
    // ```c
    // this->timers[0] == 7
    // ```
    // ##### Everywhere else
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_SPAWN_HEART_CONTAINER,

    // #### `result`
    // ```c
    // (INV_CONTENT(ITEM_TRADE_ADULT) == ITEM_ODD_POTION) ? true : false
    // ```
    // #### `args`
    // - `*EnKo`
    VB_SPAWN_LW_FADO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ShotSun`
    VB_SPAWN_SONG_FAIRY,

    // #### `result`
    // ```c
    // (talkOfferActor != NULL) || (cUpTalkActor != NULL)
    // ```
    // #### `args`
    // - None
    VB_SPEAK,

    // #### `result`
    // ```c
    // this->dyna.actor.params == TURARA_STALACTITE_REGROW
    // ```
    // #### `args`
    // - `*BgIceTurara`
    VB_STALACTITE_DROP_ITEM,

    // #### `result`
    // ```c
    // this->collider.base.acFlags & AC_HIT
    // ```
    // #### `args`
    // - `*BgIceTurara`
    VB_STALAGMITE_DROP_ITEM,

    // #### `result`
    // ```c
    // ABS(wallPoly->normal.y) < 600
    // ```
    // #### `args`
    // - None
    VB_SURFACE_ANGLE_IS_CLIMBABLE,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - None
    VB_SURFACE_IS_CLIMBABLE,

    // #### `result`
    // ```c
    // SurfaceType_GetData(colCtx, poly, bgId, 1) >> 17 & 1
    // ```
    // #### `args`
    // - None
    VB_SURFACE_IS_HOOKSHOT,

    // #### `result`
    // ```c
    // varies, never set should to true
    // ```
    // #### `args`
    // - `*Actor`
    // - `*s16` - timer value
    VB_SWITCH_TIMER_TICK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*CollisionPoly
    // - s32 - background id`
    VB_TARGETABLE_HOOKSHOT_RETICLE,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - `u16` (text position)
    VB_TEXT_CRAWL_FASTER,

    // #### `result`
    // ```c
    // (this->stateFlags1 & PLAYER_STATE1_CARRYING_ACTOR) && (this->heldActor != NULL) &&
    // CHECK_BTN_ANY(sControlInput->press.button, buttonsToCheck)
    // ```
    // #### `args`
    // - `*Input`
    VB_THROW_OR_PUT_DOWN_HELD_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_ON_ACTOR_THROW_ONLY_CHECK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnHs`
    VB_TRADE_COJIRO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnMk`
    VB_TRADE_FROG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnDs`
    VB_TRADE_ODD_MUSHROOM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnKo`
    VB_TRADE_ODD_POTION,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnNiwLady`
    VB_TRADE_POCKET_CUCCO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnToryo`
    VB_TRADE_SAW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnMk`
    VB_TRADE_TIMER_EYEDROPS,

    // #### `result`
    // ```c
    // INV_CONTENT(ITEM_TRADE_ADULT) == ITEM_FROG)
    // ```
    // #### `args`
    // - None
    VB_TRADE_TIMER_FROG,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_TRADE_TIMER_ODD_MUSHROOM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*PauseContext`
    VB_TRANSITION_TO_SAVE_SCREEN_ON_DEATH,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnWood02`
    VB_TREE_DROP_COLLECTIBLE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjWood02`
    VB_TREE_SETUP_DRAW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ObjWood02`
    VB_TREE_DROP_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `int32_t` (button - promoted from `u8`)
    // - `int32_t` (item - promoted from `u8`)
    VB_UPDATE_BOTTLE_ITEM,

    // #### `result`
    // ```c
    // INV_CONTENT(ITEM_ODD_MUSHROOM) == ITEM_EYEDROPS
    // ```
    // #### `args`
    // - `*EnMk`
    VB_USE_EYEDROP_DIALOGUE,

    // #### `result`
    // ```c
    // (this->modelAnimType != PLAYER_ANIMTYPE_3) && (play->shootingGalleryStatus == 0)
    // ```
    // #### `args`
    // - `*Player`
    VB_USE_HELD_ITEM_AFTER_CHANGE,

    // #### `result`
    // ```c
    // (shapeRotY < -0x2E93) || (shapeRotY >= 0x7C19)
    // ```
    // #### `args`
    // - None
    VB_WIN_GORON_POT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnWonderItem`
    VB_WONDER_DROP_ITEM,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - 'Vec3f' pos
    // - 'f32' rotY
    VB_WONDER_HEISHI_ITEM,

    // #### `result`
    // ```c
    // (gSaveContext.dayTime < 0xB888 || IS_DAY) && ((!IS_RANDO &&
    // !Flags_GetEventChkInf(EVENTCHKINF_ZELDA_FLED_HYRULE_CASTLE)) || (IS_RANDO && !metZelda))
    // (gSaveContext.dayTime >= 0xB889) || !IS_DAY || (!IS_RANDO &&
    // Flags_GetEventChkInf(EVENTCHKINF_ZELDA_FLED_HYRULE_CASTLE)) || (IS_RANDO && metZelda)
    // ```
    // #### `args`
    // - EnHeishi1*
    VB_WONDER_HEISHI_PATROLLING,

    // #### `result`
    // ```c
    // (this->switchFlag >= 0) && Flags_GetSwitch(play, this->switchFlag)
    // ```
    // #### `args`
    // - `None`
    VB_WONDER_SPAWN,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnWonderTalk2`
    VB_WONDER_TALK,

    // #### `result`
    // ```c
    // varies
    // ```
    // #### `args`
    // - `*Actor`
    VB_TRIGGER_VOIDOUT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_TORCH2_HANDLE_CLANKING,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_RECIEVE_FALL_DAMAGE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnRr`
    VB_LIKE_LIKE_GRAB_PLAYER,

    // #### `result`
    // ```c
    // entry != NULL
    // ```
    // #### `args`
    // - `*AnimationEntry`
    // - `*LinkAnimationHeader`
    // - `s32` frame
    // - `s32` limbCount
    // - `*Vec3s` frameTable
    VB_LOAD_PLAYER_ANIMATION_FRAME,

    // #### `result`
    // ```c
    // DoorWarp1_PlayerInRange(this, play)
    // ```
    // #### `args`
    // - `*DoorWarp1`
    VB_BLUE_WARP_CONSIDER_ADULT_IN_RANGE,

    // #### `result`
    // ```c
    // (CVarGetInteger(CVAR_GAMEPLAY_STATS("ShowIngameTimer"), 0) && gSaveContext.fileNum >= 0 && gSaveContext.fileNum
    // <= 2)
    // ```
    // #### `args`
    // - `*PlayState`
    VB_SHOW_GAMEPLAY_TIMER,

    // (this->dyna.actor.params >> 5 & 0x7F) == GI_ICE_TRAP && this->actionFunc == EnBox_Open &&
    // this->skelanime.curFrame > 45 && this->iceSmokeTimer < 100
    // ```
    // #### `args`
    // - `*EnBox`
    VB_CHEST_USE_ICE_EFFECT,

    // #### `result`
    // ```c
    // arg3 < fabsf(sp1C.x) || arg4 < fabsf(sp1C.y)
    // ```
    // #### `args`
    // - `*DoorShutter`
    // - `*Vec3f` (relPlayerPos)
    // - `*f32` (maxDistSides)
    VB_BE_NEAR_DOOR_SHUTTER,

    // #### `result`
    // ```c
    // arg3 < fabsf(sp1C.x) || arg4 < fabsf(sp1C.y)
    // ```
    // #### `args`
    // - `*Vec3f` (playerPosRelToDoor)
    VB_EN_DOOR_OFFER_OPEN,

    // #### `result`
    // ```c
    // CVarGetInteger(CVAR_ENHANCEMENT("3DSceneRender"), 0)
    // ```
    // #### `args`
    // - None
    VB_DRAW_2D_BACKGROUND,

    // true
    // ```
    // #### `args`
    // - `*Player`
    VB_SET_STATIC_PREV_FLOOR_TYPE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    VB_SET_STATIC_FLOOR_TYPE,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - *EnGirlACanBuyResult
    VB_CAN_BUY_BOMBCHUS,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - *EnGirlACanBuyResult
    // - `RAND_INF`
    VB_CAN_BUY_SHOP_SHIELD_OR_TUNIC,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - None
    VB_CHECK_BOMBCHU_CAPACITY,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - int16_t
    VB_COLOR_AMMO_GREEN,

    // (this->collider.base.acFlags & AC_HIT) && !Player_InCsMode(play) &&
    //   (player->meleeWeaponAnimation == 22 || player->meleeWeaponAnimation == 23)
    // ```
    // #### `args`
    // - `*BgHidanDalm`
    VB_HAMMER_TOTEM_BREAK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*FileChooseContext`
    VB_FILE_SELECT_DRAW_DEATHS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*FileChooseContext`
    VB_FILE_SELECT_DRAW_HEARTS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*FileChooseContext`
    // - `s16`
    // - `u8`
    VB_FILE_SELECT_DRAW_QUEST_ITEMS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*FileChooseContext`
    VB_FILE_SELECT_DRAW_FILE_INFO_BOX,

    // #### `result`
    // ```c
    // Actor_GetCollidedExplosive(play, &this->collider.base) != NULL
    // ```
    // #### `args`
    // - `*BgHidanKowarerukabe`
    VB_FIRE_TEMPLE_BOMBABLE_WALL_BREAK,

    // #### `result`
    // ```c
    // this->timer > 0
    // ```
    // #### `args`
    // - None
    VB_FISH_TIMER_TICK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    // - `*Color_RGB8`
    VB_APPLY_TUNIC_COLOR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*int16_t` // pauseCtx->namedItem
    VB_DRAW_CUSTOM_ITEM_NAME,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*PlayState`
    // - `uint16_t` (cursorSlot - promoted from `u16`)
    // - `uint16_t` (cursorItem - promoted from `u16`)
    VB_EQUIP_ITEM_TO_C_BUTTON,

    // #### `result`
    // ```c
    // (
    //     (
    //         (commonType + FIDGET_SWORD_SWING != FIDGET_SWORD_SWING) &&
    //         (commonType + FIDGET_SWORD_SWING != FIDGET_ADJUST_SHIELD)
    //     ) ||
    //     (
    //         (player->rightHandType == PLAYER_MODELTYPE_RH_SHIELD) &&
    //         (
    //             (commonType + FIDGET_SWORD_SWING == FIDGET_ADJUST_SHIELD) ||
    //             (Player_GetMeleeWeaponHeld2(player) != 0)
    //         )
    //     )
    // )
    // ```
    // #### `args`
    // - `Player*`
    // - `s32` commonType
    VB_SET_IDLE_ANIM,

    // #### `result`
    // ```c
    // player->unk_6A0 > 4000000.0f
    // ```
    // #### `args`
    // - `*Player`
    // - `double` (temp - promoted from `f32`)
    VB_RUMBLE_FOR_SECRET,

    // #### `result`
    // ```c
    // false
    // ```
    // #### `args`
    // - None
    VB_TOGGLE_Z_TARGET_SWITCH_DIRECTION,

    // #### `result`
    // ```c
    // !usingHoldTargeting
    // ```
    // #### `args`
    // - `int32_t` (usingHoldTargeting - promoted from `s32`)
    VB_TOGGLE_Z_TARGET_SWITCH_TARGETS,

    // #### `result`
    // ```c
    // (uint8_t)font->msgBuf[msgCtx->msgBufPos + 1] >= ITEM_CUSTOM
    // ```
    // #### `args`
    // - uint8_t (sDisplayNextMessageAsEnglish)
    VB_LOAD_ITEM_ICON,

    // #### `result`
    // ```c
    // itemId < ITEM_CUSTOM
    // ```
    // #### `args`
    // - `Gfx**`
    VB_DRAW_ITEM_ICON,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*ActorContext`
    // - `*ActorEntry`
    // - `*PlayState`
    // - `**Actor`
    VB_SPAWN_ACTOR_ENTRY,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*PlayState`
    // - `*Vec3f`
    // - `double` (promoted from `f32`)
    // - `double` (promoted from `f32`)
    // - `double` (promoted from `f32`)
    VB_ADULT_ZELDA_SPAWN_STALFOS_IN_COLLAPSE,

    // #### `result`
    // ```c
    // !(this->dyna.actor.flags & ACTOR_FLAG_INSIDE_CULLING_VOLUME)
    // ```
    // #### `args`
    // - `*EnBlkobj`
    // - `*PlayState`
    VB_BLKOBJ_SPAWN_DARK_LINK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgHakaTubo`
    // - `*PlayState`
    VB_HAKA_TUBO_SPAWN_KEESE,

    // #### `result`
    // ```c
    // !IS_DAY && play->sceneNum == SCENE_GRAVEYARD
    // ```
    // #### `args`
    // - `*BgHaka`
    // - `*PlayState`
    VB_HAKA_SPAWN_POE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnVali`
    // - `*PlayState`
    VB_BIRI_SPAWN_JELLYFISH_UPON_DEATH,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*EnEncount1`
    // - `*PlayState`
    // - `s16`
    // - `Vec3f`
    // - `s16`
    VB_ENCOUNT1_SPAWN_STALCHILD_OR_WOLFOS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgMoriBigst`
    // - `*PlayState`
    VB_MORI_BIGST_SUMMON_STALFOS_PAIR,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Actor`
    VB_AFTER_ACTOR_UPDATE_BGCHECKINFO,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgHakaHuta`
    // - `*PlayState`
    VB_HAKA_HUTA_SPAWN_KEESE,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*BgHakaHuta`
    // - `*PlayState`
    VB_HAKA_HUTA_SPAWN_REDEAD,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*int32_t (camId)`
    VB_SHOULD_LOAD_BG_IMAGE,

    // #### `result`
    // ```c
    // this->actor.floorHeight <= -10000.0f
    // ```
    // #### `args`
    // - `*EnItem00`
    VB_ITEM00_KILL,

    // #### `result`
    // ```c
    // interruptResult == PLAYER_INTERRUPT_NEW_ACTION
    // ```
    // #### `args`
    // - `*u8 (&player->unk_6AD)`
    VB_INTERRUPT_LADDER_DISMOUNT,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - none
    VB_ITEMSHIELD_DRAW,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `*Player`
    VB_INIT_HOOKSHOT_IA,

    // #### `result`
    // ```c
    // !(this->stateFlags1 & PLAYER_STATE1_ON_HORSE) && Player_HoldsHookshot(this)
    // ```
    // #### `args`
    // - `s16* (&this->actor.parent->id)`
    VB_PREVENT_HOOKSHOT_PARENT_SOFTLOCK,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - none
    VB_PUTAWAY_BECAUSE_DISABLED_ITEM_BUTTONS,

    // #### `result`
    // ```c
    // true
    // ```
    // #### `args`
    // - `s32* i` (button index)
    // - `Player*`
    // - `s32* item`
    VB_OVERRIDE_BUTTON_ITEM_USED,

    // #### `result`
    // ```c
    // true if Goron Link is talking
    // ```
    // #### `args`
    // - `*EnGo2` (Goron Link)
    VB_PREVENT_GORON_LINK_SOFTLOCK,

    // #### `result`
    // ```c
    // play->interfaceCtx.hbaAmmo == 0
    // ```
    // Prevent custom fanfares set to loop from softlocking Horseback Archery by
    // letting players escape the cutscene with A/B/start after a normal number of playframes.
    // #### `args`
    // - none
    VB_PREVENT_HBA_FANFARE_SOFTLOCK_TIMER,

    // #### `result`
    // ```c
    // (isFanfarePlaying != 1 && gSaveContext.minigameState != 3)
    // ```
    // Prevent custom fanfares set to loop from softlocking Horseback Archery by
    // letting players escape the cutscene with A/B/start after a normal number of playframes.
    // #### `args`
    // - `EnHorse*`
    VB_PREVENT_HBA_FANFARE_SOFTLOCK_BUTTONS,

    // #### `result`
    // ```c
    // sets `camMode` to new mode if applicable
    // ```
    // #### `args`
    // - `s32` player->heldItemAction
    // - `s32*` camMode
    VB_CHANGE_AIMING_CAMERA,

    // true
    // ```
    // #### `args`
    // - `*EnPeehat`
    // - `*PlayState`
    VB_PEEHAT_SPAWN_LARVAS,

    // #### `result`
    // ```c
    // gSaveContext.equips.buttonItems[0] != ITEM_NONE
    // ```
    // Whether the B button slot should be treated as holding an item when entering the
    // horseback/minigame "temporary B" force path. Rando returns `true` for a swordless
    // player so the swordless-on-Epona item glitch can be blocked.
    // #### `args`
    // - `*PlayState`
    VB_TEMP_B_TREAT_AS_OCCUPIED,

    // #### `result`
    // ```c
    // true
    // ```
    // Side-effect hook (return value ignored): fired right after the vanilla
    // `buttonStatus[0] = buttonItems[0]` stash so rando can relocate it to its swordless
    // sentinel for later restoration.
    // #### `args`
    // - `*PlayState`
    VB_TEMP_B_STASH_SWORDLESS,

    // #### `result`
    // ```c
    // (gSaveContext.equips.buttonItems[0] != ITEM_NONE) || (gSaveContext.infTable[29] == 0)
    // ```
    // Whether the "temporary B" item should be restored to the B button. Rando also returns
    // `true` when it had stashed a swordless sentinel.
    // #### `args`
    // - None
    VB_TEMP_B_SHOULD_RESTORE,

    // #### `result`
    // ```c
    // true
    // ```
    // Side-effect hook (return value ignored): fired right after the vanilla
    // `buttonItems[0] = buttonStatus[0]` restore so rando can convert its swordless sentinel
    // back into an empty (swordless) B button.
    // #### `args`
    // - None
    VB_TEMP_B_RESTORE_SWORDLESS,

    // #### `result`
    // ```c
    // true
    // // ```
    // Hook to override the save menu for a message box allowing you to
    // Continue, Reset, and Reset to Spawn after saving (only from the pause menu, not the
    // game over screen).
    // #### `args`
    // - `*PlayState`
    VB_LOAD_SAVE_MENU,

    // #### `result`
    // ```c
    // pauseCtx->state == 7
    // ```
    // Hook to override the drawing/loading textures for the save menu so that
    // a textbox can be rendered instead. Pause screen only, Game Over version left
    // intact.
    VB_DRAW_SAVE_MENU,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether the chest game shopkeeper wipes the scene's chest flags and keys on spawn.
    // #### `args`
    // - `*EnTakaraMan`
    VB_TAKARA_MAN_RESET_CHESTS_AND_KEYS,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether the chest game shopkeeper hands over a small key after being paid.
    // #### `args`
    // - `*EnTakaraMan`
    VB_TAKARA_MAN_OFFER_GET_ITEM,

    // #### `result`
    // ```c
    // Rand_ZeroFloat(1.99f) < 1.0f
    // ```
    // Whether the chest game swaps which side of the room holds the key chest.
    // #### `args`
    // - `*EnChanger`
    VB_EN_CHANGER_SWAP_CHESTS,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether opening a chest sets its treasure flag.
    // #### `args`
    // - `*EnBox`
    VB_CHEST_SET_TREASURE_FLAG,

    // #### `result`
    // ```c
    // Flags_GetTreasure(play, this->dyna.actor.params & 0x1F)
    // ```
    // Whether a chest counts as already opened.
    // #### `args`
    // - `*EnBox`
    VB_CHEST_CONSIDER_CHEST_OPEN,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether NPCs give their mask reaction text for the mask being worn.
    // #### `args`
    // - `u8 currentMask`
    VB_NPC_REACT_TO_MASK,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether a trade item button gets greyed out while trade items are restricted.
    // #### `args`
    // - `u8 item`
    VB_DISABLE_TRADE_ITEM_BUTTON,

    // #### `result`
    // ```c
    // true
    // ```
    // Movement speed for the "Move in first person" setting, multiplied in place.
    // #### `args`
    // - `*Player`
    // - `f32*` movementSpeed
    VB_PLAYER_MODIFY_FIRST_PERSON_SPEED,

    // #### `result`
    // ```c
    // true
    // ```
    // Whether the market night guard goes back to idle once talked to, rather than
    // a hook taking over his action func.
    // #### `args`
    // - `*EnHeishi4`
    // - `*PlayState`
    VB_MARKET_NIGHT_GUARD_SET_ACTION_AFTER_TALK,

    // #### `result`
    // ```c
    // ageReq == AGE_REQ_NONE || ageReq == gSaveContext.linkAge
    // ```
    // Whether the player is the right age for something age gated.
    // #### `args`
    // - `u8 ageReq` an `AGE_REQ_*`, which for adult and child is the matching `LINK_AGE_*`
    VB_PLAYER_MEETS_AGE_REQ,

    // #### `result`
    // ```c
    // gItemAgeReqs[itemIndex] == AGE_REQ_NONE || gItemAgeReqs[itemIndex] == gSaveContext.linkAge
    // ```
    // Whether the player is the right age to hold an item.
    // #### `args`
    // - `u8 itemIndex`
    VB_ITEM_MEETS_AGE_REQ,

    // #### `result`
    // ```c
    // gSlotAgeReqs[slotIndex] == AGE_REQ_NONE || gSlotAgeReqs[slotIndex] == gSaveContext.linkAge
    // ```
    // Whether the player is the right age to use an inventory slot.
    // #### `args`
    // - `u8 slotIndex`
    VB_SLOT_MEETS_AGE_REQ,

    // #### `result`
    // ```c
    // this->currentMask != PLAYER_MASK_NONE
    // ```
    // Whether a worn mask comes off once it's no longer on a button.
    // #### `args`
    // - `*Player`
    VB_PLAYER_UNEQUIP_MASK_WITHOUT_BUTTON,
} GIVanillaBehavior;
