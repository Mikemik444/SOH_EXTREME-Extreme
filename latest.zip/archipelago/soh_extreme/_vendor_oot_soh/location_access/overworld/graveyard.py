from ...LogicHelpers import *

if TYPE_CHECKING:
    from ... import SohWorld


class EventLocations(StrEnum):
    GRAVEYARD_BUTTERFLY_FAIRY = "Graveyard Butterfly Fairy"
    GRAVEYARD_BEAN_PLANT_FAIRY = "Graveyard Bean Plant Fairy"
    GRAVEYARD_BUG_ROCK = "Graveyard Bug Rock"
    GRAVEYARD_SOLD_SPOOKY_MASK = "Graveyard Sold Spooky Mask"
    GRAVEYARD_DAMPES_GRAVE_NUT_POT = "Graveyard Dampes Grave Nut Pot"
    GRAVEYARD_DAMPES_WINDMILL_ACCESS = "Graveyard Dampes Windmill Access"
    GRAVEYARD_GOSSIP_STONE_SONG_FAIRY = "Graveyard Gossip Stone Song Fairy"
    GRAVEYARD_BEAN_PATCH = "Graveyard Bean Patch"


class LocalEvents(StrEnum):
    ACCESS_TO_WINDMILL_FROM_DAMPES_GRAVE = "Access to Windmill From Dampes Grave"
    GRAVEYARD_BEAN_PLANTED = "Graveyard Bean Planted"


def can_reach_graveyard_crate(bundle):
    # Bean ownership alone is not a planted platform: the event carries child
    # access, usable beans and the patch's soul. Longshot and the adult Feather
    # jump are independent approaches; all still need to break the crate.
    return ((is_adult(bundle) & (has_item(LocalEvents.GRAVEYARD_BEAN_PLANTED, bundle)
                                | can_use(Items.ROCS_FEATHER, bundle)))
            | can_use(Items.LONGSHOT, bundle)) & can_break_crates(bundle)


def set_region_rules(world: "SohWorld") -> None:
    # The Graveyard
    # Events
    add_events(Regions.THE_GRAVEYARD, world, [
        (EventLocations.GRAVEYARD_BUTTERFLY_FAIRY, Events.CAN_ACCESS_FAIRIES,
         lambda bundle: can_use(Items.STICKS, bundle) & at_day(bundle)),
        (EventLocations.GRAVEYARD_BEAN_PLANT_FAIRY, Events.CAN_ACCESS_FAIRIES, lambda bundle: is_child(
            bundle) & can_use(Items.MAGIC_BEAN, bundle) & can_use(Items.SONG_OF_STORMS, bundle)),
        (EventLocations.GRAVEYARD_BUG_ROCK,
         Events.CAN_ACCESS_BUGS, lambda bundle: True_()),
        (EventLocations.GRAVEYARD_SOLD_SPOOKY_MASK, Events.SOLD_SPOOKY_MASK, lambda bundle: is_child(bundle) & at_day(
            bundle) & has_item(Events.CAN_BORROW_SPOOKY_MASK, bundle) & has_item(Items.CHILD_WALLET, bundle)),
        (EventLocations.GRAVEYARD_BEAN_PATCH, LocalEvents.GRAVEYARD_BEAN_PLANTED,
         lambda bundle: is_child(bundle) & can_use(Items.MAGIC_BEAN, bundle)),
    ])
    # Locations
    add_locations(Regions.THE_GRAVEYARD, world, [
        (Locations.GRAVEYARD_FREESTANDING_POH, lambda bundle: can_reach_graveyard_crate(bundle) | (can_do_trick(Tricks.GY_POH, bundle) & can_use(Items.BOOMERANG, bundle))),
        (Locations.GRAVEYARD_DAMPE_GRAVEDIGGING_TOUR, lambda bundle: has_item(
            Items.CHILD_WALLET, bundle) & is_child(bundle) & at_clock_window(bundle, 'dampe')),
        (Locations.GRAVEYARD_GS_WALL, lambda bundle: is_child(bundle) & hookshot_or_boomerang(
            bundle) & at_night(bundle) & can_get_nighttime_gs(bundle)),
        (Locations.GRAVEYARD_GS_BEAN_PATCH,
         lambda bundle: can_spawn_soil_skull(bundle) & can_attack(bundle)),
        (Locations.GRAVEYARD_BEAN_SPROUT_FAIRY1, lambda bundle: is_child(bundle) & can_use(
            Items.MAGIC_BEAN, bundle) & can_use(Items.SONG_OF_STORMS, bundle)),
        (Locations.GRAVEYARD_BEAN_SPROUT_FAIRY2, lambda bundle: is_child(bundle) & can_use(
            Items.MAGIC_BEAN, bundle) & can_use(Items.SONG_OF_STORMS, bundle)),
        (Locations.GRAVEYARD_BEAN_SPROUT_FAIRY3, lambda bundle: is_child(bundle) & can_use(
            Items.MAGIC_BEAN, bundle) & can_use(Items.SONG_OF_STORMS, bundle)),
        (Locations.GRAVEYARD_GRASS_1, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_2, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_3, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_4, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_5, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_6, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_7, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_8, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_9, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_10, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_11, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_GRASS_12, lambda bundle: can_collect_grass(bundle)),
        (Locations.GRAVEYARD_FREESTANDING_POH_CRATE, lambda bundle: can_reach_graveyard_crate(bundle))

    ])
    # Connections
    connect_regions(Regions.THE_GRAVEYARD, world, [
        (Regions.GRAVEYARD_SHIELD_GRAVE,
         lambda bundle: can_grab(bundle) & (is_adult(bundle) | at_night(bundle))),
        (Regions.GRAVEYARD_COMPOSERS_GRAVE,
         lambda bundle: can_use(Items.ZELDAS_LULLABY, bundle)),
        (Regions.GRAVEYARD_HEART_PIECE_GRAVE,
         lambda bundle: can_grab(bundle) & (is_adult(bundle) | at_night(bundle))),
        (Regions.GRAVEYARD_DAMPES_GRAVE, lambda bundle: can_grab(bundle) & is_adult(bundle)),
        (Regions.GRAVEYARD_DAMPES_HOUSE, lambda bundle: is_adult(bundle)
         & can_open_overworld_door(Items.DAMPES_HUT_KEY, bundle)),
        (Regions.KAKARIKO_VILLAGE, lambda bundle: True_()),
        (Regions.GRAVEYARD_WARP_PAD_REGION, lambda bundle: False_())
    ])

    # The Graveyard Shield Grave
    # Locations
    add_locations(Regions.GRAVEYARD_SHIELD_GRAVE, world, [
        (Locations.GRAVEYARD_SHIELD_GRAVE_CHEST, lambda bundle: True_())
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_SHIELD_GRAVE, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_()),
        (Regions.GRAVEYARD_SHIELD_GRAVE_BACK,
         lambda bundle: can_break_mud_walls(bundle))
    ])

    # The Graveyard Shield Grave Back
    # Locations
    add_locations(Regions.GRAVEYARD_SHIELD_GRAVE_BACK, world, [
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY1, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY2, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY3, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY4, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY5, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY6, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY7, lambda bundle: True_()),
        (Locations.GRAVEYARD_SHIELD_GRAVE_FAIRY8, lambda bundle: True_())
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_SHIELD_GRAVE_BACK, world, [
        (Regions.GRAVEYARD_SHIELD_GRAVE, lambda bundle: True_())
    ])

    # The Graveyard Heart Piece Grave
    # Locations
    add_locations(Regions.GRAVEYARD_HEART_PIECE_GRAVE, world, [
        (Locations.GRAVEYARD_HEART_PIECE_GRAVE_CHEST,
         lambda bundle: can_use(Items.SUNS_SONG, bundle))
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_HEART_PIECE_GRAVE, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_())
    ])

    # The Graveyard Composers Grave
    # Locations
    add_locations(Regions.GRAVEYARD_COMPOSERS_GRAVE, world, [
        (Locations.GRAVEYARD_ROYAL_FAMILYS_TOMB_CHEST,
         lambda bundle: has_fire_source(bundle)),
        (Locations.SONG_FROM_ROYAL_FAMILYS_TOMB,
         lambda bundle: can_use_projectile(bundle) | can_jump_slash(bundle)),
        (Locations.GRAVEYARD_ROYAL_FAMILYS_TOMB_SUNS_SONG_FAIRY,
         lambda bundle: can_use(Items.SUNS_SONG, bundle))
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_COMPOSERS_GRAVE, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_())
    ])

    # The Graveyard Dampes Grave
    # Events
    add_events(Regions.GRAVEYARD_DAMPES_GRAVE, world, [
        (EventLocations.GRAVEYARD_DAMPES_GRAVE_NUT_POT,
         Events.CAN_FARM_NUTS, lambda bundle: True_()),
        (EventLocations.GRAVEYARD_DAMPES_WINDMILL_ACCESS, Events.DAMPES_WINDMILL_ACCESS,
         lambda bundle: is_adult(bundle) & can_use(Items.SONG_OF_TIME, bundle) & can_interact_npc(bundle, "Hylian"))
    ])
    # Locations
    add_locations(Regions.GRAVEYARD_DAMPES_GRAVE, world, [
        (Locations.GRAVEYARD_HOOKSHOT_CHEST, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPE_RACE_FREESTANDING_POH, lambda bundle: is_adult(
            bundle) | can_do_trick(Tricks.GY_CHILD_DAMPE_RACE_POH, bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT1,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT2,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT3,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT4,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT5,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_POT6,
         lambda bundle: can_break_pots(bundle)),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE1, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE2, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE3, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE4, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE5, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE6, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE7, lambda bundle: True_()),
        (Locations.GRAVEYARD_DAMPES_GRAVE_RUPEE8, lambda bundle: True_())
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_DAMPES_GRAVE, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_()),
        (Regions.KAK_WINDMILL, lambda bundle: can_interact_npc(bundle, "Hylian") & (
            (is_adult(bundle) & can_use(Items.SONG_OF_TIME, bundle)) | (is_child(bundle) & can_ground_jump(bundle))))
    ])

    # The Graveyard Dampes House
    # Connections
    connect_regions(Regions.GRAVEYARD_DAMPES_HOUSE, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_())
    ])

    # The Graveyard Warp Pad Region
    # Events
    add_events(Regions.GRAVEYARD_WARP_PAD_REGION, world, [
        (EventLocations.GRAVEYARD_GOSSIP_STONE_SONG_FAIRY, Events.CAN_ACCESS_FAIRIES,
         lambda bundle: call_gossip_fairy_except_suns(bundle))
    ])
    # Locations
    add_locations(Regions.GRAVEYARD_WARP_PAD_REGION, world, [
        (Locations.GRAVEYARD_GOSSIP_STONE_FAIRY,
         lambda bundle: call_gossip_fairy_except_suns(bundle)),
        (Locations.GRAVEYARD_GOSSIP_STONE_BIG_FAIRY,
         lambda bundle: can_use(Items.SONG_OF_STORMS, bundle))
    ])
    # Connections
    connect_regions(Regions.GRAVEYARD_WARP_PAD_REGION, world, [
        (Regions.THE_GRAVEYARD, lambda bundle: True_()),
        (Regions.SHADOW_TEMPLE_ENTRYWAY, lambda bundle: can_use(Items.DINS_FIRE, bundle) | (can_do_trick(
            Tricks.GY_SHADOW_FIRE_ARROWS, bundle) & is_adult(bundle) & can_use(Items.FIRE_ARROW, bundle)))
    ])
