from dataclasses import dataclass, fields
from Options import Toggle, Choice, Range, OptionGroup, OptionSet
from ._vendor_oot_soh.Options import SohOptions, soh_option_groups
from .EntranceOptions import *
from .SongNotes import SONG_NOTE_KEYS, normalize_song_selection

class ShuffleRoll(Toggle):
    """Shuffle the ability to roll."""
    display_name = "Shuffle Roll"

class ShuffleGrab(Toggle):
    """Shuffle Link's basic grab/lift ability (Power Bracelet tier)."""
    display_name = "Shuffle Grab / Power Bracelet"

class ShuffleClimb(Toggle):
    """Shuffle the ability to climb climbable surfaces."""
    display_name = "Shuffle Climb"

class ShuffleCrawl(Toggle):
    """Shuffle the ability to crawl through crawlspaces."""
    display_name = "Shuffle Crawl"

class ShuffleSpeak(Choice):
    """Speech ability: one shared Speak item or one item per language."""
    display_name = "Shuffle Speak"
    option_off = 0
    option_on = 1
    option_individual_languages = 2
    default = 0

class ShuffleOpenChest(Choice):
    """Shuffle chest-opening ability. Progressive requires a second copy for large chests."""
    display_name = "Shuffle Open Chest"
    option_off = 0
    option_on = 1
    option_progressive = 2
    default = 0

class ShuffleEnemyDrops(Toggle):
    """The first defeat of each finite vanilla enemy placement is an Archipelago check.

    Every placed enemy instance has its own persistent check. Re-killing the same
    placement cannot resend it; ordinary native randomized drops continue normally
    after that placement's AP check is complete.
    """
    display_name = "Shuffle Enemy Drops"

class ShuffleEnemySoul(Choice):
    display_name = "Shuffle Enemy Soul"
    option_off = 0
    option_all_enemies_as_1 = 1
    option_individual_enemies = 2
    default = 0

class EnemySoulBehavior(Choice):
    display_name = "Enemy Soul Locked Behavior"
    option_gone_until_found = 0
    option_invincible_until_found = 1
    default = 0
class ShuffleNpcSoul(Toggle):
    display_name = "Shuffle NPC Soul"
class ShuffleAnimalSoul(Choice):
    display_name = "Shuffle Animal Soul"
    option_off = 0
    option_all_animals_as_1 = 1
    option_individual_animals = 2
    default = 0
class ShufflePotSoul(Toggle):
    display_name = "Shuffle Pot Soul"
class ShuffleCrateSoul(Toggle):
    display_name = "Shuffle Crate Soul"
class ShuffleGrassBushSoul(Toggle):
    display_name = "Shuffle Grass / Bush Soul"
class ShuffleRockBoulderSoul(Toggle):
    display_name = "Shuffle Rock / Boulder Soul"
class ShuffleTreeSoul(Toggle):
    display_name = "Shuffle Tree Soul"
class ShuffleBeehiveSoul(Toggle):
    display_name = "Shuffle Beehive Soul"
class ShuffleSignSoul(Toggle):
    display_name = "Shuffle Sign Soul"
class ShuffleSkulltulaSoul(Toggle):
    display_name = "Shuffle Skulltula Soul"
class ShuffleBusinessScrubSoul(Toggle):
    display_name = "Shuffle Scrub Soul"
class ShuffleShovel(Toggle):
    display_name = "Shuffle Shovel"
class ShuffleBeanSouls(Toggle):
    """Shuffle the ten native per-area Bean Souls."""
    display_name = "Shuffle Bean Souls"
class SceneTransitionChecks(Toggle):
    """First use of each directed scene entrance/exit and dungeon room door is a check.

    Entering and leaving are separate checks; one-way passages have only one.
    Repeat visits do not award more
    checks. Save loads, deaths, void-outs, and ordinary logical region changes
    do not count. Requires a new seed and the matching native client.
    """
    display_name = "Scene Transition Checks"
    default = 0

class NpcSpeechSanity(Toggle):
    """The first conversation with each catalogued NPC is an Archipelago check.
    Later conversations behave normally. Moving characters and transformed
    versions share one check; a shopkeeper has one check, not one per shelf.
    NPC Soul, the NPC's language, and physical access apply when shuffled.
    Changing this option or upgrading a legacy speech seed requires generation
    with the matching APWorld; a client update cannot add server locations.
    """
    display_name = "NPC Speech Sanity"

class SongNoteShuffle(Choice):
    """Split the songs selected by Song Note Songs into Progressive song items.

    Collect the required copies of Progressive [Song]: 6 for most songs,
    8 for Bolero, 5 for Serenade, and 7 for Nocturne. Playing still requires
    an Ocarina and its shuffled buttons. Selected songs' notes use the normal
    item pool; unselected songs keep the ordinary Shuffle Songs placement mode.
    Starting with a selected song grants its complete note group. Selecting
    all splits all twelve songs into the existing 74 Progressive song copies.
    """
    display_name = "Song Note Shuffle"
    option_off = 0
    option_individual_notes = 1
    default = 0

class SongNoteSongs(OptionSet):
    """Songs to split when Song Note Shuffle is Individual Notes.

    Use all for every song, or a list of song names. Accepted keys:
    zeldas_lullaby, eponas_song, sarias_song, suns_song, song_of_time,
    song_of_storms, minuet_of_forest, bolero_of_fire, serenade_of_water,
    requiem_of_spirit, nocturne_of_shadow, prelude_of_light.
    Full names such as Zelda's Lullaby are also accepted. Unselected songs
    remain complete songs; an empty list splits none. This list is ignored
    when Song Note Shuffle is off. All overrides any additional listed songs.
    """
    display_name = "Song Note Songs"
    valid_keys = frozenset({"all", *SONG_NOTE_KEYS})
    default = frozenset({"all"})

    def __init__(self, value, random_str=None):
        super().__init__(normalize_song_selection(value), random_str)


class ShuffleFlowOfTime(Toggle):
    """Freeze normal time progression until Flow of Time is collected.

    Sun's Song can still select day or night when it can be played. Time stays
    at the selected phase until Flow of Time is found.
    """
    display_name = "Shuffle Flow of Time"

class FrozenStartingTime(Choice):
    display_name = "Frozen Starting Time"
    # "random" is reserved by Archipelago's Choice metaclass. Keep the
    # native zero sentinel under a valid name, accepting legacy YAML below.
    option_randomized = 0
    option_dawn = 1
    option_day = 2
    option_dusk = 3
    option_night = 4
    default = 0

    @classmethod
    def from_text(cls, text: str):
        if text.lower() == "random":
            return cls(cls.option_randomized)
        return super().from_text(text)

class TimeSpeedAfterUnlock(Choice):
    display_name = "Time Speed After Unlock"
    option_normal = 0
    option_2x = 1
    option_3x = 2
    option_4x = 3
    default = 0

class DeathLink(Toggle):
    """Send your deaths to other DeathLink players and receive theirs."""
    display_name = "Death Link"

class TrapLink(Toggle):
    """Share received traps with other players using the Archipelago TrapLink protocol."""
    display_name = "Trap Link"

class ExtremeTrapPool(Choice):
    display_name = "Extreme Trap Pool"
    option_off = 0
    option_ice_only = 1
    option_expanded = 2
    default = 0
class ExtremeIceTraps(Toggle):
    display_name = "Extreme Ice Traps"
class ExtremeFireTraps(Toggle):
    display_name = "Extreme Fire Traps"
class ExtremeSlowTraps(Toggle):
    display_name = "Extreme Slow Traps"
class ExtremeMagicSuckTraps(Toggle):
    display_name = "Extreme Magic Suck Traps"
class ExtremeHealthDrainTraps(Toggle):
    display_name = "Extreme Health Drain Traps"
class ExtremeTrapFillerReplacement(Range):
    display_name = "Extreme Trap Filler Replacement %"
    range_start = 0
    range_end = 100
    default = 0


# Native location families added by the SOH-EXTREME Ship fork but not present in
# the stock Archipelago-SoH option dataclass.  These are first-class AP options
# so an AP save never inherits an invisible local randomizer value.
class ShuffleRocks(Toggle):
    display_name = "Shuffle Rocks"
class ShuffleBoulders(Choice):
    display_name = "Shuffle Boulders"
    option_off = 0
    option_dungeons = 1
    option_overworld = 2
    option_all = 3
    default = 0
class ShuffleBushes(Toggle):
    display_name = "Shuffle Bushes"
class ShuffleIcicles(Toggle):
    display_name = "Shuffle Icicles / Stalagmites"
class ShuffleRedIce(Toggle):
    display_name = "Shuffle Red Ice"
class ShuffleSigns(Choice):
    display_name = "Shuffle Signs"
    option_off = 0
    option_dungeons = 1
    option_overworld = 2
    option_all = 3
    default = 0
class ShuffleBeggar(Toggle):
    display_name = "Shuffle Market Beggar"
class ShuffleChestMinigame(Toggle):
    display_name = "Shuffle Treasure Chest Game"
class ShuffleWonderItems(Choice):
    display_name = "Shuffle Wonder Items"
    option_off = 0
    option_dungeons = 1
    option_overworld = 2
    option_all = 3
    default = 0
class ShuffleSilver(Choice):
    display_name = "Shuffle Silver Rupees"
    option_off = 0
    option_on = 1
    option_wallet = 2
    option_start_with = 3
    default = 0
class ShuffleButterflyFairies(Toggle):
    display_name = "Shuffle Butterfly Fairies"

@dataclass
class SohExtremeOptions(SohOptions):
    shuffle_overworld_entrances: ShuffleOverworldEntrances
    shuffle_interior_entrances: ShuffleInteriorEntrances
    shuffle_dungeon_entrances: ShuffleDungeonEntrances
    shuffle_grotto_entrances: ShuffleGrottoEntrances
    shuffle_boss_entrances: ShuffleBossEntrances
    shuffle_one_way_entrances: ShuffleOneWayEntrances
    shuffle_owl_drops: ShuffleOwlDrops
    shuffle_warp_songs: ShuffleWarpSongs
    shuffle_child_spawn: ShuffleChildSpawn
    shuffle_adult_spawn: ShuffleAdultSpawn
    shuffle_dungeon_doors: ShuffleDungeonDoors
    mixed_entrance_pools: MixedEntrancePools
    shuffle_rocks: ShuffleRocks
    shuffle_boulders: ShuffleBoulders
    shuffle_bushes: ShuffleBushes
    shuffle_icicles: ShuffleIcicles
    shuffle_red_ice: ShuffleRedIce
    shuffle_signs: ShuffleSigns
    shuffle_beggar: ShuffleBeggar
    shuffle_chest_minigame: ShuffleChestMinigame
    shuffle_wonder_items: ShuffleWonderItems
    shuffle_silver: ShuffleSilver
    shuffle_butterfly_fairies: ShuffleButterflyFairies
    shuffle_roll: ShuffleRoll
    shuffle_grab: ShuffleGrab
    shuffle_climb: ShuffleClimb
    shuffle_crawl: ShuffleCrawl
    shuffle_speak: ShuffleSpeak
    shuffle_open_chest: ShuffleOpenChest
    shuffle_enemy_drops: ShuffleEnemyDrops
    shuffle_enemy_soul: ShuffleEnemySoul
    enemy_soul_behavior: EnemySoulBehavior
    shuffle_npc_soul: ShuffleNpcSoul
    shuffle_animal_soul: ShuffleAnimalSoul
    shuffle_pot_soul: ShufflePotSoul
    shuffle_crate_soul: ShuffleCrateSoul
    shuffle_grass_bush_soul: ShuffleGrassBushSoul
    shuffle_rock_boulder_soul: ShuffleRockBoulderSoul
    shuffle_tree_soul: ShuffleTreeSoul
    shuffle_beehive_soul: ShuffleBeehiveSoul
    shuffle_sign_soul: ShuffleSignSoul
    shuffle_skulltula_soul: ShuffleSkulltulaSoul
    shuffle_business_scrub_soul: ShuffleBusinessScrubSoul
    shuffle_shovel: ShuffleShovel
    shuffle_bean_souls: ShuffleBeanSouls
    scene_transition_checks: SceneTransitionChecks
    npc_speech_sanity: NpcSpeechSanity
    song_note_shuffle: SongNoteShuffle
    song_note_songs: SongNoteSongs
    shuffle_flow_of_time: ShuffleFlowOfTime
    frozen_starting_time: FrozenStartingTime
    time_speed_after_unlock: TimeSpeedAfterUnlock
    death_link: DeathLink
    trap_link: TrapLink
    extreme_trap_pool: ExtremeTrapPool
    extreme_ice_traps: ExtremeIceTraps
    extreme_fire_traps: ExtremeFireTraps
    extreme_slow_traps: ExtremeSlowTraps
    extreme_magic_suck_traps: ExtremeMagicSuckTraps
    extreme_health_drain_traps: ExtremeHealthDrainTraps
    extreme_trap_filler_replacement: ExtremeTrapFillerReplacement

# SohWebWorld has already been created by the time this module is imported.
# Archipelago's WebWorld metaclass mutates soh_option_groups in-place by adding
# the common "Item & Location Options" group. Reusing that injected group in a
# second WebWorld causes a duplicate-options assertion, so copy only SoH's
# game-specific groups. Archipelago will inject the common group for this world.
_base_option_groups = [group for group in soh_option_groups if group.name != "Item & Location Options"]

extreme_option_groups = list(_base_option_groups) + [
    ENTRANCE_GROUP,
    OptionGroup("SOH-EXTREME Fork Location Shuffles", [
        ShuffleRocks, ShuffleBoulders, ShuffleBushes, ShuffleIcicles, ShuffleRedIce,
        ShuffleSigns, ShuffleBeggar, ShuffleChestMinigame, ShuffleWonderItems,
        ShuffleSilver, ShuffleButterflyFairies,
    ]),
    OptionGroup("SOH-EXTREME Abilities & Souls", [
        ShuffleRoll, ShuffleGrab, ShuffleClimb, ShuffleCrawl, ShuffleSpeak, ShuffleOpenChest,
        ShuffleEnemySoul, EnemySoulBehavior, ShuffleNpcSoul, ShuffleAnimalSoul, ShufflePotSoul, ShuffleCrateSoul,
        ShuffleGrassBushSoul, ShuffleRockBoulderSoul, ShuffleTreeSoul, ShuffleBeehiveSoul,
        ShuffleSignSoul, ShuffleSkulltulaSoul, ShuffleBusinessScrubSoul, ShuffleShovel, ShuffleBeanSouls,
    ]),
    OptionGroup("SOH-EXTREME World Features", [
        ShuffleEnemyDrops, SceneTransitionChecks, NpcSpeechSanity, SongNoteShuffle, SongNoteSongs, ShuffleFlowOfTime, FrozenStartingTime, TimeSpeedAfterUnlock,
    ]),
    OptionGroup("SOH-EXTREME Traps & Links", [
        DeathLink, TrapLink, ExtremeTrapPool, ExtremeIceTraps, ExtremeFireTraps, ExtremeSlowTraps,
        ExtremeMagicSuckTraps, ExtremeHealthDrainTraps, ExtremeTrapFillerReplacement,
    ]),
]


# Archipelago's template generator reads options_dataclass. Because this dataclass
# subclasses the official SoH SohOptions dataclass, every stock SoH 1.4.2 option
# remains present in generated templates. Fail loudly if that ever stops being true.
_BASE_OPTION_NAMES = {field.name for field in fields(SohOptions)}
_EXTREME_OPTION_NAMES = {field.name for field in fields(SohExtremeOptions)} - _BASE_OPTION_NAMES
_missing_base_options = _BASE_OPTION_NAMES - {field.name for field in fields(SohExtremeOptions)}
if _missing_base_options:
    raise RuntimeError(
        "SOH-EXTREME lost inherited Ship of Harkinian options: "
        + ", ".join(sorted(_missing_base_options))
    )
