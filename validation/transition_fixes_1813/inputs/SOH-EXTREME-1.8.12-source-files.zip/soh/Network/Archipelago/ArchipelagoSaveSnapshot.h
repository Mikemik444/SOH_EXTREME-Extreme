#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include "SaveConnectionIdentity.h"

// Copied with SaveContext on the game thread, then owned by one save job.
// A writer must never pair old inventory with a newer live AP receipt cursor.
struct ArchipelagoSaveSnapshot {
    bool active = false;
    uint64_t receivedItemCount = 0;
    std::string server;
    std::string slot;
    SohExtreme::SaveConnectionIdentity identity;
    std::string settingsJson;
    // Only item targets from completed hint text, scoped to this save identity.
    std::string revealedHintTargetsJson;
    std::vector<uint64_t> fallbackNpcSpeechHashes;
    std::vector<int64_t> pendingLocations;
};
