#pragma once

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <map>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "TrackerMirror.h"
#include "TrackerWorker.h"
#include "ArchipelagoSaveSnapshot.h"
#include "ArchipelagoHintData.h"


class ArchipelagoClient {
  public:
    static ArchipelagoClient& GetInstance();

    void Enable();
    void Disable();
    void Toggle();
    // Main-thread only. A null result is unknown/stale, not an empty reachable set.
    const SohExtreme::TrackerSnapshot* GetFinderSnapshot(std::string& status);
    void RefreshFinderMirror();
    int32_t AdjustAmmoChange(int32_t item, int32_t currentAmmo, int32_t change) const;
    void ObserveAmmoSource(int32_t randomizerCheck, int32_t actorId, int32_t sourceDropParams,
                           int32_t collectibleInput);
    void RestartFinderWorker();
    const std::string& GetFinderRuntimePath() const;
    int32_t GetFinderNativeCheck(int64_t locationId) const;
    void Update();
    void ReofferPendingPresentation();

    bool IsEnabled() const { return enabled.load(); }
    bool IsAuthenticated() const;
    bool IsConnectionRefused() const;
    std::string GetStatusText() const;
    // Game-thread menu query: reports this save's installed map and fixed spawns.
    std::string GetEntranceStatusText() const;

    void SendLocation(int64_t locationId, bool notifyRemote = false);
    void ReportCheck(int32_t randomizerCheck);
    void ReportNpcSpeech(int32_t randomizerCheck);
    bool ReportNpcSpeechLocation(int64_t speechLocation);
    bool HasSceneTransitionChecks() const;
    void CaptureSceneTransition();
    void CompleteSceneTransition(int16_t scene);
    void BeginDoorTransition(int door, int fromRoom, int toRoom, const struct Actor* actor, int side);
    void AdvanceDoorTransition();
    void ReportTransition(int64_t location);
    bool ReportFallbackNpcSpeech(const struct Actor* actor);
    // Read-only, game-thread draw query; never reports or reserves a check.
    bool ShouldHighlightNpcSpeech(const struct Actor* actor) const;
    void LoadFallbackNpcSpeechHashes(const std::vector<uint64_t>& hashes);
    std::vector<uint64_t> GetFallbackNpcSpeechHashes() const;
    void RegisterHooks();
    bool OwnsCheck(int32_t randomizerCheck);
    bool OwnsCheckCached(int32_t randomizerCheck) const;
    // Build the complete native RC -> active AP location cache for Check Finder.
    // This is intentionally demand-driven so normal save loading stays scene-local.
    bool PrepareCheckFinderMappings();
    bool IsLocationActive(int64_t locationId) const;
    bool IsLocationReported(int64_t locationId) const;
    bool IsLocationSubmitted(int64_t locationId) const;
    void LoadPendingLocations(const std::vector<int64_t>& locations);
    // Game-thread only, paired with the engine's inventory snapshot.
    ArchipelagoSaveSnapshot CaptureSaveSnapshot() const;
    size_t GetActiveLocationCount() const;
    size_t GetReportedActiveLocationCount() const;
    void ApplyScoutedPlacements();
    void RefreshPlacementForCheck(int32_t randomizerCheck);
    int32_t GetLocationDisplayItem(int64_t locationId) const;
    void RefreshPlacementsForScene(int16_t sceneNum);
    void EnsureLocationScouts();
    std::string GetRemoteItemDescription(int32_t randomizerCheck);
    // Game-thread only. No chat commands, hint purchases, or remote scouting.
    std::string GetInGameHint(const std::string& key, int32_t stoneIndex = -1);
    std::string GetHintItemDescription(int32_t randomizerCheck);
    // Game-thread-only provenance, frozen with the text until its final page is drawn.
    // Live hint/scout stores are also game-thread-owned; adjacent text/target
    // getters cannot be interleaved by a network callback or SeedHints update.
    std::vector<SohExtreme::HintTarget> GetHintItemTargets(int32_t randomizerCheck);
    std::vector<SohExtreme::HintTarget> GetInGameHintTargets(const std::string& key, int32_t stoneIndex = -1);
    void RecordRevealedHintTargets(const std::vector<SohExtreme::HintTarget>& targets);
    std::string GetRevealedHintTargetsJson() const;
    bool LoadRevealedHintTargetsJson(const std::string& raw);
    const std::string& GetHintSyncStatus() const { return hintSyncStatus; }
    bool IsReadyForFileSelect() const;
    void ApplySlotSettings();
    void EnforceSlotSettings();
    void ApplyPostInitSlotState();
    void PrimeNewSaveMetadata();
    void PrepareNewSaveItemReplay();
    void BeginFileSelectActivation();
    void EndFileSelectActivation();
    bool IsGameplaySessionActive() const;
    std::vector<std::string> GetChatMessages();
    void SendChatMessage(const std::string& message);
    struct HintInfo {
        std::string item, location, finder, recipient, entrance;
        bool found = false;
    };
    const std::vector<HintInfo>& GetHints() const { return hints; }
    bool HasHintSnapshot() const { return hintSnapshotLoaded; }
    const std::string& GetSongNotePickupDescription() const { return songNotePickupDescription; }
    const std::string& GetRemotePickupDescription() const { return remotePickupDescription; }

    // Per-save Archipelago receipt state.  This is serialized by SaveManager so
    // each save resumes the server ReceivedItems stream at exactly the point
    // represented by that save's inventory.
    void LoadSaveMetadata(bool isArchipelagoSave, uint64_t receivedItemCount, const std::string& server,
                          const std::string& slot, const std::string& cachedSettingsJson,
                          const SohExtreme::SaveConnectionIdentity& identity = {});
    bool IsCurrentSaveArchipelago() const { return currentSaveIsArchipelago; }
    uint64_t GetAppliedItemCount() const { return appliedItemCount; }
    std::string GetSaveServer() const { return saveServer; }
    std::string GetSaveSlot() const { return saveSlot; }
    bool ConnectionSettingsChanged() const;
    bool CanConfirmLegacyReconnect() const;
    void ConfirmLegacyReconnect();
    std::string GetReconnectTarget() const;
    std::string GetCachedSlotSettingsJson() const { return cachedSlotSettingsJson; }

  private:
    ArchipelagoClient() = default;
    ~ArchipelagoClient() = default;
    ArchipelagoClient(const ArchipelagoClient&) = delete;
    ArchipelagoClient& operator=(const ArchipelagoClient&) = delete;

    void DrainMessages();
    void SetConnectionIdentityFromJson(const std::string& raw);
    void ReconcileSaveConnection(bool confirmLegacy = false);
    void ResetRemotePresentations();
    void QueueRemotePresentation(int64_t locationId);
    bool ProcessRemotePresentation();
    SohExtreme::InGameHintData inGameHints;
    std::vector<HintInfo> hints;
    bool hintSnapshotLoaded = false;
    SohExtreme::HintTarget MakeHintTarget(int64_t locationId) const;
    void RebuildHints();
    void ServiceHintBridge();
    mutable std::mutex hintJournalMutex;
    std::map<std::pair<int, int64_t>, SohExtreme::HintTarget> revealedHintTargets;
    std::vector<SohExtreme::ServerHintRecord> serverHintRows;
    std::string pendingHintPayload, hintProducer, hintSyncStatus;
    uint64_t hintRequest = 0, hintRevision = 0;
    double nextHintRequest = 0.0, nextHintPublish = 0.0;
    std::deque<int64_t> remotePresentations;
    std::unordered_set<int64_t> presentedRemoteLocations;
    std::string remotePickupDescription;
    std::string songNotePickupDescription;
    bool remotePresentationActive = false;
    bool remotePresentationReceived = false;
    unsigned remotePresentationFrames = 0;
    void BeginItemReplay();
    void QueueSlotData(const std::string& key, const std::string& raw);
    void DrainSlotData();
    void UpdateGoal();
    void ResetFinderMirror();
    void ServiceFinderWorker();
    SohExtreme::TrackerWorker finderWorker;
    bool finderWorkerStarted = false;
    uint32_t finderWorkerAttempts = 0;
    double finderWorkerNextPoll = 0.0;
    double finderWorkerRetryAt = 0.0;
    std::string finderWorkerError;
    SohExtreme::TrackerMirrorState finderMirror;
    std::string pendingFinderPayload;
    std::string pendingFinderNonce;
    std::string finderMirrorError;
    double finderNextRequest = 0.0;
    uint32_t ammoRefillMask = 0;
    uint64_t ammoRefillState = 0, ammoRefillReceived = 0;
    double ammoRefillUntil = 0.0;
    void ResetAmmoSources();
    std::string AmmoSourcesJson() const;
    std::map<std::pair<int64_t, uint32_t>, uint32_t> ammoSourceFacts;
    uint64_t ammoSourceRevision = 0;
    int32_t ammoSourceFile = -1;
    std::string ammoSourceSettingsJson;
    void QueueItem(int64_t itemId, bool notify);
    void QueueCheckedLocation(int64_t locationId);
    void QueueDeathLink(const std::string& source, const std::string& cause);
    void QueueTrapLink(const std::string& source, const std::string& trapName);
    void SendDeathLink();
    void SendTrapLink(const std::string& trapName);
    void QueueLocationInfo(int64_t locationId, int64_t itemId, int playerId, int flags, const std::string& itemName,
                           const std::string& playerName, const std::string& locationName,
                           const std::string& itemGame);
    bool ProcessItem(int64_t itemId, bool notify, uint64_t sequence);
    void MarkItemApplied(uint64_t sequence);
    void FinalizeMajorItemReceipt(int modIndex, int itemId, int getItemId);
    std::string GetReceivedCountCVar() const;
    int32_t MapApItemToRandomizerGet(int64_t itemId) const;
    void RequestLocationScouts();
    int64_t ResolveApLocationForCheck(int32_t randomizerCheck);
    void ApplySlotSetting(const std::string& key, int value);
    void RefreshSongNotes();
    void RegisterCallbacks();
    void SyncCollectedLocations();
    void SetActiveLocationsFromJson(const std::string& raw);
    void SetLocationNameMapFromJson(const std::string& raw);
    void SetSlotSettingsFromJson(const std::string& raw);
    void SetShopPricesFromJson(const std::string& raw);
    struct PendingItem {
        int64_t id;
        bool notify;
        uint64_t sequence = 0;
    };
    struct ScoutedLocation {
        int64_t itemId = 0;
        int playerId = 0;
        int flags = 0;
        std::string itemName;
        std::string playerName;
        std::string locationName;
        std::string itemGame;
    };
    void IndexScoutedLocation(int64_t locationId, const ScoutedLocation& info);
    struct PendingScout {
        int64_t locationId = 0;
        ScoutedLocation info;
    };
    struct PendingDeathLink {
        std::string source;
        std::string cause;
    };
    struct PendingTrapLink {
        std::string source;
        std::string trapName;
    };

    std::atomic<bool> enabled{ false };
    std::mutex queueMutex;
    // Callback-owned mailbox. Live settings/maps below belong to the game thread.
    std::unordered_map<std::string, std::string> pendingSlotData;
    std::deque<PendingItem> pendingItems;
    std::deque<int64_t> pendingCheckedLocations;
    std::deque<PendingScout> pendingScouts;
    std::deque<PendingDeathLink> pendingDeathLinks;
    std::deque<PendingTrapLink> pendingTrapLinks;
    std::deque<std::string> chatMessages;
    std::unordered_map<int, int64_t> rcToApLocation;
    std::unordered_map<int64_t, int> apLocationToRc;
    std::unordered_map<int64_t, ScoutedLocation> scoutedLocations;
    // Fast normalized AP location-name -> AP ID lookup. Missing native RC mappings
    // are resolved against this index on demand instead of scanning every scout.
    // A value of -1 marks an ambiguous normalized name.
    std::unordered_map<std::string, int64_t> scoutedLocationNameIndex;
    // Exact per-seed namespace supplied by standalone SOH-EXTREME slot data.
    // This is authoritative and decouples native RC checks from baked AP ids/names.
    std::unordered_map<std::string, int64_t> authoritativeLocationNameIndex;
    bool locationNameMapLoaded = false;
    // Server-confirmed AP checks only.
    std::unordered_set<int64_t> reportedLocations;
    // LocationChecks sent but not yet acknowledged by the AP server.
    std::unordered_set<int64_t> pendingLocationReports;
    std::unordered_set<int64_t> activeLocations;
    std::unordered_map<std::string, int> slotSettings;
    std::unordered_map<int64_t, uint16_t> shopPrices;
    bool activeLocationsLoaded = false;
    bool slotSettingsLoaded = false;
    std::string slotSettingsError;
    std::string rejectedSlotSettingsJson;
    bool shopPricesLoaded = false;
    bool kakarikoGateOpen = false;
    bool deathLinkEnabled = false;
    bool trapLinkEnabled = false;
    bool linkTagsSynchronized = false;
    bool deathStateInitialized = false;
    bool lastPlayerAlive = true;
    bool suppressNextDeathLinkSend = false;
    size_t expectedScoutCount = 0;
    double nextScoutRequest = 0.0;
    bool wasAuthenticated = false;
    bool goalReported = false;
    uint32_t syncFrameCounter = 0;
    bool scoutsRequested = false;
    // Scene-local gameplay never needs every RC mapped. Check Finder does, but only
    // when the user enables it; this flag prevents rebuilding that cache repeatedly.
    bool checkFinderMappingsPrepared = false;
    // Reset whenever no gameplay save is active. The next loaded AP save gets a full
    // authoritative settings/placement/state reconciliation before normal play continues.
    bool saveRuntimeSynchronized = false;
    bool fileSelectActivationRequested = false;

    // APCpp callbacks only publish data + these flags. Gameplay mutation is
    // deferred to Update()/save-load on the main/gameplay thread.
    std::atomic<bool> slotSettingsPendingApply{ false };
    std::atomic<bool> activeLocationsPendingRefresh{ false };

    // AP remains authoritative, but checking every native randomizer option every
    // frame is unnecessary.
    uint32_t settingsEnforceFrameCounter = 0;

    uint64_t incomingItemOrdinal = 0;
    uint64_t appliedItemCount = 0;
    // Major AP items are not committed when the get-item animation merely starts.
    // They become durable only when SoH fires OnItemReceive after actually granting the item.
    bool awaitingMajorItemReceipt = false;
    uint64_t awaitingMajorSequence = 0;
    int64_t awaitingMajorApItemId = 0;
    int awaitingMajorModIndex = 0;
    int awaitingMajorItemId = 0;
    int awaitingMajorGetItemId = 0;
    std::vector<int64_t> receivedItemSnapshot;
    bool currentSaveIsArchipelago = false;
    bool newSaveReplayPending = false;
    bool saveMetadataLoaded = false;
    bool saveIdentityMismatch = false;
    std::string saveServer;
    SohExtreme::SaveConnectionIdentity saveConnectionIdentity, connectedIdentity;
    std::string connectedServer, connectedSlot, connectedPassword, connectedSettingsJson;
    std::string saveConnectionStatus;
    SohExtreme::SaveConnectionDecision saveConnectionDecision = SohExtreme::SaveConnectionDecision::Waiting;
    std::vector<uint64_t> fallbackNpcSpeechHashes;
    std::unordered_set<uint64_t> fallbackNpcSpeechSeen;
    std::string saveSlot;
    std::string cachedSlotSettingsJson;
};
