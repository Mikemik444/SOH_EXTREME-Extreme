#include "ArchipelagoClient.h"
#include "NpcSpeechIdentity.h"
#include "SceneTransitionChecks.h"
#include "TrackerWorkerConfig.h"
#include "AmmoPolicy.h"
#include "AmmoSourcePolicy.h"
#include "soh/Enhancements/GameplayDeliverySafety.h"

static bool ParseFlatStringIntObject(const std::string& raw, std::unordered_map<std::string, int64_t>& out);

#include <Archipelago.h>
#include <spdlog/spdlog.h>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <set>
#include <random>
#include <limits>
#include <nlohmann/json.hpp>
#include <ship/Context.h>
#include <ship/window/Window.h>

#include "soh/OTRGlobals.h"
#include "soh/SaveManager.h"
#include "soh/ShipInit.hpp"
#include "soh/cvar_prefixes.h"
#include "soh/Enhancements/game-interactor/GameInteractor.h"
#include "soh/Enhancements/randomizer/item.h"
#include "soh/Enhancements/randomizer/dungeon.h"
#include "soh/Enhancements/randomizer/randomizer.h"
#include "soh/Enhancements/randomizer/randomizer_check_tracker.h"
#include "soh/Enhancements/randomizer/savefile.h"
#include "soh/Enhancements/randomizer/settings.h"
#include "soh/Enhancements/randomizer/SoulActorAccess.h"
#include "soh/Network/Archipelago/ArchipelagoC.h"
#include "soh/Enhancements/randomizer/SeedContext.h"
#include "soh/Enhancements/randomizer/static_data.h"
#include "soh/Enhancements/randomizer/randomizerEnums/RandomizerCheck.h"
#include "soh/Enhancements/randomizer/randomizerEnums.h"
#include "soh/Enhancements/randomizer/randomizerEnums/RandomizerInf.h"
#include "soh/Enhancements/randomizer/randomizerEnums/RandomizerMiscEnums.h"
#include "soh/Notification/Notification.h"

extern "C" {
#include "macros.h"
#include "z64.h"
#include "functions.h"
#include "variables.h"
#include "overlays/actors/ovl_En_Ossan/z_en_ossan.h"
extern PlayState* gPlayState;
}

extern "C" u16 Randomizer_Item_Give(PlayState* play, GetItemEntry giEntry);
extern "C" void Save_SaveFile(void);

#include "EntranceRuntime.inc"

namespace {
std::string NormalizeApLocationName(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (unsigned char c : value) {
        if (std::isalnum(c)) {
            out.push_back(static_cast<char>(std::tolower(c)));
        }
    }
    return out;
}

constexpr int64_t AP_EXTREME_ITEM_BASE = 9500000;
constexpr int64_t AP_EXTREME_SPEECH_BASE = 9600000;
constexpr int64_t AP_EXTREME_SPEECH_FALLBACK_BASE = 9650000;
constexpr int64_t AP_EXTREME_SPEECH_FALLBACK_COUNT = 512;

// AP hot-path state intentionally lives in this translation unit.  None of this
// needs to be serialized: saved RandomizerCheck state and ReceivedItems replay
// are the durable sources of truth.
std::deque<int64_t> gDeferredLocationReports;
SohExtreme::CrossingJournal gCrossingJournal;
uint64_t gNewSaveReplayTargetCount = 0;
int gNewSaveReplayGraceFrames = 0;

constexpr int AP_NEW_SAVE_REPLAY_GRACE_FRAMES = 90;
constexpr int AP_NEW_SAVE_REPLAY_ITEMS_PER_FRAME = 8;
constexpr int AP_LOCATION_REPORTS_PER_FRAME = 4;

// Some SoH major/randomizer items successfully finish their hold-item sequence
// without producing the generic OnItemReceive callback AP normally uses as its
// transaction completion. Never let that wedge the entire receive queue forever.
// Retry only after the item/cutscene state has ended and Link is alive.
uint32_t gAwaitingMajorFrames = 0;
GetItemEntry gAwaitingMajorEntry{};
GetItemEntry gRemotePresentationEntry{};
constexpr uint32_t AP_MAJOR_RECEIVE_VERIFY_TIMEOUT_FRAMES = 90;


static uint64_t HashApReceiptBytes(uint64_t hash, const void* data, size_t size) {
    const auto* bytes = static_cast<const uint8_t*>(data);
    for (size_t i = 0; i < size; ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

template <typename T>
static uint64_t HashApReceiptValue(uint64_t hash, const T& value) {
    return HashApReceiptBytes(hash, &value, sizeof(T));
}

static uint64_t CaptureApPersistentGrantDigest() {
    uint64_t hash = 1469598103934665603ULL;

    hash = HashApReceiptBytes(hash, &gSaveContext.inventory, sizeof(gSaveContext.inventory));
    hash = HashApReceiptBytes(hash, &gSaveContext.ship.randomizerInf,
                             sizeof(gSaveContext.ship.randomizerInf));

    hash = HashApReceiptValue(hash, gSaveContext.healthCapacity);
    hash = HashApReceiptValue(hash, gSaveContext.magicLevel);
    hash = HashApReceiptValue(hash, gSaveContext.isMagicAcquired);
    hash = HashApReceiptValue(hash, gSaveContext.isDoubleMagicAcquired);
    hash = HashApReceiptValue(hash, gSaveContext.isDoubleDefenseAcquired);
    hash = HashApReceiptValue(hash, gSaveContext.bgsFlag);
    hash = HashApReceiptValue(hash, gSaveContext.rupees);
    hash = HashApReceiptValue(hash, gSaveContext.ship.quest.data.randomizer.bombchuUpgradeLevel);
    hash = HashApReceiptValue(hash, gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected);

    // Silver Rupee group progress uses dedicated native counters. Hash every
    // counter so an important AP silver piece is not acknowledged until the
    // exact SOH randomizer state proves that it was applied.
    const auto& apRando = gSaveContext.ship.quest.data.randomizer;
    hash = HashApReceiptValue(hash, apRando.silverShadowBlades);
    hash = HashApReceiptValue(hash, apRando.silverShadowPit);
    hash = HashApReceiptValue(hash, apRando.silverShadowSpikes);
    hash = HashApReceiptValue(hash, apRando.silverSpiritChild);
    hash = HashApReceiptValue(hash, apRando.silverSpiritSun);
    hash = HashApReceiptValue(hash, apRando.silverSpiritBoulders);
    hash = HashApReceiptValue(hash, apRando.silverBotw);
    hash = HashApReceiptValue(hash, apRando.silverIceCavernBlades);
    hash = HashApReceiptValue(hash, apRando.silverIceCavernBlock);
    hash = HashApReceiptValue(hash, apRando.silverGtgSlope);
    hash = HashApReceiptValue(hash, apRando.silverGtgLava);
    hash = HashApReceiptValue(hash, apRando.silverGtgWater);
    hash = HashApReceiptValue(hash, apRando.silverGanonLight);
    hash = HashApReceiptValue(hash, apRando.silverGanonForest);
    hash = HashApReceiptValue(hash, apRando.silverGanonFire);
    hash = HashApReceiptValue(hash, apRando.silverGanonSpirit);
    hash = HashApReceiptValue(hash, apRando.silverMqDodongosCavern);
    hash = HashApReceiptValue(hash, apRando.silverMqShadowInvisibleBlades);
    hash = HashApReceiptValue(hash, apRando.silverMqSpiritLobby);
    hash = HashApReceiptValue(hash, apRando.silverMqSpiritBigWall);
    hash = HashApReceiptValue(hash, apRando.silverMqGanonWater);
    hash = HashApReceiptValue(hash, apRando.silverMqGanonShadow);

    return hash;
}


constexpr int64_t AP_ITEM_ROLL = 9500000;
constexpr int64_t AP_ITEM_GRAB = 9500001;
constexpr int64_t AP_ITEM_CLIMB = 9500002;
constexpr int64_t AP_ITEM_CRAWL = 9500003;
constexpr int64_t AP_ITEM_SPEAK = 9500004;
constexpr int64_t AP_ITEM_OPEN_CHEST = 9500005;
constexpr int64_t AP_ITEM_ENEMY_SOUL = 9500006;
constexpr int64_t AP_ITEM_NPC_SOUL = 9500007;
constexpr int64_t AP_ITEM_ANIMAL_SOUL = 9500008;
constexpr int64_t AP_ITEM_POT_SOUL = 9500009;
constexpr int64_t AP_ITEM_CRATE_SOUL = 9500010;
constexpr int64_t AP_ITEM_GRASS_SOUL = 9500011;
constexpr int64_t AP_ITEM_ROCK_SOUL = 9500012;
constexpr int64_t AP_ITEM_TREE_SOUL = 9500013;
constexpr int64_t AP_ITEM_BEEHIVE_SOUL = 9500014;
constexpr int64_t AP_ITEM_SIGN_SOUL = 9500015;
constexpr int64_t AP_ITEM_SKULLTULA_SOUL = 9500016;
constexpr int64_t AP_ITEM_BUSINESS_SCRUB_SOUL = 9500017;
constexpr int64_t AP_ITEM_SHOVEL = 9500018;
constexpr int64_t AP_ITEM_FLOW_OF_TIME = 9500019;

constexpr int64_t AP_ITEM_DMC_BEAN_SOUL = 9500095;
constexpr int64_t AP_ITEM_DMT_BEAN_SOUL = 9500096;
constexpr int64_t AP_ITEM_COLOSSUS_BEAN_SOUL = 9500097;
constexpr int64_t AP_ITEM_GV_BEAN_SOUL = 9500098;
constexpr int64_t AP_ITEM_GRAVEYARD_BEAN_SOUL = 9500099;
constexpr int64_t AP_ITEM_KF_BEAN_SOUL = 9500100;
constexpr int64_t AP_ITEM_LH_BEAN_SOUL = 9500101;
constexpr int64_t AP_ITEM_LW_BRIDGE_BEAN_SOUL = 9500102;
constexpr int64_t AP_ITEM_LW_BEAN_SOUL = 9500103;
constexpr int64_t AP_ITEM_ZR_BEAN_SOUL = 9500104;

constexpr int64_t AP_ITEM_SPEAK_DEKU = 9500105;
constexpr int64_t AP_ITEM_SPEAK_GERUDO = 9500106;
constexpr int64_t AP_ITEM_SPEAK_GORON = 9500107;
constexpr int64_t AP_ITEM_SPEAK_HYLIAN = 9500108;
constexpr int64_t AP_ITEM_SPEAK_KOKIRI = 9500109;
constexpr int64_t AP_ITEM_SPEAK_ZORA = 9500110;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_COW = 9500111;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_CUCCO = 9500112;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_DOG = 9500113;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_FISH = 9500114;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_BUG = 9500115;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_BUTTERFLY = 9500116;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_FROG = 9500117;
constexpr int64_t AP_ITEM_ANIMAL_SOUL_HORSE = 9500118;
constexpr int64_t AP_ITEM_ENEMY_SOUL_STALFOS = 9500119;
constexpr int64_t AP_ITEM_ENEMY_SOUL_OCTOROK = 9500120;
constexpr int64_t AP_ITEM_ENEMY_SOUL_WALLMASTER = 9500121;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DODONGO = 9500122;
constexpr int64_t AP_ITEM_ENEMY_SOUL_KEESE = 9500123;
constexpr int64_t AP_ITEM_ENEMY_SOUL_TEKTITE = 9500124;
constexpr int64_t AP_ITEM_ENEMY_SOUL_PEAHAT = 9500125;
constexpr int64_t AP_ITEM_ENEMY_SOUL_LIZALFOS_DINOLFOS = 9500126;
constexpr int64_t AP_ITEM_ENEMY_SOUL_GOHMA_LARVA = 9500127;
constexpr int64_t AP_ITEM_ENEMY_SOUL_SHABOM = 9500128;
constexpr int64_t AP_ITEM_ENEMY_SOUL_BABY_DODONGO = 9500129;
constexpr int64_t AP_ITEM_ENEMY_SOUL_BIRI_BARI = 9500130;
constexpr int64_t AP_ITEM_ENEMY_SOUL_TAILPASARAN = 9500131;
constexpr int64_t AP_ITEM_ENEMY_SOUL_TORCH_SLUG = 9500132;
constexpr int64_t AP_ITEM_ENEMY_SOUL_MOBLIN = 9500133;
constexpr int64_t AP_ITEM_ENEMY_SOUL_ARMOS = 9500134;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DEKU_BABA = 9500135;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DEKU_SCRUB = 9500136;
constexpr int64_t AP_ITEM_ENEMY_SOUL_BUBBLE = 9500137;
constexpr int64_t AP_ITEM_ENEMY_SOUL_BEAMOS = 9500138;
constexpr int64_t AP_ITEM_ENEMY_SOUL_FLOORMASTER = 9500139;
constexpr int64_t AP_ITEM_ENEMY_SOUL_REDEAD_GIBDO = 9500140;
constexpr int64_t AP_ITEM_ENEMY_SOUL_FLARE_DANCER = 9500141;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DEAD_HAND = 9500142;
constexpr int64_t AP_ITEM_ENEMY_SOUL_SHELL_BLADE = 9500143;
constexpr int64_t AP_ITEM_ENEMY_SOUL_LIKE_LIKE = 9500144;
constexpr int64_t AP_ITEM_ENEMY_SOUL_SPIKE = 9500145;
constexpr int64_t AP_ITEM_ENEMY_SOUL_ANUBIS = 9500146;
constexpr int64_t AP_ITEM_ENEMY_SOUL_IRON_KNUCKLE = 9500147;
constexpr int64_t AP_ITEM_ENEMY_SOUL_SKULL_KID = 9500148;
constexpr int64_t AP_ITEM_ENEMY_SOUL_FLYING_POT = 9500149;
constexpr int64_t AP_ITEM_ENEMY_SOUL_FREEZARD = 9500150;
constexpr int64_t AP_ITEM_ENEMY_SOUL_STINGER = 9500151;
constexpr int64_t AP_ITEM_ENEMY_SOUL_WOLFOS = 9500152;
constexpr int64_t AP_ITEM_ENEMY_SOUL_GUAY = 9500153;
constexpr int64_t AP_ITEM_ENEMY_SOUL_JABU_TENTACLE = 9500154;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DARK_LINK = 9500155;
constexpr int64_t AP_ITEM_ENEMY_SOUL_DOOR_TRAP = 9500156;
constexpr int64_t AP_ITEM_ENEMY_SOUL_FLYING_FLOOR_TILE = 9500157;
constexpr int64_t AP_ITEM_ENEMY_SOUL_GERUDO_THIEF = 9500158;
constexpr int64_t AP_ITEM_ENEMY_SOUL_POE_SISTER = 9500159;
constexpr int64_t AP_ITEM_ENEMY_SOUL_POE = 9500182;
constexpr int64_t AP_ITEM_ENEMY_SOUL_LEEVER = 9500183;
constexpr int64_t AP_ITEM_ENEMY_SOUL_STALCHILD = 9500184;
constexpr int64_t AP_ITEM_ENEMY_SOUL_BIG_OCTO = 9500185;


// Native Silver Rupee group progression.
constexpr int64_t AP_ITEM_SHADOW_SILVER_BLADES = 9500160;
constexpr int64_t AP_ITEM_SHADOW_SILVER_PIT = 9500161;
constexpr int64_t AP_ITEM_SHADOW_SILVER_SPIKES = 9500162;
constexpr int64_t AP_ITEM_SPIRIT_SILVER_CHILD = 9500163;
constexpr int64_t AP_ITEM_SPIRIT_SILVER_SUN = 9500164;
constexpr int64_t AP_ITEM_SPIRIT_SILVER_BOULDERS = 9500165;
constexpr int64_t AP_ITEM_BOTW_SILVER = 9500166;
constexpr int64_t AP_ITEM_ICE_CAVERN_SILVER_BLADES = 9500167;
constexpr int64_t AP_ITEM_ICE_CAVERN_SILVER_BLOCK = 9500168;
constexpr int64_t AP_ITEM_GTG_SILVER_SLOPE = 9500169;
constexpr int64_t AP_ITEM_GTG_SILVER_LAVA = 9500170;
constexpr int64_t AP_ITEM_GTG_SILVER_WATER = 9500171;
constexpr int64_t AP_ITEM_GANONS_CASTLE_SILVER_LIGHT = 9500172;
constexpr int64_t AP_ITEM_GANONS_CASTLE_SILVER_FOREST = 9500173;
constexpr int64_t AP_ITEM_GANONS_CASTLE_SILVER_FIRE = 9500174;
constexpr int64_t AP_ITEM_GANONS_CASTLE_SILVER_SPIRIT = 9500175;
constexpr int64_t AP_ITEM_DODONGOS_CAVERN_MQ_SILVER = 9500176;
constexpr int64_t AP_ITEM_SHADOW_MQ_SILVER_INVISIBLE_BLADES = 9500177;
constexpr int64_t AP_ITEM_SPIRIT_MQ_SILVER_LOBBY = 9500178;
constexpr int64_t AP_ITEM_SPIRIT_MQ_SILVER_BIG_WALL = 9500179;
constexpr int64_t AP_ITEM_GANONS_CASTLE_MQ_SILVER_WATER = 9500180;
constexpr int64_t AP_ITEM_GANONS_CASTLE_MQ_SILVER_SHADOW = 9500181;
constexpr int64_t AP_FIRST_SILVER_ITEM = AP_ITEM_SHADOW_SILVER_BLADES;
constexpr int64_t AP_LAST_SILVER_ITEM = AP_ITEM_GANONS_CASTLE_MQ_SILVER_SHADOW;


// Archipelago NetworkItem.flags:
//   0x01 progression, 0x02 useful, 0x04 trap.
// Treat progression OR useful as "important" for the colored AP icon.
// Filler/junk/trap-only remote items use the grayscale icon.
static RandomizerGet GetRemoteArchipelagoDisplay(int flags) {
    return (flags & 0x03) != 0 ? RG_AP_REMOTE_IMPORTANT : RG_AP_REMOTE_NORMAL;
}
constexpr int64_t AP_FIRST_SONG_NOTE = 9500020;
constexpr int64_t AP_LAST_SONG_NOTE = 9500093;
constexpr int64_t AP_FIRST_PROGRESSIVE_SONG = 9500300;
constexpr int64_t AP_LAST_PROGRESSIVE_SONG = 9500311;

// AP base item IDs 1..276 intentionally match SoH RandomizerGet IDs in the
// 9.2.3-based world. This is the same numbering used by Items.py.
constexpr int64_t AP_BASE_ITEM_MIN = 1;
constexpr int64_t AP_BASE_ITEM_MAX = 276;
constexpr int64_t AP_ITEM_PROGRESSIVE_WALLET = 44;

static void SetQuestSong(int quest) {
    gSaveContext.inventory.questItems |= (1u << quest);
}

static bool HasNote(RandomizerInf first, int offset) {
    return Flags_GetRandomizerInf(static_cast<RandomizerInf>(static_cast<int>(first) + offset));
}

static RandomizerGet GetApSongNoteDisplay(int64_t itemId);
static RandomizerGet GetApProgressiveSongDisplay(const std::string& name);

static RandomizerGet MapApItemNameToRandomizerGet(const std::string& itemName) {
    static const std::unordered_map<std::string, RandomizerGet> kItemNameMap = {
#include "ArchipelagoNameMap.inc"
    };

    auto it = kItemNameMap.find(itemName);
    if (it != kItemNameMap.end()) {
        return it->second;
    }

    if (itemName.rfind("Progressive ", 0) == 0) {
        const auto song = GetApProgressiveSongDisplay(itemName);
        if (song != RG_NONE) return song;
    }

    // The legacy AP catalog names notes 01..74. Resolve their owning song rather than
    // losing that identity in a single shared note model. Reject malformed names
    // so a valid numeric item ID can still resolve a delayed/missing name.
    if (itemName.rfind("Song Note ", 0) == 0 && itemName.size() >= 11 && itemName.size() <= 12) {
        int note = 0;
        for (size_t i = 10; i < itemName.size(); ++i) {
            if (itemName[i] < '0' || itemName[i] > '9') return RG_NONE;
            note = note * 10 + (itemName[i] - '0');
        }
        return GetApSongNoteDisplay(AP_FIRST_SONG_NOTE + note - 1);
    }

    return RG_NONE;
}

// Ice Traps should mimic valuable items instead of exposing themselves with one
// fixed model. The disguise is stable per AP location.
static RandomizerGet GetIceTrapDisguise(int64_t apLocation) {
    static constexpr const char* kMajorDisguises[] = {
        "Progressive Hookshot",
        "Bow",
        "Boomerang",
        "Lens of Truth",
        "Megaton Hammer",
        "Progressive Strength Upgrade",
        "Progressive Scale",
        "Progressive Wallet",
        "Magic Meter",
        "Ocarina",
        "Mirror Shield",
        "Iron Boots",
        "Hover Boots",
        "Dins Fire",
        "Farores Wind",
        "Nayrus Love",
    };

    uint64_t x = static_cast<uint64_t>(apLocation);
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;

    const char* fakeName =
        kMajorDisguises[x % (sizeof(kMajorDisguises) / sizeof(kMajorDisguises[0]))];
    RandomizerGet display = MapApItemNameToRandomizerGet(fakeName);
    return display != RG_NONE ? display : RG_PROGRESSIVE_HOOKSHOT;
}

struct SongNotes { const char* name; int count; int quest; RandomizerGet display; };
static constexpr SongNotes kApSongNotes[] = {
        {"Zelda's Lullaby", 6, QUEST_SONG_LULLABY, RG_AP_NOTE_ZELDA},
        {"Epona's Song", 6, QUEST_SONG_EPONA, RG_AP_NOTE_EPONA},
        {"Saria's Song", 6, QUEST_SONG_SARIA, RG_AP_NOTE_SARIA},
        {"Sun's Song", 6, QUEST_SONG_SUN, RG_AP_NOTE_SUN},
        {"Song of Time", 6, QUEST_SONG_TIME, RG_AP_NOTE_TIME},
        {"Song of Storms", 6, QUEST_SONG_STORMS, RG_AP_NOTE_STORMS},
        {"Minuet of Forest", 6, QUEST_SONG_MINUET, RG_AP_NOTE_MINUET},
        {"Bolero of Fire", 8, QUEST_SONG_BOLERO, RG_AP_NOTE_BOLERO},
        {"Serenade of Water", 5, QUEST_SONG_SERENADE, RG_AP_NOTE_SERENADE},
        {"Requiem of Spirit", 6, QUEST_SONG_REQUIEM, RG_AP_NOTE_REQUIEM},
        {"Nocturne of Shadow", 7, QUEST_SONG_NOCTURNE, RG_AP_NOTE_NOCTURNE},
        {"Prelude of Light", 6, QUEST_SONG_PRELUDE, RG_AP_NOTE_PRELUDE},
    };

static int GetApSongIndex(int64_t itemId) {
    if (itemId >= AP_FIRST_PROGRESSIVE_SONG && itemId <= AP_LAST_PROGRESSIVE_SONG)
        return static_cast<int>(itemId - AP_FIRST_PROGRESSIVE_SONG);
    if (itemId < AP_FIRST_SONG_NOTE || itemId > AP_LAST_SONG_NOTE) return -1;
    int note = static_cast<int>(itemId - AP_FIRST_SONG_NOTE);
    int index = 0;
    for (const auto& song : kApSongNotes) {
        if (note < song.count) return index;
        note -= song.count;
        ++index;
    }
    return -1;
}

static bool IsApSongNote(int64_t itemId) {
    return GetApSongIndex(itemId) >= 0;
}

static RandomizerGet GetApSongNoteDisplay(int64_t itemId) {
    const int index = GetApSongIndex(itemId);
    return index < 0 ? RG_NONE : kApSongNotes[index].display;
}

static RandomizerGet GetApProgressiveSongDisplay(const std::string& name) {
    for (const auto& song : kApSongNotes)
        if (name == "Progressive " + std::string(song.name)) return song.display;
    return RG_NONE;
}

static bool ApplyApSongNote(int64_t itemId) {
    const int index = GetApSongIndex(itemId);
    if (index < 0) return false;
    int offset = 0;
    for (int i = 0; i < index; ++i) offset += kApSongNotes[i].count;
    if (itemId >= AP_FIRST_SONG_NOTE && itemId <= AP_LAST_SONG_NOTE) {
        offset = static_cast<int>(itemId - AP_FIRST_SONG_NOTE);
    } else {
        // Each committed receipt fills one missing flag. Legacy saves and new
        // progressive items share the same persistent song-note flags.
        int next = 0;
        while (next < kApSongNotes[index].count && HasNote(RAND_INF_SONG_NOTE_0, offset + next)) ++next;
        if (next == kApSongNotes[index].count) return true; // capped duplicate
        offset += next;
    }
    const auto flag = static_cast<RandomizerInf>(RAND_INF_SONG_NOTE_0 + offset);
    Flags_SetRandomizerInf(flag);
    return Flags_GetRandomizerInf(flag);
}

static std::string BuildApSongNotePickupDescription(int64_t itemId) {
    const int index = GetApSongIndex(itemId);
    if (index < 0) return {};
    int offset = 0;
    for (int i = 0; i < index; ++i) offset += kApSongNotes[i].count;
    const auto& song = kApSongNotes[index];
    int collected = 0;
    for (int i = 0; i < song.count; ++i)
        if (HasNote(RAND_INF_SONG_NOTE_0, offset + i)) ++collected;
    // This textbox precedes the receipt callback. Preview exactly one new note.
    if (itemId >= AP_FIRST_PROGRESSIVE_SONG ||
        !HasNote(RAND_INF_SONG_NOTE_0, static_cast<int>(itemId - AP_FIRST_SONG_NOTE)))
        collected = std::min(collected + 1, song.count);
    return "%gProgressive " + std::string(song.name) + "%w - %y" +
        std::to_string(collected) + "/" + std::to_string(song.count) + "%w" +
        (collected == song.count ? "&Song complete!" : ".");
}

static std::string GetApItemDisplayName(int64_t itemId) {
    switch (itemId) {
        case AP_ITEM_ROLL: return "Roll";
        case AP_ITEM_GRAB: return "Grab / Power Bracelet";
        case AP_ITEM_CLIMB: return "Climb";
        case AP_ITEM_CRAWL: return "Crawl";
        case AP_ITEM_SPEAK: return "Speak";
        case AP_ITEM_OPEN_CHEST: return "Open Chest";
        case AP_ITEM_ENEMY_SOUL: return "Enemy Soul";
        case AP_ITEM_NPC_SOUL: return "NPC Soul";
        case AP_ITEM_ANIMAL_SOUL: return "Animal Soul";
        case AP_ITEM_POT_SOUL: return "Pot Soul";
        case AP_ITEM_CRATE_SOUL: return "Crate Soul";
        case AP_ITEM_GRASS_SOUL: return "Grass / Bush Soul";
        case AP_ITEM_ROCK_SOUL: return "Rock / Boulder Soul";
        case AP_ITEM_TREE_SOUL: return "Tree Soul";
        case AP_ITEM_BEEHIVE_SOUL: return "Beehive Soul";
        case AP_ITEM_SIGN_SOUL: return "Sign Soul";
        case AP_ITEM_SKULLTULA_SOUL: return "Skulltula Soul";
        case AP_ITEM_BUSINESS_SCRUB_SOUL: return "Scrub Soul";
        case AP_ITEM_SHOVEL: return "Shovel";
        case AP_ITEM_FLOW_OF_TIME: return "Flow of Time";
        case AP_ITEM_DMC_BEAN_SOUL: return "Death Mountain Crater Bean Soul";
        case AP_ITEM_DMT_BEAN_SOUL: return "Death Mountain Trail Bean Soul";
        case AP_ITEM_COLOSSUS_BEAN_SOUL: return "Desert Colossus Bean Soul";
        case AP_ITEM_GV_BEAN_SOUL: return "Gerudo Valley Bean Soul";
        case AP_ITEM_GRAVEYARD_BEAN_SOUL: return "Graveyard Bean Soul";
        case AP_ITEM_KF_BEAN_SOUL: return "Kokiri Forest Bean Soul";
        case AP_ITEM_LH_BEAN_SOUL: return "Lake Hylia Bean Soul";
        case AP_ITEM_LW_BRIDGE_BEAN_SOUL: return "Lost Woods Bridge Bean Soul";
        case AP_ITEM_LW_BEAN_SOUL: return "Lost Woods Bean Soul";
        case AP_ITEM_ZR_BEAN_SOUL: return "Zora's River Bean Soul";
        case AP_ITEM_SPEAK_DEKU: return "Speak Deku";
        case AP_ITEM_SPEAK_GERUDO: return "Speak Gerudo";
        case AP_ITEM_SPEAK_GORON: return "Speak Goron";
        case AP_ITEM_SPEAK_HYLIAN: return "Speak Hylian";
        case AP_ITEM_SPEAK_KOKIRI: return "Speak Kokiri";
        case AP_ITEM_SPEAK_ZORA: return "Speak Zora";
        case AP_ITEM_ANIMAL_SOUL_COW: return "Cow Soul";
        case AP_ITEM_ANIMAL_SOUL_CUCCO: return "Cucco Soul";
        case AP_ITEM_ANIMAL_SOUL_DOG: return "Dog Soul";
        case AP_ITEM_ANIMAL_SOUL_FISH: return "Fish Soul";
        case AP_ITEM_ANIMAL_SOUL_BUG: return "Bug Soul";
        case AP_ITEM_ANIMAL_SOUL_BUTTERFLY: return "Butterfly Soul";
        case AP_ITEM_ANIMAL_SOUL_FROG: return "Frog Soul";
        case AP_ITEM_ANIMAL_SOUL_HORSE: return "Horse Soul";
        case AP_ITEM_ENEMY_SOUL_STALFOS: return "Stalfos Soul";
        case AP_ITEM_ENEMY_SOUL_OCTOROK: return "Octorok Soul";
        case AP_ITEM_ENEMY_SOUL_WALLMASTER: return "Wallmaster Soul";
        case AP_ITEM_ENEMY_SOUL_DODONGO: return "Dodongo Soul";
        case AP_ITEM_ENEMY_SOUL_KEESE: return "Keese Soul";
        case AP_ITEM_ENEMY_SOUL_TEKTITE: return "Tektite Soul";
        case AP_ITEM_ENEMY_SOUL_PEAHAT: return "Peahat Soul";
        case AP_ITEM_ENEMY_SOUL_LIZALFOS_DINOLFOS: return "Lizalfos and Dinolfos Soul";
        case AP_ITEM_ENEMY_SOUL_GOHMA_LARVA: return "Gohma Larva Soul";
        case AP_ITEM_ENEMY_SOUL_SHABOM: return "Shabom Soul";
        case AP_ITEM_ENEMY_SOUL_BABY_DODONGO: return "Baby Dodongo Soul";
        case AP_ITEM_ENEMY_SOUL_BIRI_BARI: return "Biri and Bari Soul";
        case AP_ITEM_ENEMY_SOUL_TAILPASARAN: return "Tailpasaran Soul";
        case AP_ITEM_ENEMY_SOUL_TORCH_SLUG: return "Torch Slug Soul";
        case AP_ITEM_ENEMY_SOUL_MOBLIN: return "Moblin Soul";
        case AP_ITEM_ENEMY_SOUL_ARMOS: return "Armos Soul";
        case AP_ITEM_ENEMY_SOUL_DEKU_BABA: return "Deku Baba Soul";
        case AP_ITEM_ENEMY_SOUL_DEKU_SCRUB: return "Deku Scrub Soul";
        case AP_ITEM_ENEMY_SOUL_BUBBLE: return "Bubble Soul";
        case AP_ITEM_ENEMY_SOUL_BEAMOS: return "Beamos Soul";
        case AP_ITEM_ENEMY_SOUL_FLOORMASTER: return "Floormaster Soul";
        case AP_ITEM_ENEMY_SOUL_REDEAD_GIBDO: return "Redead and Gibdo Soul";
        case AP_ITEM_ENEMY_SOUL_FLARE_DANCER: return "Flare Dancer Soul";
        case AP_ITEM_ENEMY_SOUL_DEAD_HAND: return "Dead Hand Soul";
        case AP_ITEM_ENEMY_SOUL_SHELL_BLADE: return "Shell Blade Soul";
        case AP_ITEM_ENEMY_SOUL_LIKE_LIKE: return "Like Like Soul";
        case AP_ITEM_ENEMY_SOUL_SPIKE: return "Spike Soul";
        case AP_ITEM_ENEMY_SOUL_ANUBIS: return "Anubis Soul";
        case AP_ITEM_ENEMY_SOUL_IRON_KNUCKLE: return "Iron Knuckle Soul";
        case AP_ITEM_ENEMY_SOUL_SKULL_KID: return "Skull Kid Soul";
        case AP_ITEM_ENEMY_SOUL_FLYING_POT: return "Flying Pot Soul";
        case AP_ITEM_ENEMY_SOUL_FREEZARD: return "Freezard Soul";
        case AP_ITEM_ENEMY_SOUL_STINGER: return "Stinger Soul";
        case AP_ITEM_ENEMY_SOUL_WOLFOS: return "Wolfos Soul";
        case AP_ITEM_ENEMY_SOUL_GUAY: return "Guay Soul";
        case AP_ITEM_ENEMY_SOUL_JABU_TENTACLE: return "Jabu Jabu Tentacle Soul";
        case AP_ITEM_ENEMY_SOUL_DARK_LINK: return "Dark Link Soul";
        case AP_ITEM_ENEMY_SOUL_DOOR_TRAP: return "Door Trap Soul";
        case AP_ITEM_ENEMY_SOUL_FLYING_FLOOR_TILE: return "Flying Floor Tile Soul";
        case AP_ITEM_ENEMY_SOUL_GERUDO_THIEF: return "Gerudo Thief Soul";
        case AP_ITEM_ENEMY_SOUL_POE_SISTER: return "Poe Sister Soul";
        case AP_ITEM_ENEMY_SOUL_POE: return "Poe Soul";
        case AP_ITEM_ENEMY_SOUL_LEEVER: return "Leever Soul";
        case AP_ITEM_ENEMY_SOUL_STALCHILD: return "Stalchild Soul";
        case AP_ITEM_ENEMY_SOUL_BIG_OCTO: return "Big Octo Soul";

        case AP_ITEM_SHADOW_SILVER_BLADES: return "Shadow Silver: Blades";
        case AP_ITEM_SHADOW_SILVER_PIT: return "Shadow Silver: Pit";
        case AP_ITEM_SHADOW_SILVER_SPIKES: return "Shadow Silver: Spikes";
        case AP_ITEM_SPIRIT_SILVER_CHILD: return "Spirit Silver: Child";
        case AP_ITEM_SPIRIT_SILVER_SUN: return "Spirit Silver: Sun";
        case AP_ITEM_SPIRIT_SILVER_BOULDERS: return "Spirit Silver: Boulders";
        case AP_ITEM_BOTW_SILVER: return "Bottom of the Well Silver";
        case AP_ITEM_ICE_CAVERN_SILVER_BLADES: return "Ice Cavern Silver: Blades";
        case AP_ITEM_ICE_CAVERN_SILVER_BLOCK: return "Ice Cavern Silver: Block";
        case AP_ITEM_GTG_SILVER_SLOPE: return "Training Ground Silver: Slope";
        case AP_ITEM_GTG_SILVER_LAVA: return "Training Ground Silver: Lava";
        case AP_ITEM_GTG_SILVER_WATER: return "Training Ground Silver: Water";
        case AP_ITEM_GANONS_CASTLE_SILVER_LIGHT: return "Ganon's Castle Silver: Light";
        case AP_ITEM_GANONS_CASTLE_SILVER_FOREST: return "Ganon's Castle Silver: Forest";
        case AP_ITEM_GANONS_CASTLE_SILVER_FIRE: return "Ganon's Castle Silver: Fire";
        case AP_ITEM_GANONS_CASTLE_SILVER_SPIRIT: return "Ganon's Castle Silver: Spirit";
        case AP_ITEM_DODONGOS_CAVERN_MQ_SILVER: return "Dodongo's Cavern Silver";
        case AP_ITEM_SHADOW_MQ_SILVER_INVISIBLE_BLADES: return "Shadow Silver: Invisible Blades";
        case AP_ITEM_SPIRIT_MQ_SILVER_LOBBY: return "Spirit Silver: Lobby";
        case AP_ITEM_SPIRIT_MQ_SILVER_BIG_WALL: return "Spirit Silver: Big Wall";
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_WATER: return "Ganon's Castle Silver: Water";
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_SHADOW: return "Ganon's Castle Silver: Shadow";
        default: break;
    }

    if (itemId >= AP_FIRST_PROGRESSIVE_SONG && itemId <= AP_LAST_PROGRESSIVE_SONG) {
        return "Progressive " + std::string(kApSongNotes[itemId - AP_FIRST_PROGRESSIVE_SONG].name);
    }
    if (itemId >= AP_FIRST_SONG_NOTE && itemId <= AP_LAST_SONG_NOTE) {
        return "Song Note " + std::to_string(static_cast<int>(itemId - AP_FIRST_SONG_NOTE) + 1);
    }

    if (itemId >= AP_BASE_ITEM_MIN && itemId <= AP_BASE_ITEM_MAX) {
        RandomizerGet randoGet = RG_NONE;
        switch (itemId) {
#include "ArchipelagoItemMap.inc"
            default: break;
        }
        if (randoGet != RG_NONE) {
            return Rando::StaticData::RetrieveItem(randoGet).GetName().english;
        }
    }

    return "Item " + std::to_string(itemId);
}

static bool BounceHasTag(const AP_Bounce& bounce, const std::string& tag) {
    if (bounce.tags == nullptr) return false;
    return std::find(bounce.tags->begin(), bounce.tags->end(), tag) != bounce.tags->end();
}

static std::string ExtractJsonString(const std::string& json, const std::string& key) {
    const std::string token = "\"" + key + "\"";
    size_t pos = json.find(token);
    if (pos == std::string::npos) return {};
    pos = json.find(':', pos + token.size());
    if (pos == std::string::npos) return {};
    pos = json.find('"', pos + 1);
    if (pos == std::string::npos) return {};
    ++pos;
    std::string out;
    bool escaped = false;
    for (; pos < json.size(); ++pos) {
        const char c = json[pos];
        if (escaped) {
            switch (c) {
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                default: out.push_back(c); break;
            }
            escaped = false;
        } else if (c == '\\') {
            escaped = true;
        } else if (c == '"') {
            break;
        } else {
            out.push_back(c);
        }
    }
    return out;
}

static std::string EscapeJsonString(const std::string& value) {
    std::string out;
    out.reserve(value.size() + 8);
    for (char c : value) {
        switch (c) {
            case '\\': out += "\\\\"; break;
            case '"': out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: out.push_back(c); break;
        }
    }
    return out;
}
}

ArchipelagoClient& ArchipelagoClient::GetInstance() {
    static ArchipelagoClient instance;
    return instance;
}

bool ArchipelagoClient::IsAuthenticated() const {
    return AP_IsInit() && AP_GetConnectionStatus() == AP_ConnectionStatus::Authenticated;
}

bool ArchipelagoClient::IsConnectionRefused() const {
    return AP_IsInit() && AP_GetConnectionStatus() == AP_ConnectionStatus::ConnectionRefused;
}

std::string ArchipelagoClient::GetStatusText() const {
    if (!enabled.load()) {
        return "Disabled";
    }
    if (!AP_IsInit()) {
        return "Starting...";
    }
    switch (AP_GetConnectionStatus()) {
        // APCpp can report Disconnected briefly while AP_Start() is establishing the
        // websocket.  Treat that as an in-progress connection while this client is
        // enabled instead of showing the contradictory "Disconnect / Disconnected" UI.
        case AP_ConnectionStatus::Disconnected: return "Connecting...";
        case AP_ConnectionStatus::Connected: return "Connected - authenticating...";
        case AP_ConnectionStatus::Authenticated:
            if (currentSaveIsArchipelago && saveIdentityMismatch) return saveConnectionStatus;
            if (!slotSettingsError.empty()) return slotSettingsError;
            if (!slotSettingsLoaded) return "Authenticated - loading AP settings...";
            if (!activeLocationsLoaded) return "Authenticated - loading AP locations...";
            if (!shopPricesLoaded) return "Authenticated - loading AP prices...";
            if (expectedScoutCount > 0 && scoutedLocations.size() < expectedScoutCount) {
                return "Authenticated - loading AP placements " + std::to_string(scoutedLocations.size()) + "/" +
                       std::to_string(expectedScoutCount);
            }
            return "Authenticated - ready";
        case AP_ConnectionStatus::ConnectionRefused: return "Connection refused - check server/slot/password";
        default: return "Connecting...";
    }
}

std::string ArchipelagoClient::GetEntranceStatusText() const {
    if (!slotSettingsError.empty()) return "Entrances: " + slotSettingsError;
    const auto& routes = SohExtreme::EntranceRuntime::routing;
    if (currentSaveIsArchipelago) {
        if (!SohExtreme::EntranceRuntime::slotMapLoaded)
            return "Entrances: waiting for this save's seed map";
        if (!routes.Active()) return "Entrances: vanilla in this save's seed";
        auto spawnName = [&routes](int source, const char* vanilla) {
            if (!routes.Contains(source)) return std::string(vanilla) + " (not shuffled by this seed)";
            const auto* destination = SohExtreme::EntranceEndpointById(routes.Destination(source));
            if (!destination) return std::string("unavailable");
            std::string name = destination->name;
            const auto arrow = name.find(" -> ");
            if (arrow != std::string::npos) name.erase(0, arrow + 4);
            return name;
        };
        return "Entrances: " + std::to_string(routes.Routes().size()) + " routes loaded" +
               "\nChild spawn: " + spawnName(ENTR_LINKS_HOUSE_CHILD_SPAWN, "Link's House") +
               "\nAdult spawn: " + spawnName(ENTR_HYRULE_FIELD_10, "Temple of Time");
    }
    if (!slotSettingsLoaded) return "Entrances: waiting for AP seed settings";
    const auto revision = slotSettings.find("EntranceRandomizerRevision");
    if (revision == slotSettings.end() || revision->second == 0)
        return "Entrances: vanilla in the connected server's seed";
    return "Entrances: randomized map received; open this seed's Archipelago save";
}

bool ArchipelagoClient::ConnectionSettingsChanged() const {
    auto configured = [](const char* key) { const char* value = CVarGetString(key, ""); return std::string(value ? value : ""); };
    return enabled.load() && (connectedServer != configured(CVAR_REMOTE_ARCHIPELAGO("ServerAddress")) ||
        connectedSlot != configured(CVAR_REMOTE_ARCHIPELAGO("SlotName")) ||
        connectedPassword != configured(CVAR_REMOTE_ARCHIPELAGO("Password")));
}

void ArchipelagoClient::SetConnectionIdentityFromJson(const std::string& raw) {
    const auto data = nlohmann::json::parse(raw, nullptr, false);
    connectedIdentity = {};
    connectedSettingsJson.clear();
    if (data.is_object() && data.contains("name") && data["name"].is_string() &&
        data["name"].get<std::string>() == connectedSlot &&
        data.contains("seed") && data["seed"].is_string() &&
        data.contains("team") && data["team"].is_number_integer() &&
        data.contains("slot") && data["slot"].is_number_integer()) {
        const auto team = data["team"].get<int64_t>();
        const auto slot = data["slot"].get<int64_t>();
        const auto seed = data["seed"].get<std::string>();
        if (!seed.empty() && seed.size() <= 4096 && team >= 0 && team <= std::numeric_limits<int>::max() &&
            slot > 0 && slot <= std::numeric_limits<int>::max())
            connectedIdentity = {seed, static_cast<int>(team), static_cast<int>(slot)};
    }
    // This callback also marks automatic reconnects where Disconnected was too
    // brief for a rendered frame to see it. Restart all per-connection services.
    saveIdentityMismatch = currentSaveIsArchipelago;
    saveRuntimeSynchronized = false;
    wasAuthenticated = false;
    std::scoped_lock lock(queueMutex);
    ResetFinderMirror();
}

void ArchipelagoClient::ReconcileSaveConnection(bool confirmLegacy) {
    if (!currentSaveIsArchipelago) return;
    using Decision = SohExtreme::SaveConnectionDecision;
    const auto decision = SohExtreme::CompareSaveConnection(saveConnectionIdentity, saveSlot, saveServer,
        connectedIdentity, connectedSlot, connectedServer, IsAuthenticated(), confirmLegacy);
    saveConnectionDecision = decision;
    saveIdentityMismatch = decision != Decision::Ready;
    switch (decision) {
        case Decision::Waiting:
            saveConnectionStatus = "Waiting to verify this save's AP seed and slot. Connect to its room; use the matching APCpp.dll.";
            return;
        case Decision::WrongSlot:
            saveConnectionStatus = "Connected AP slot/team differs from this save. Connect to the save's original player slot.";
            return;
        case Decision::WrongSeed:
            saveConnectionStatus = "Connected AP seed differs from this save. Use its original room or a separate save for the new seed.";
            return;
        case Decision::ConfirmLegacy:
            saveConnectionStatus = "This older save has no AP seed ID and the server address changed. Confirm the same AP game below.";
            return;
        case Decision::Ready: break;
    }
    if (saveServer != connectedServer || !saveConnectionIdentity.Valid()) {
        SPDLOG_INFO("[Archipelago] Bound save to verified AP connection (address updated; receipt cursor preserved at {})", appliedItemCount);
        saveRuntimeSynchronized = false;
        std::scoped_lock lock(queueMutex);
        ResetFinderMirror();
    }
    saveConnectionIdentity = connectedIdentity;
    saveServer = connectedServer;
    saveSlot = connectedSlot;
    saveConnectionStatus.clear();
    if (!connectedSettingsJson.empty() && (!slotSettingsLoaded || cachedSlotSettingsJson != connectedSettingsJson))
        SetSlotSettingsFromJson(connectedSettingsJson);
}

bool ArchipelagoClient::CanConfirmLegacyReconnect() const {
    return currentSaveIsArchipelago && IsAuthenticated() &&
        SohExtreme::CompareSaveConnection(saveConnectionIdentity, saveSlot, saveServer,
            connectedIdentity, connectedSlot, connectedServer, true) == SohExtreme::SaveConnectionDecision::ConfirmLegacy;
}

std::string ArchipelagoClient::GetReconnectTarget() const {
    return connectedServer + " | Player: " + connectedSlot + " | AP seed: " + connectedIdentity.seed;
}

void ArchipelagoClient::ConfirmLegacyReconnect() {
    if (!CanConfirmLegacyReconnect()) return;
    ReconcileSaveConnection(true);
    // Persist identity with the existing inventory/cursor in a normal game-thread
    // snapshot. No item grant, cursor reset, or save deletion is part of rebinding.
    if (!saveIdentityMismatch && IsGameplaySessionActive() && gSaveContext.fileNum < 3)
        Save_SaveFile();
}

void ArchipelagoClient::RegisterCallbacks() {
    AP_RegisterSlotDataRawCallback("_soh_connection_identity", [](std::string raw) {
        ArchipelagoClient::GetInstance().QueueSlotData("_soh_connection_identity", raw);
    });
    AP_SetLoggingCallback([](std::string line) { SPDLOG_INFO("[Archipelago] {}", line); });
    AP_SetItemClearCallback([]() {
        // APCpp calls this before replaying the complete ReceivedItems list.  Do NOT
        // clear SoH inventory here: the save already persists awarded items.  Instead
        // reset our receive ordinal so the full replay can be deduplicated against the
        // number of AP items this local save has already consumed.
        ArchipelagoClient::GetInstance().BeginItemReplay();
    });
    AP_SetItemRecvCallback([](int64_t item, bool notify) {
        ArchipelagoClient::GetInstance().QueueItem(item, notify);
    });
    AP_SetLocationCheckedCallback([](int64_t location) {
        ArchipelagoClient::GetInstance().QueueCheckedLocation(location);
    });
    AP_SetLocationInfoCallback([](std::vector<AP_NetworkItem> locations) {
        auto& client = ArchipelagoClient::GetInstance();
        for (const auto& item : locations) {
            client.QueueLocationInfo(item.location, item.item, item.player, item.flags, item.itemName, item.playerName,
                                     item.locationName, item.itemGame);
        }
    });

    // Do not mutate gameplay CVars from APCpp's networking callback thread.
    // extreme_soh_cvars below is the authoritative snapshot; it is applied only
    // after the user starts/loads an AP randomizer save on the gameplay thread.

    // Raw Bounce handling is used for TrapLink. APCpp documents that registering a
    // Bounced callback disables its automatic DeathLink handling, so SOH-EXTREME
    // handles BOTH link protocols here and advertises the matching tags after auth.
    AP_RegisterSlotDataIntCallback("death_link", [](int value) {
        ArchipelagoClient::GetInstance().QueueSlotData("death_link", value != 0 ? "1" : "0");
    });
    AP_RegisterSlotDataIntCallback("trap_link", [](int value) {
        ArchipelagoClient::GetInstance().QueueSlotData("trap_link", value != 0 ? "1" : "0");
    });
    AP_RegisterBouncedCallback([](AP_Bounce bounce) {
        auto& client = ArchipelagoClient::GetInstance();
        // The callback copies only a bounded payload. Decode and UI mutation
        // happen on the gameplay thread when the Check Finder is open.
        if (bounce.data.size() <= 1000100 &&
            ExtractJsonString(bounce.data, "soh_extreme_tracker") == SohExtreme::kTrackerProtocol &&
            ExtractJsonString(bounce.data, "kind") == "snapshot") {
            const auto payload = ExtractJsonString(bounce.data, "payload");
            if (!payload.empty() && payload.size() <= 1000000) {
                const auto nonce = ExtractJsonString(bounce.data, "nonce");
                std::scoped_lock lock(client.queueMutex);
                client.pendingFinderNonce = nonce;
                client.pendingFinderPayload = payload;
            }
        }
        if (bounce.data.size() <= 8 * 1024 * 1024 &&
            ExtractJsonString(bounce.data, "soh_extreme_tracker") == SohExtreme::kTrackerProtocol &&
            ExtractJsonString(bounce.data, "kind") == "hint_snapshot") {
            std::scoped_lock lock(client.queueMutex);
            client.pendingHintPayload = bounce.data;
        }
        if (BounceHasTag(bounce, "DeathLink")) {
            client.QueueDeathLink(ExtractJsonString(bounce.data, "source"),
                                  ExtractJsonString(bounce.data, "cause"));
        }
        if (BounceHasTag(bounce, "TrapLink")) {
            client.QueueTrapLink(ExtractJsonString(bounce.data, "source"),
                                 ExtractJsonString(bounce.data, "trap_name"));
        }
    });

    // v0.4.5 publishes one authoritative snapshot already translated into this
    // fork's native gRando.Settings CVar names. It is intentionally raw JSON so all
    // settings arrive as one readiness boundary before file-select is allowed to start.
    AP_RegisterSlotDataRawCallback("extreme_soh_cvars", [](std::string raw) {
        ArchipelagoClient::GetInstance().QueueSlotData("extreme_soh_cvars", raw);
    });
    AP_RegisterSlotDataRawCallback("extreme_shop_prices", [](std::string raw) {
        ArchipelagoClient::GetInstance().QueueSlotData("extreme_shop_prices", raw);
    });
    AP_RegisterSlotDataIntCallback("extreme_kakariko_gate_open", [](int value) {
        ArchipelagoClient::GetInstance().QueueSlotData("extreme_kakariko_gate_open", value != 0 ? "1" : "0");
    });

    // The AP server only allows LocationScouts for locations that actually exist in
    // this slot. SOH-EXTREME publishes that exact set in slot data. Scouting the entire
    // static SoH location table is invalid when options remove locations and causes the
    // AP 0.6.7 server to close the connection (for example: "No location 61 for player").
    AP_RegisterSlotDataRawCallback("extreme_active_locations", [](std::string raw) {
        ArchipelagoClient::GetInstance().QueueSlotData("extreme_active_locations", raw);
    });
    // Standalone SOH-EXTREME owns its own location namespace.  Never assume the
    // compiled ArchipelagoLocationMap.inc still has the seed's exact ids/names.
    // The APWorld publishes the authoritative active name -> id table per slot.
    AP_RegisterSlotDataRawCallback("extreme_location_name_to_id", [](std::string raw) {
        ArchipelagoClient::GetInstance().QueueSlotData("extreme_location_name_to_id", raw);
    });

    // The old per-setting native callbacks were intentionally removed here.
    // extreme_soh_cvars is the single authoritative snapshot and includes enum
    // translations that cannot be represented by a direct 1:1 callback.

}

namespace {
double FinderMirrorClock() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
}

namespace {
uint32_t ApAmmoMaskForItem(int32_t item) {
    switch (item) {
        case ITEM_STICK: return SOH_EXTREME_AMMO_REFILL_STICK;
        case ITEM_NUT: return SOH_EXTREME_AMMO_REFILL_NUT;
        case ITEM_BOMB: return SOH_EXTREME_AMMO_REFILL_BOMB;
        case ITEM_BOMBCHU: return SOH_EXTREME_AMMO_REFILL_BOMBCHU;
        case ITEM_BOW: return SOH_EXTREME_AMMO_REFILL_ARROWS;
        default: return 0;
    }
}

uint32_t CaptureApAmmoOwnedMask() {
    uint32_t mask = 0;
    if (INV_CONTENT(ITEM_STICK) == ITEM_STICK && CUR_CAPACITY(UPG_STICKS) > 0)
        mask |= SOH_EXTREME_AMMO_REFILL_STICK;
    if (INV_CONTENT(ITEM_NUT) == ITEM_NUT && CUR_CAPACITY(UPG_NUTS) > 0)
        mask |= SOH_EXTREME_AMMO_REFILL_NUT;
    if (INV_CONTENT(ITEM_BOMB) == ITEM_BOMB && CUR_CAPACITY(UPG_BOMB_BAG) > 0)
        mask |= SOH_EXTREME_AMMO_REFILL_BOMB;
    if (INV_CONTENT(ITEM_BOW) == ITEM_BOW && CUR_CAPACITY(UPG_QUIVER) > 0)
        mask |= SOH_EXTREME_AMMO_REFILL_ARROWS;
    const int mode = Randomizer_GetSettingValue(RSK_BOMBCHU_BAG);
    if (INV_CONTENT(ITEM_BOMBCHU) == ITEM_BOMBCHU &&
        (mode == RO_BOMBCHU_BAG_PROGRESSIVE
             ? gSaveContext.ship.quest.data.randomizer.bombchuUpgradeLevel > 0
             : (mode != RO_BOMBCHU_BAG_NONE || (mask & SOH_EXTREME_AMMO_REFILL_BOMB))))
        mask |= SOH_EXTREME_AMMO_REFILL_BOMBCHU;
    return mask;
}

uint32_t CaptureApAmmoAvailableMask(uint32_t owned) {
    uint32_t mask = 0;
    for (const int item : { ITEM_STICK, ITEM_NUT, ITEM_BOMB, ITEM_BOMBCHU, ITEM_BOW }) {
        if (AMMO(item) > 0) mask |= ApAmmoMaskForItem(item);
    }
    return mask & owned;
}

uint32_t CaptureApAmmoRulesFlags() {
    return (CVarGetInteger(CVAR_ENHANCEMENT("NoRandomDrops"), 0) ? 1u : 0u) |
           (CVarGetInteger(CVAR_ENHANCEMENT("TreesDropSticks"), 0) ? 2u : 0u);
}

uint64_t CaptureApAmmoStateToken(uint64_t sourceRevision = 0) {
    // Bind refill permission to this inventory and physical-save state. Ammo
    // quantities above zero have the same usability; firing 20 -> 19 does not
    // invalidate a still-correct result. No graph or network work happens here.
    auto inventory = gSaveContext.inventory;
    std::fill(std::begin(inventory.ammo), std::end(inventory.ammo), 0);
    uint64_t hash = HashApReceiptBytes(1469598103934665603ULL, &inventory, sizeof(inventory));
    hash = HashApReceiptBytes(hash, &gSaveContext.ship.randomizerInf, sizeof(gSaveContext.ship.randomizerInf));
    hash = HashApReceiptValue(hash, CaptureApAmmoAvailableMask(CaptureApAmmoOwnedMask()));
    hash = HashApReceiptValue(hash, CaptureApAmmoRulesFlags());
    hash = HashApReceiptValue(hash, sourceRevision);
    hash = HashApReceiptValue(hash, CVarGetInteger(CVAR_ENHANCEMENT("DampeAllNight"), 0));
    hash = HashApReceiptValue(hash, gSaveContext.ship.quest.data.randomizer.bombchuUpgradeLevel);
    hash = HashApReceiptValue(hash, gSaveContext.rupees);
    hash = HashApReceiptValue(hash, gSaveContext.linkAge);
    hash = HashApReceiptValue(hash, gSaveContext.nightFlag);
    hash = HashApReceiptValue(hash, SohExtreme::TrackerClockWindow(gSaveContext.dayTime));
    return hash ? hash : 1;
}
} // namespace

int32_t ArchipelagoClient::AdjustAmmoChange(int32_t item, int32_t currentAmmo, int32_t change) const {
    // Preserve only a unit that already exists in this AP save. No pickup, empty
    // bag, local randomizer, file-select, or minigame counter gains ammunition.
    if (change >= 0 || currentAmmo <= 0 || !currentSaveIsArchipelago || gPlayState == nullptr ||
        gSaveContext.ship.quest.id != QUEST_RANDOMIZER || gSaveContext.gameMode != GAMEMODE_NORMAL)
        return change;
    const uint32_t bit = ApAmmoMaskForItem(item);
    const bool owned = bit && (CaptureApAmmoOwnedMask() & bit);
    if (!owned || change >= 1 - currentAmmo) return change;
    const bool refill = IsAuthenticated() && !saveIdentityMismatch &&
        !slotSettingsPendingApply.load() && ammoRefillReceived == appliedItemCount &&
        ammoRefillState == CaptureApAmmoStateToken(ammoSourceRevision) &&
        FinderMirrorClock() <= ammoRefillUntil && (ammoRefillMask & bit);
    return SohExtreme_AdjustAmmoChange(currentAmmo, change, owned, refill);
}

void ArchipelagoClient::ResetAmmoSources() {
    ammoSourceFacts.clear();
    ++ammoSourceRevision;
    ammoSourceFile = gSaveContext.fileNum;
    ammoRefillMask = 0;
    ammoRefillUntil = 0.0;
}

void ArchipelagoClient::ObserveAmmoSource(int32_t randomizerCheck, int32_t actorId,
                                          int32_t sourceDropParams, int32_t collectibleInput) {
    // The init hook supplies original actor metadata and an exact identity.
    // Loading an actor is evidence about its drop, never about reachable access.
    if (!currentSaveIsArchipelago || gPlayState == nullptr ||
        gSaveContext.ship.quest.id != QUEST_RANDOMIZER || randomizerCheck <= RC_UNKNOWN_CHECK ||
        randomizerCheck >= RC_MAX)
        return;
    static_assert(SOH_EXTREME_AMMO_DROP_BOMBS_A == ITEM00_BOMBS_A &&
                  SOH_EXTREME_AMMO_DROP_BOMBS_B == ITEM00_BOMBS_B &&
                  SOH_EXTREME_AMMO_DROP_ARROWS_SMALL == ITEM00_ARROWS_SMALL &&
                  SOH_EXTREME_AMMO_DROP_ARROWS_MEDIUM == ITEM00_ARROWS_MEDIUM &&
                  SOH_EXTREME_AMMO_DROP_ARROWS_LARGE == ITEM00_ARROWS_LARGE &&
                  SOH_EXTREME_AMMO_DROP_NUTS == ITEM00_NUTS &&
                  SOH_EXTREME_AMMO_DROP_STICK == ITEM00_STICK &&
                  SOH_EXTREME_AMMO_DROP_SEEDS == ITEM00_SEEDS, "ammo source drop IDs changed");
    const int kind = actorId == ACTOR_OBJ_TSUBO ? SOH_EXTREME_AMMO_SOURCE_POT :
                     actorId == ACTOR_OBJ_KIBAKO ? SOH_EXTREME_AMMO_SOURCE_SMALL_CRATE :
                     actorId == ACTOR_OBJ_KIBAKO2 ? SOH_EXTREME_AMMO_SOURCE_LARGE_CRATE : 0;
    if (!kind) return;
    const auto mapping = rcToApLocation.find(randomizerCheck);
    if (mapping == rcToApLocation.end() || mapping->second <= 0) return;
    if (ammoSourceFile != gSaveContext.fileNum) ResetAmmoSources();
    const uint32_t age = gSaveContext.linkAge == LINK_AGE_CHILD ? 1u : 2u;
    const auto key = std::make_pair(mapping->second, age);
    const uint32_t mask = SohExtreme_AmmoSourceMask(kind, sourceDropParams, collectibleInput);
    const uint32_t fact = mask ? mask | (static_cast<uint32_t>(kind) << 6) | (age << 8) : 0;
    const auto old = ammoSourceFacts.find(key);
    if (old != ammoSourceFacts.end() && old->second == fact) return;
    if (old == ammoSourceFacts.end() && ammoSourceFacts.size() >= 2048) return;
    // Keep rejected observations as bounded tombstones. Seeing a nonrenewable
    // variant of the same age/identity removes the earlier authority as well.
    if (old != ammoSourceFacts.end() && old->second == 0) return;
    ammoSourceFacts[key] = old != ammoSourceFacts.end() ? 0 : fact;
    ++ammoSourceRevision;
    ammoRefillMask = 0;
    ammoRefillUntil = 0.0;
    finderNextRequest = 0.0;
}

std::string ArchipelagoClient::AmmoSourcesJson() const {
    std::string json = "[";
    bool first = true;
    for (const auto& [identity, fact] : ammoSourceFacts) {
        if (!fact) continue;
        if (!first) json += ",";
        first = false;
        json += "[" + std::to_string(identity.first) + "," + std::to_string(fact) + "]";
    }
    return json + "]";
}

void ArchipelagoClient::ResetFinderMirror() {
    finderWorker.Stop();
    ammoRefillMask = 0;
    ammoRefillState = ammoRefillReceived = 0;
    ammoRefillUntil = 0.0;
    finderWorkerStarted = false;
    finderWorkerAttempts = 0;
    finderWorkerNextPoll = 0.0;
    finderWorkerRetryAt = 0.0;
    finderWorkerError.clear();
    // Not an authentication secret: a collision-resistant per-save/connection
    // token preventing accidental use of another slot's or an old save's data.
    static constexpr char hex[] = "0123456789abcdef";
    std::random_device random;
    std::string nonce(32, '0');
    for (auto& c : nonce) c = hex[random() & 15u];
    finderMirror.Reset(nonce);
    pendingFinderPayload.clear();
    pendingFinderNonce.clear();
    finderMirrorError.clear();
    finderNextRequest = 0.0;
    pendingHintPayload.clear();
    hintProducer.clear();
    hintRevision = hintRequest = 0;
    nextHintRequest = nextHintPublish = 0.0;
    serverHintRows.clear();
    hintSnapshotLoaded = false;
    hintSyncStatus.clear();
    RebuildHints();
}

void ArchipelagoClient::RefreshFinderMirror() {
    // Called from the game UI; do not erase a valid snapshot just for a refresh.
    finderNextRequest = 0.0;
}

void ArchipelagoClient::RestartFinderWorker() {
    std::scoped_lock lock(queueMutex);
    ResetFinderMirror();
}

const std::string& ArchipelagoClient::GetFinderRuntimePath() const {
    return finderWorker.RuntimePath();
}

int32_t ArchipelagoClient::GetFinderNativeCheck(int64_t locationId) const {
    const auto found = apLocationToRc.find(locationId);
    return found == apLocationToRc.end() ? -1 : found->second;
}

void ArchipelagoClient::ServiceFinderWorker() {
    // Starts only for a loaded, authenticated AP gameplay save. Returning to
    // file select, loading a local save, or losing auth stops our own worker.
    // The native/local randomizer never starts or consults this service.
    const bool wanted = enabled.load() && currentSaveIsArchipelago && !saveIdentityMismatch &&
                        IsGameplaySessionActive() && IsAuthenticated();
    if (!wanted) {
        if (finderWorkerStarted) {
            std::scoped_lock lock(queueMutex);
            ResetFinderMirror();
        }
        return;
    }
    // 0.11.21a: Update() services this method BEFORE its authentication
    // reconciliation. Starting here on the first frame launched a host which
    // that reconciliation immediately stopped, then launched a second host on
    // the next frame. Wait for BOTH boundaries; never flap a new connection.
    if (!wasAuthenticated || !saveRuntimeSynchronized || !activeLocationsLoaded) return;
    const double now = FinderMirrorClock();
    if (now < finderWorkerNextPoll) return;
    finderWorkerNextPoll = now + 0.5;
    if (finderWorkerStarted && !finderWorker.IsRunning(finderWorkerError)) {
        const auto attempts = finderWorkerAttempts;
        const auto error = finderWorkerError;
        {
            std::scoped_lock lock(queueMutex);
            ResetFinderMirror();
        }
        finderWorkerAttempts = attempts;
        finderWorkerError = error;
        finderWorkerRetryAt = now + 5.0;
        finderWorkerNextPoll = now + 0.5;
        SPDLOG_WARN("[Archipelago] {}", finderWorkerError);
    }
    if (!finderWorkerStarted && finderWorkerAttempts < 3 && now >= finderWorkerRetryAt) {
        ++finderWorkerAttempts;
        const char* server = connectedServer.c_str();
        const char* name = connectedSlot.c_str();
        const char* password = connectedPassword.c_str();
        const char* runtime = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("TrackerRuntimePath"), "");
        try {
            const auto config = SohExtreme::MakeTrackerWorkerBootstrap(server ? server : "", name ? name : "",
                password ? password : "", static_cast<uint32_t>(AP_GetPlayerID()), finderMirror.Nonce());
            finderWorkerStarted = finderWorker.Start(runtime ? runtime : "", config, finderWorkerError);
        } catch (const std::exception&) {
            finderWorkerError = "The AP tracker could not read valid game connection settings.";
        }
        finderWorkerRetryAt = now + 15.0 * finderWorkerAttempts;
        if (finderWorkerStarted) {
            finderNextRequest = 0.0;
            SPDLOG_INFO("[Archipelago] Automatic Universal Tracker host started using {}", finderWorker.RuntimePath());
        } else {
            SPDLOG_WARN("[Archipelago] {}", finderWorkerError);
        }
    }
    if (finderWorkerStarted) {
        // Requests and replies continue even with the tracker UI closed. No
        // Python generation, rule evaluation, or network waiting occurs here.
        std::string status;
        if (GetFinderSnapshot(status) != nullptr) finderWorkerAttempts = 0;
    }
}

const SohExtreme::TrackerSnapshot* ArchipelagoClient::GetFinderSnapshot(std::string& status) {
    if (!currentSaveIsArchipelago || !IsAuthenticated()) {
        status = "Connect this Archipelago save to its server to start automatic tracking.";
        return nullptr;
    }
    if (saveIdentityMismatch) { status = saveConnectionStatus; return nullptr; }
    if (!activeLocationsLoaded) {
        status = "Waiting for the server's active location manifest...";
        return nullptr;
    }
    std::string payload;
    std::string payloadNonce;
    uint64_t received = 0;
    std::set<int64_t> active;
    {
        std::scoped_lock lock(queueMutex);
        payload.swap(pendingFinderPayload);
        payloadNonce.swap(pendingFinderNonce);
        received = incomingItemOrdinal;
        active.insert(activeLocations.begin(), activeLocations.end());
    }
    const double now = FinderMirrorClock();
    const auto slot = static_cast<uint32_t>(AP_GetPlayerID());
    // Shop reachability and receipt history cannot tell whether Link has bought
    // a shield yet, or lost one to fire/a Like Like. Read the live save on this
    // main-thread path and require the reply to match this exact equipment.
    const uint32_t liveShields = (CHECK_OWNED_EQUIP(EQUIP_TYPE_SHIELD, EQUIP_INV_SHIELD_DEKU) ? 1u : 0u) |
                                (CHECK_OWNED_EQUIP(EQUIP_TYPE_SHIELD, EQUIP_INV_SHIELD_HYLIAN) ? 2u : 0u);
    const uint32_t liveTime = gSaveContext.nightFlag ? 1u : 0u;
    const uint32_t liveClock = gSaveContext.dayTime;
    const uint32_t liveTimeFlags = CVarGetInteger(CVAR_ENHANCEMENT("DampeAllNight"), 0) ? 1u : 0u;
    const uint32_t liveAmmoOwned = CaptureApAmmoOwnedMask();
    const uint32_t liveAmmo = CaptureApAmmoAvailableMask(liveAmmoOwned);
    const uint32_t liveAmmoFlags = CaptureApAmmoRulesFlags();
    const uint32_t liveRupees = static_cast<uint32_t>(std::max<int32_t>(0, gSaveContext.rupees));
    const uint32_t liveAge = gSaveContext.linkAge == LINK_AGE_CHILD ? 1u : 2u;
    const uint64_t liveAmmoState = CaptureApAmmoStateToken(ammoSourceRevision);
    if (!payload.empty() && payloadNonce == finderMirror.Nonce()) {
        try {
            finderMirror.Accept(SohExtreme::DecodeTrackerSnapshot(payload), slot, now, finderMirrorError);
        } catch (const std::exception& error) {
            finderMirrorError = std::string("Invalid tracker snapshot: ") + error.what();
        }
    }
    if (finderWorkerStarted && now >= finderNextRequest) {
        const uint64_t request = finderMirror.NextRequest();
        AP_Bounce bounce{};
        std::vector<std::string> tags{ "SOHExtremeUT" };
        bounce.tags = &tags;
        bounce.data = "{\"soh_extreme_tracker\":\"SOHExtremeFinder1\",\"kind\":\"request\",\"slot\":" +
            std::to_string(slot) + ",\"nonce\":\"" + finderMirror.Nonce() + "\",\"request\":" +
            std::to_string(request) + ",\"live_shields\":" + std::to_string(liveShields) +
            ",\"live_time\":" + std::to_string(liveTime) + ",\"live_clock\":" + std::to_string(liveClock) +
            ",\"live_time_flags\":" + std::to_string(liveTimeFlags) +
            ",\"ammo_protocol\":1,\"live_ammo\":" + std::to_string(liveAmmo) +
            ",\"live_ammo_owned\":" + std::to_string(liveAmmoOwned) +
            ",\"live_rupees\":" + std::to_string(liveRupees) +
            ",\"live_ammo_flags\":" + std::to_string(liveAmmoFlags) +
            ",\"live_ammo_state\":" + std::to_string(liveAmmoState) +
            ",\"live_age\":" + std::to_string(liveAge) +
            ",\"ammo_sources\":" + AmmoSourcesJson() + "}";
        AP_SendBounce(bounce);
        finderNextRequest = now + 2.0;
    }
    std::set<int64_t> checked;
    for (const auto id : reportedLocations) if (active.count(id)) checked.insert(id);
    const auto* result = finderMirror.Current(slot, received, active, checked, now, status, liveShields, liveTime,
                                            liveClock, liveTimeFlags, liveAmmo, liveAmmoState);
    // Display may accept an older protocol or a manually adjusted UT view.
    // Gameplay refill permission requires exact live, unmodified inventory.
    ammoRefillMask = 0;
    ammoRefillUntil = 0.0;
    if (result != nullptr && result->liveAmmo != 0xffffffffu && result->manualCount == 0 &&
        result->ignoredCount == 0 && result->received == appliedItemCount &&
        result->liveAmmoOwned == liveAmmoOwned && result->liveRupees == liveRupees &&
        result->liveAmmoFlags == liveAmmoFlags) {
        ammoRefillMask = result->ammoRefills & liveAmmoOwned;
        ammoRefillState = liveAmmoState;
        ammoRefillReceived = appliedItemCount;
        ammoRefillUntil = now + 1.0;
    }
    if (!result && !finderWorkerError.empty()) status = finderWorkerError;
    else if (!result && !finderMirrorError.empty()) status += " " + finderMirrorError;
    return result;
}

void ArchipelagoClient::Enable() {
    if (enabled.load()) {
        return;
    }
    ResetRemotePresentations();

    // A refused/failed APCpp session can remain initialized even after the UI considers
    // it inactive.  Always tear down stale state before starting a fresh connection.
    if (AP_IsInit()) {
        AP_Shutdown();
    }

    const char* server = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("ServerAddress"), "archipelago.gg:38281");
    const char* slot = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("SlotName"), "");
    const char* password = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("Password"), "");

    if (slot == nullptr || slot[0] == '\0') {
        SPDLOG_ERROR("[Archipelago] Slot name is empty");
        enabled = false;
        return;
    }

    // Reset per-connection state before APCpp callbacks can begin filling it.
    {
        std::scoped_lock lock(queueMutex);
        ResetFinderMirror();
        pendingSlotData.clear();
        pendingItems.clear();
        pendingCheckedLocations.clear();
        pendingScouts.clear();
        pendingDeathLinks.clear();
        pendingTrapLinks.clear();
        hints.clear();
        hintSnapshotLoaded = false;
        inGameHints.Clear();
        chatMessages.clear();
    }
    scoutedLocations.clear();
    scoutedLocationNameIndex.clear();
    reportedLocations.clear();
    activeLocations.clear();
    authoritativeLocationNameIndex.clear();
    locationNameMapLoaded = false;
    slotSettings.clear();
    shopPrices.clear();
    activeLocationsLoaded = false;
    slotSettingsLoaded = false;
    slotSettingsError.clear();
    rejectedSlotSettingsJson.clear();
    shopPricesLoaded = false;
    kakarikoGateOpen = false;
    deathLinkEnabled = false;
    trapLinkEnabled = false;
    linkTagsSynchronized = false;
    deathStateInitialized = false;
    lastPlayerAlive = true;
    suppressNextDeathLinkSend = false;
    expectedScoutCount = 0;
    scoutsRequested = false;
    saveRuntimeSynchronized = false;
    fileSelectActivationRequested = false;
    slotSettingsPendingApply.store(false);
    activeLocationsPendingRefresh.store(false);
    settingsEnforceFrameCounter = 0;
    wasAuthenticated = false;
    goalReported = false;
    syncFrameCounter = 0;
    incomingItemOrdinal = 0;
    receivedItemSnapshot.clear();
    gDeferredLocationReports.clear();
    gNewSaveReplayTargetCount = 0;
    gNewSaveReplayGraceFrames = 0;
    awaitingMajorItemReceipt = false;
    awaitingMajorSequence = 0;
    awaitingMajorApItemId = 0;
    gAwaitingMajorFrames = 0;
    connectedServer = server ? server : "";
    connectedSlot = slot;
    connectedPassword = password ? password : "";
    connectedIdentity = {};
    connectedSettingsJson.clear();
    saveIdentityMismatch = currentSaveIsArchipelago;
    saveConnectionStatus = "Connecting to verify this save's AP seed and slot...";
    // Migration fallback for pre-0.5.9 saves.  A real AP save overrides this
    // with its own serialized receive count as soon as SaveManager loads it.
    if (!saveMetadataLoaded) {
        appliedItemCount = static_cast<uint64_t>(std::max(0, CVarGetInteger(GetReceivedCountCVar().c_str(), 0)));
    }
    SPDLOG_INFO("[Archipelago] Loaded persisted received-item count {}", appliedItemCount);

    enabled = true;
    AP_Init(server, "SOH-EXTREME", slot, password == nullptr ? "" : password);
    AP_NetworkVersion version{ 0, 6, 7 };
    AP_SetClientVersion(&version);
    RegisterCallbacks();
    AP_EnableQueueItemRecvMsgs(true);
    AP_Start();
    SPDLOG_INFO("[Archipelago] Starting connection to {} as {}", server, slot);
}

void ArchipelagoClient::Disable() {
    ResetRemotePresentations();
    // Shutdown should be safe even if our UI state and APCpp state got out of sync.
    enabled = false;
    if (AP_IsInit()) {
        AP_Shutdown();
    }
    std::scoped_lock lock(queueMutex);
    ResetFinderMirror();
    connectedIdentity = {};
    connectedSettingsJson.clear();
    connectedPassword.clear();
    pendingSlotData.clear();
    goalReported = false;
    pendingItems.clear();
    pendingCheckedLocations.clear();
    pendingScouts.clear();
    pendingDeathLinks.clear();
    pendingTrapLinks.clear();
    scoutedLocations.clear();
    scoutedLocationNameIndex.clear();
    activeLocations.clear();
    authoritativeLocationNameIndex.clear();
    locationNameMapLoaded = false;
    slotSettings.clear();
    shopPrices.clear();
    activeLocationsLoaded = false;
    slotSettingsLoaded = false;
    slotSettingsError.clear();
    rejectedSlotSettingsJson.clear();
    shopPricesLoaded = false;
    kakarikoGateOpen = false;
    deathLinkEnabled = false;
    trapLinkEnabled = false;
    linkTagsSynchronized = false;
    deathStateInitialized = false;
    lastPlayerAlive = true;
    suppressNextDeathLinkSend = false;
    expectedScoutCount = 0;
    scoutsRequested = false;
    saveRuntimeSynchronized = false;
    fileSelectActivationRequested = false;
    awaitingMajorItemReceipt = false;
    awaitingMajorSequence = 0;
    awaitingMajorApItemId = 0;
    gAwaitingMajorFrames = 0;
    newSaveReplayPending = false;
    gDeferredLocationReports.clear();
    gNewSaveReplayTargetCount = 0;
    gNewSaveReplayGraceFrames = 0;
    hints.clear();
    hintSnapshotLoaded = false;
    inGameHints.Clear();
    chatMessages.clear();
}

void ArchipelagoClient::Toggle() {
    if (IsEnabled()) Disable(); else Enable();
}

std::string ArchipelagoClient::GetReceivedCountCVar() const {
    const char* server = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("ServerAddress"), "");
    const char* slot = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("SlotName"), "");
    std::string identity = std::string(server ? server : "") + "_" + std::string(slot ? slot : "");
    for (char& c : identity) {
        if (!std::isalnum(static_cast<unsigned char>(c))) c = '_';
    }
    return std::string("gNetwork.Archipelago.ReceivedItemCount.") + identity;
}

void ArchipelagoClient::LoadSaveMetadata(bool isArchipelagoSave, uint64_t receivedItemCount,
                                               const std::string& server, const std::string& slot,
                                               const std::string& cachedSettingsJson,
                                               const SohExtreme::SaveConnectionIdentity& identity) {
    ResetRemotePresentations();
    auto sameIdentity = [](const SohExtreme::SaveConnectionIdentity& a,
                           const SohExtreme::SaveConnectionIdentity& b) {
        return a.Valid() && b.Valid() && a.seed == b.seed && a.team == b.team && a.slot == b.slot;
    };
    // Return to Spawn reopens this same verified save. Keep the existing
    // managed host/nonce while inventory and receipt state reload normally.
    // A different file identity, connection, settings, or dead host still
    // follows the complete reset path below.
    std::string workerStatus;
    const bool preserveTracker = currentSaveIsArchipelago && isArchipelagoSave &&
        !saveIdentityMismatch && IsAuthenticated() && sameIdentity(saveConnectionIdentity, identity) &&
        sameIdentity(connectedIdentity, identity) && saveSlot == slot && connectedSlot == slot &&
        saveServer == server && connectedServer == server && slotSettingsLoaded &&
        cachedSlotSettingsJson == cachedSettingsJson && connectedSettingsJson == cachedSettingsJson &&
        finderWorkerStarted && finderWorker.IsRunning(workerStatus);
    const bool preserveHintJournal = currentSaveIsArchipelago && isArchipelagoSave &&
        sameIdentity(saveConnectionIdentity, identity);
    if (!preserveHintJournal) {
        std::scoped_lock lock(hintJournalMutex);
        revealedHintTargets.clear();
    }
    const bool preserveRequestedDungeonReturn = currentSaveIsArchipelago && isArchipelagoSave &&
        sameIdentity(saveConnectionIdentity, identity) && saveServer == server && saveSlot == slot &&
        cachedSlotSettingsJson == cachedSettingsJson;
    if (!preserveRequestedDungeonReturn || ammoSourceFile != gSaveContext.fileNum) ResetAmmoSources();
    gCrossingJournal.Reset();
    SohExtreme::EntranceRuntime::Reset(preserveRequestedDungeonReturn);
    {
        std::scoped_lock lock(queueMutex);
        if (preserveTracker) {
            finderNextRequest = 0.0;
            nextHintRequest = 0.0;
        } else {
            ResetFinderMirror();
        }
        currentSaveIsArchipelago = isArchipelagoSave;
        pendingLocationReports.clear();
        saveRuntimeSynchronized = false;
        newSaveReplayPending = false;
        gDeferredLocationReports.clear();
        gNewSaveReplayTargetCount = 0;
        gNewSaveReplayGraceFrames = 0;
        awaitingMajorItemReceipt = false;
        awaitingMajorSequence = 0;
        awaitingMajorApItemId = 0;
        gAwaitingMajorFrames = 0;
        saveMetadataLoaded = true;
        goalReported = false;
        saveServer = server;
        saveSlot = slot;
        saveConnectionIdentity = identity;
        saveConnectionDecision = SohExtreme::SaveConnectionDecision::Waiting;
        saveConnectionStatus.clear();
        saveIdentityMismatch = isArchipelagoSave;
        // The cursor always belongs to this inventory, including a blocked or
        // offline load. Never keep another file's cursor or reset it on rebind.
        appliedItemCount = receivedItemCount;
        cachedSlotSettingsJson = cachedSettingsJson;
        slotSettingsError.clear();
        rejectedSlotSettingsJson.clear();
        if (!isArchipelagoSave) return;
        slotSettings.clear();
        slotSettingsLoaded = false;
        std::unordered_map<std::string, int64_t> parsed;
        if (!cachedSettingsJson.empty()) {
            if (!ParseFlatStringIntObject(cachedSettingsJson, parsed)) {
                slotSettingsError = "Saved AP settings could not be read. Connect to this save's original room.";
            } else {
                for (const auto& [key, value] : parsed) {
                    if (value < std::numeric_limits<int>::min() || value > std::numeric_limits<int>::max()) {
                        slotSettingsError = "A saved AP setting is out of range. Connect to this save's original room.";
                        break;
                    }
                    slotSettings[key] = static_cast<int>(value);
                }
                SohExtreme::EntranceRouting validated;
                std::string error;
                if (slotSettingsError.empty() &&
                    !SohExtreme::EntranceRuntime::Validate(slotSettings, validated, error))
                    slotSettingsError = "Entrance map rejected: " + error;
                slotSettingsLoaded = slotSettingsError.empty();
            }
            if (!slotSettingsLoaded) {
                slotSettings.clear();
                SPDLOG_ERROR("[Archipelago] {}", slotSettingsError);
            }
        }
        slotSettingsPendingApply.store(false);
        if (receivedItemCount == 0)
            gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected = 0;
        pendingItems.clear();
        for (uint64_t i = appliedItemCount; i < receivedItemSnapshot.size(); ++i)
            pendingItems.push_back({receivedItemSnapshot[i], false, i});
    }
    // Restore this save's settings BEFORE scene/actor initialization, even with
    // no network or a different configured room. Only verified live data may
    // replace them. Slot receipts/checks remain gated until reconciliation.
    ReconcileSaveConnection();
    if (slotSettingsLoaded) {
        ApplySlotSettings();
        slotSettingsPendingApply.store(false);
        SPDLOG_INFO("[Archipelago] Restored this save's AP settings before scene init");
    }
    SPDLOG_INFO("[Archipelago] Loaded AP save metadata: slot='{}', receive count={}", saveSlot, appliedItemCount);
}

void ArchipelagoClient::BeginItemReplay() {
    std::scoped_lock lock(queueMutex);
    incomingItemOrdinal = 0;
    receivedItemSnapshot.clear();
    pendingItems.clear();
    SPDLOG_INFO("[Archipelago] Beginning server item-state replay");
}

void ArchipelagoClient::QueueItem(int64_t itemId, bool notify) {
    std::scoped_lock lock(queueMutex);

    const uint64_t sequence = incomingItemOrdinal++;
    receivedItemSnapshot.push_back(itemId);

    // Deduplication happens on the game thread against this save's receipt cursor.
    // Reconnect can replay while an earlier major item is still being animated.
    SPDLOG_DEBUG("[Archipelago] Queued item {} at sequence {}", itemId, sequence);
    pendingItems.push_back({ itemId, notify, sequence });
}

void ArchipelagoClient::MarkItemApplied(uint64_t sequence) {
    const uint64_t newCount = sequence + 1;
    if (newCount <= appliedItemCount) return;

    // 0.7.47: the queue itself is transactional.  An AP item stays at the front
    // until the game has REALLY applied it.  Major items are removed only from
    // OnItemReceive; immediate items are removed after their give routine returns.
    // Death, void-out, scene transition, pause/cutscene blocking, or a failed
    // GiveItemEntryWithoutActor therefore cannot silently consume the queue entry.
    int64_t appliedItemId = 0;
    {
        std::scoped_lock lock(queueMutex);
        if (!pendingItems.empty() && pendingItems.front().sequence == sequence) {
            appliedItemId = pendingItems.front().id;
            pendingItems.pop_front();
        } else {
            auto it = std::find_if(pendingItems.begin(), pendingItems.end(),
                                   [sequence](const PendingItem& item) { return item.sequence == sequence; });
            if (it != pendingItems.end()) {
                appliedItemId = it->id;
                pendingItems.erase(it);
            }
        }
    }

    appliedItemCount = newCount;
    // Keep the old CVar as a migration mirror, but SaveManager's per-save field is
    // authoritative from 0.5.9 onward.
    CVarSetInteger(GetReceivedCountCVar().c_str(), static_cast<int>(appliedItemCount));
    SPDLOG_INFO("[Archipelago] Committed receive #{}; removed from queue only after grant; current save receive count is now {}", sequence, appliedItemCount);

    // Do NOT queue a full Save_SaveFile() for every AP item. SaveManager writes
    // asynchronously and Reset/Exit waits for its thread pool. A received-item burst
    // (especially a brand-new local AP file reconstructing server history) used to
    // queue dozens/hundreds of full saves and make Reset look permanently frozen.
    //
    // The normal/manual save path persists BOTH inventory/RandomizerInf and
    // archipelagoReceivedItemCount together. If gameplay reloads before a save,
    // both values revert together and APCpp's ReceivedItems replay safely grants
    // the item again, so no item can be eaten by removing this per-item autosave.
    // Do not run the Check Tracker/Check Finder reachability search on the item
    // pickup/receive frame.  SOH-EXTREME's expanded graph makes that search
    // expensive enough to cause a visible hitch whenever progression arrives.
    // Tracker availability is refreshed by normal load/slot synchronization
    // paths instead of blocking item pickup here.
    SPDLOG_DEBUG("[Archipelago] Receive #{} item {} committed", sequence, appliedItemId);

    // Available Checks is opt-in. When enabled, progression receives should make
    // the finder accurate again, but never run ReachabilitySearch inside the AP
    // receive callback itself. RecalculateAvailableChecks() only schedules one
    // deferred pass; multiple items in the same burst collapse into that one pass.
    //
    // During a new-save historical replay, wait until the replay reaches its end
    // so we do not run a world search after each reconstructed item.
    if (CVarGetInteger(CVAR_TRACKER_CHECK("EnableAvailableChecks"), 0) &&
        (gNewSaveReplayTargetCount == 0 || newCount >= gNewSaveReplayTargetCount)) {
        // Live Check Finder depends on some non-major state too (most notably
        // current Bombchu ammo).  Do not filter refreshes by advancement/major
        // classification: RecalculateAvailableChecks() is deferred/debounced, so
        // bursts still collapse to one graph pass while ammo/refills cannot leave
        // the finder stale.
        CheckTracker::RecalculateAvailableChecks();
    }
}


static bool ApplyExtremePersistentApItem(int64_t apItemId) {
    switch (apItemId) {
        case AP_ITEM_ROLL: Flags_SetRandomizerInf(RAND_INF_HAS_ROLL); return true;
        case AP_ITEM_GRAB: Flags_SetRandomizerInf(RAND_INF_CAN_GRAB); return true;
        case AP_ITEM_CLIMB: Flags_SetRandomizerInf(RAND_INF_CAN_CLIMB); return true;
        case AP_ITEM_CRAWL: Flags_SetRandomizerInf(RAND_INF_CAN_CRAWL); return true;
        case AP_ITEM_FLOW_OF_TIME: Flags_SetRandomizerInf(RAND_INF_FLOW_OF_TIME); return true;
        case AP_ITEM_SPEAK:
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_DEKU);
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_GERUDO);
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_GORON);
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_HYLIAN);
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_KOKIRI);
            Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_ZORA);
            return true;
        case AP_ITEM_SPEAK_DEKU: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_DEKU); return true;
        case AP_ITEM_SPEAK_GERUDO: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_GERUDO); return true;
        case AP_ITEM_SPEAK_GORON: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_GORON); return true;
        case AP_ITEM_SPEAK_HYLIAN: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_HYLIAN); return true;
        case AP_ITEM_SPEAK_KOKIRI: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_KOKIRI); return true;
        case AP_ITEM_SPEAK_ZORA: Flags_SetRandomizerInf(RAND_INF_CAN_SPEAK_ZORA); return true;
        case AP_ITEM_ENEMY_SOUL: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL); return true;
        case AP_ITEM_NPC_SOUL: Flags_SetRandomizerInf(RAND_INF_NPC_SOUL); return true;
        case AP_ITEM_ANIMAL_SOUL: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL); return true;
        case AP_ITEM_ANIMAL_SOUL_COW: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_COW); return true;
        case AP_ITEM_ANIMAL_SOUL_CUCCO: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_CUCCO); return true;
        case AP_ITEM_ANIMAL_SOUL_DOG: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_DOG); return true;
        case AP_ITEM_ANIMAL_SOUL_FISH: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_FISH); return true;
        case AP_ITEM_ANIMAL_SOUL_BUG: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_BUG); return true;
        case AP_ITEM_ANIMAL_SOUL_BUTTERFLY: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_BUTTERFLY); return true;
        case AP_ITEM_ANIMAL_SOUL_FROG: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_FROG); return true;
        case AP_ITEM_ANIMAL_SOUL_HORSE: Flags_SetRandomizerInf(RAND_INF_ANIMAL_SOUL_HORSE); return true;
        case AP_ITEM_ENEMY_SOUL_STALFOS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_STALFOS); return true;
        case AP_ITEM_ENEMY_SOUL_OCTOROK: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_OCTOROK); return true;
        case AP_ITEM_ENEMY_SOUL_WALLMASTER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_WALLMASTER); return true;
        case AP_ITEM_ENEMY_SOUL_DODONGO: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DODONGO); return true;
        case AP_ITEM_ENEMY_SOUL_KEESE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_KEESE); return true;
        case AP_ITEM_ENEMY_SOUL_TEKTITE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_TEKTITE); return true;
        case AP_ITEM_ENEMY_SOUL_PEAHAT: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_PEAHAT); return true;
        case AP_ITEM_ENEMY_SOUL_LIZALFOS_DINOLFOS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_LIZALFOS_DINOLFOS); return true;
        case AP_ITEM_ENEMY_SOUL_GOHMA_LARVA: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_GOHMA_LARVA); return true;
        case AP_ITEM_ENEMY_SOUL_SHABOM: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_SHABOM); return true;
        case AP_ITEM_ENEMY_SOUL_BABY_DODONGO: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_BABY_DODONGO); return true;
        case AP_ITEM_ENEMY_SOUL_BIRI_BARI: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_BIRI_BARI); return true;
        case AP_ITEM_ENEMY_SOUL_TAILPASARAN: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_TAILPASARAN); return true;
        case AP_ITEM_ENEMY_SOUL_TORCH_SLUG: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_TORCH_SLUG); return true;
        case AP_ITEM_ENEMY_SOUL_MOBLIN: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_MOBLIN); return true;
        case AP_ITEM_ENEMY_SOUL_ARMOS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_ARMOS); return true;
        case AP_ITEM_ENEMY_SOUL_DEKU_BABA: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DEKU_BABA); return true;
        case AP_ITEM_ENEMY_SOUL_DEKU_SCRUB: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DEKU_SCRUB); return true;
        case AP_ITEM_ENEMY_SOUL_BUBBLE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_BUBBLE); return true;
        case AP_ITEM_ENEMY_SOUL_BEAMOS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_BEAMOS); return true;
        case AP_ITEM_ENEMY_SOUL_FLOORMASTER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_FLOORMASTER); return true;
        case AP_ITEM_ENEMY_SOUL_REDEAD_GIBDO: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_REDEAD_GIBDO); return true;
        case AP_ITEM_ENEMY_SOUL_FLARE_DANCER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_FLARE_DANCER); return true;
        case AP_ITEM_ENEMY_SOUL_DEAD_HAND: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DEAD_HAND); return true;
        case AP_ITEM_ENEMY_SOUL_SHELL_BLADE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_SHELL_BLADE); return true;
        case AP_ITEM_ENEMY_SOUL_LIKE_LIKE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_LIKE_LIKE); return true;
        case AP_ITEM_ENEMY_SOUL_SPIKE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_SPIKE); return true;
        case AP_ITEM_ENEMY_SOUL_ANUBIS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_ANUBIS); return true;
        case AP_ITEM_ENEMY_SOUL_IRON_KNUCKLE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_IRON_KNUCKLE); return true;
        case AP_ITEM_ENEMY_SOUL_SKULL_KID: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_SKULL_KID); return true;
        case AP_ITEM_ENEMY_SOUL_FLYING_POT: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_FLYING_POT); return true;
        case AP_ITEM_ENEMY_SOUL_FREEZARD: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_FREEZARD); return true;
        case AP_ITEM_ENEMY_SOUL_STINGER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_STINGER); return true;
        case AP_ITEM_ENEMY_SOUL_WOLFOS: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_WOLFOS); return true;
        case AP_ITEM_ENEMY_SOUL_GUAY: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_GUAY); return true;
        case AP_ITEM_ENEMY_SOUL_JABU_TENTACLE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_JABU_TENTACLE); return true;
        case AP_ITEM_ENEMY_SOUL_DARK_LINK: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DARK_LINK); return true;
        case AP_ITEM_ENEMY_SOUL_DOOR_TRAP: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_DOOR_TRAP); return true;
        case AP_ITEM_ENEMY_SOUL_FLYING_FLOOR_TILE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_FLYING_FLOOR_TILE); return true;
        case AP_ITEM_ENEMY_SOUL_GERUDO_THIEF: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_GERUDO_THIEF); return true;
        case AP_ITEM_ENEMY_SOUL_POE_SISTER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_POE_SISTER); return true;
        case AP_ITEM_ENEMY_SOUL_POE: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_POE); return true;
        case AP_ITEM_ENEMY_SOUL_LEEVER: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_LEEVER); return true;
        case AP_ITEM_ENEMY_SOUL_STALCHILD: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_STALCHILD); return true;
        case AP_ITEM_ENEMY_SOUL_BIG_OCTO: Flags_SetRandomizerInf(RAND_INF_ENEMY_SOUL_BIG_OCTO); return true;

        case AP_ITEM_POT_SOUL: Flags_SetRandomizerInf(RAND_INF_POT_SOUL); return true;
        case AP_ITEM_CRATE_SOUL: Flags_SetRandomizerInf(RAND_INF_CRATE_SOUL); return true;
        case AP_ITEM_GRASS_SOUL: Flags_SetRandomizerInf(RAND_INF_GRASS_SOUL); return true;
        case AP_ITEM_ROCK_SOUL: Flags_SetRandomizerInf(RAND_INF_ROCK_SOUL); return true;
        case AP_ITEM_TREE_SOUL: Flags_SetRandomizerInf(RAND_INF_TREE_SOUL); return true;
        case AP_ITEM_BEEHIVE_SOUL: Flags_SetRandomizerInf(RAND_INF_BEEHIVE_SOUL); return true;
        case AP_ITEM_SIGN_SOUL: Flags_SetRandomizerInf(RAND_INF_SIGN_SOUL); return true;
        case AP_ITEM_SKULLTULA_SOUL: Flags_SetRandomizerInf(RAND_INF_SKULLTULA_SOUL); return true;
        case AP_ITEM_BUSINESS_SCRUB_SOUL: Flags_SetRandomizerInf(RAND_INF_BUSINESS_SCRUB_SOUL); return true;
        case AP_ITEM_SHOVEL: Flags_SetRandomizerInf(RAND_INF_HAS_SHOVEL); return true;
        case AP_ITEM_DMC_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_DEATH_MOUNTAIN_CRATER_BEAN_SOUL); return true;
        case AP_ITEM_DMT_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_DEATH_MOUNTAIN_TRAIL_BEAN_SOUL); return true;
        case AP_ITEM_COLOSSUS_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_DESERT_COLOSSUS_BEAN_SOUL); return true;
        case AP_ITEM_GV_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_GERUDO_VALLEY_BEAN_SOUL); return true;
        case AP_ITEM_GRAVEYARD_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_GRAVEYARD_BEAN_SOUL); return true;
        case AP_ITEM_KF_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_KOKIRI_FOREST_BEAN_SOUL); return true;
        case AP_ITEM_LH_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_LAKE_HYLIA_BEAN_SOUL); return true;
        case AP_ITEM_LW_BRIDGE_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_LOST_WOODS_BRIDGE_BEAN_SOUL); return true;
        case AP_ITEM_LW_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_LOST_WOODS_BEAN_SOUL); return true;
        case AP_ITEM_ZR_BEAN_SOUL: Flags_SetRandomizerInf(RAND_INF_ZORAS_RIVER_BEAN_SOUL); return true;
        default: return false;
    }
}

void ArchipelagoClient::FinalizeMajorItemReceipt(int modIndex, int itemId, int getItemId) {
    if (!awaitingMajorItemReceipt) return;

    // Vanilla Item_Give can canonicalize GetItemID aliases, but preserves the
    // mod/item identity. Randomizer receipts preserve their complete entry.
    if (modIndex != awaitingMajorModIndex || itemId != awaitingMajorItemId ||
        (modIndex == MOD_RANDOMIZER && getItemId != awaitingMajorGetItemId)) {
        SPDLOG_DEBUG("[Archipelago] Ignoring unrelated item callback while AP receive is pending");
        return;
    }
    const uint64_t sequence = awaitingMajorSequence;
    const int64_t apItemId = awaitingMajorApItemId;

    // Native grants have completed. Verify idempotent custom progression here,
    // never when the engine has merely accepted a get-item offer.
    if (ApplyExtremePersistentApItem(apItemId)) {
        const auto rg = static_cast<RandomizerGet>(getItemId);
        auto flag = Rando::StaticData::RandoGetToRandInf.find(rg);
        if (flag != Rando::StaticData::RandoGetToRandInf.end() &&
            !Flags_GetRandomizerInf(static_cast<RandomizerInf>(flag->second))) return;
    }

    if (IsApSongNote(apItemId)) {
        if (!ApplyApSongNote(apItemId)) return;
        RefreshSongNotes();
    }

    if (apItemId == AP_ITEM_PROGRESSIVE_WALLET && RAND_GET_OPTION(RSK_FULL_WALLETS).Get()) {
        // The native grant has installed the new capacity. Finish the fill now,
        // including repeat/capped wallets, without a delayed rupee accumulator.
        gSaveContext.rupees = static_cast<s16>(CUR_CAPACITY(UPG_WALLET));
        gSaveContext.rupeeAccumulator = 0;
    }

    awaitingMajorItemReceipt = false;
    awaitingMajorSequence = 0;
    awaitingMajorApItemId = 0;
    gAwaitingMajorFrames = 0;

    SPDLOG_INFO("[Archipelago] Major AP item {} receive #{} verified in persistent state; committing now",
                apItemId, sequence);
    MarkItemApplied(sequence);
    Notification::Emit({
        .prefix = "Archipelago",
        .message = "received",
        .suffix = GetApItemDisplayName(apItemId),
        .remainingTime = 4.0f,
    });
}

void ArchipelagoClient::PrimeNewSaveMetadata() {
    // File creation must stay as close as possible to a normal randomizer save.
    // Do not rebuild the ReceivedItems queue here: APCpp may still be publishing a
    // large replay/scout response and queueMutex contention can stall name-entry
    // creation.  Only stamp the durable AP identity/settings needed by SaveManager.
    std::scoped_lock lock(queueMutex);

    // This method is called only when creating a new AP file. Completed-hint
    // rows from a previous file must not enter this file's first snapshot.
    // Ordinary same-save reloads retain their journal in LoadSaveMetadata.
    {
        std::scoped_lock hintLock(hintJournalMutex);
        revealedHintTargets.clear();
    }
    nextHintPublish = 0.0;

    appliedItemCount = 0;
    pendingLocationReports.clear();
    awaitingMajorItemReceipt = false;
    awaitingMajorSequence = 0;
    awaitingMajorApItemId = 0;
    gAwaitingMajorFrames = 0;
    currentSaveIsArchipelago = true;
    newSaveReplayPending = true;
    saveMetadataLoaded = true;
    gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected = 0;
    saveIdentityMismatch = false;

    saveServer = connectedServer;
    saveSlot = connectedSlot;
    saveConnectionIdentity = connectedIdentity;
    RebuildHints();

    CVarSetInteger(GetReceivedCountCVar().c_str(), 0);
    pendingItems.clear();
    gDeferredLocationReports.clear();

    SPDLOG_INFO("[Archipelago] Primed new AP save metadata; item history replay deferred until gameplay");
}

void ArchipelagoClient::PrepareNewSaveItemReplay() {
    fallbackNpcSpeechHashes.clear();
    fallbackNpcSpeechSeen.clear();

    std::scoped_lock lock(queueMutex);
    newSaveReplayPending = false;

    // A deliberately-created new AP save starts from a clean SoH inventory, so replay
    // the server's current item history exactly once into that new save.  This also
    // means deleting/recreating a local file does not permanently lose AP starting
    // inventory just because the server remembers that it was delivered before.
    appliedItemCount = 0;
    awaitingMajorItemReceipt = false;
    awaitingMajorSequence = 0;
    awaitingMajorApItemId = 0;
    gAwaitingMajorFrames = 0;
    currentSaveIsArchipelago = true;
    saveMetadataLoaded = true;
    saveIdentityMismatch = false;
    saveServer = connectedServer;
    saveSlot = connectedSlot;
    saveConnectionIdentity = connectedIdentity;
    CVarSetInteger(GetReceivedCountCVar().c_str(), 0); // legacy migration mirror only
    pendingItems.clear();
    gDeferredLocationReports.clear();
    gNewSaveReplayTargetCount = receivedItemSnapshot.size();
    gNewSaveReplayGraceFrames = AP_NEW_SAVE_REPLAY_GRACE_FRAMES;
    for (uint64_t i = 0; i < receivedItemSnapshot.size(); ++i) {
        // Historical reconstruction is intentionally silent. The player already
        // received these server-side; this pass only rebuilds the new local save.
        pendingItems.push_back({ receivedItemSnapshot[i], false, i });
    }
    SPDLOG_INFO("[Archipelago] New AP save: queued {} historical received items for fast one-time reconstruction "
                "after {} grace frames",
                pendingItems.size(), gNewSaveReplayGraceFrames);
}

void ArchipelagoClient::QueueCheckedLocation(int64_t locationId) {
    std::scoped_lock lock(queueMutex);
    pendingCheckedLocations.push_back(locationId);
}

void ArchipelagoClient::QueueLocationInfo(int64_t locationId, int64_t itemId, int playerId, int flags,
                                          const std::string& itemName, const std::string& playerName,
                                          const std::string& locationName, const std::string& itemGame) {
    std::scoped_lock lock(queueMutex);
    PendingScout scout;
    scout.locationId = locationId;
    scout.info.itemId = itemId;
    scout.info.playerId = playerId;
    scout.info.flags = flags;
    scout.info.itemName = itemName;
    scout.info.playerName = playerName;
    scout.info.locationName = locationName;
    scout.info.itemGame = itemGame;
    pendingScouts.push_back(std::move(scout));
}

int32_t ArchipelagoClient::MapApItemToRandomizerGet(int64_t itemId) const {
    // ArchipelagoItemMap.inc is an assignment table.  It expects a local
    // variable named `randoGet`; it is shared with ProcessItem below.
    RandomizerGet randoGet = RG_NONE;

    if (itemId >= AP_BASE_ITEM_MIN && itemId <= AP_BASE_ITEM_MAX) {
        switch (itemId) {
#include "ArchipelagoItemMap.inc"
            default: break;
        }
        return static_cast<int32_t>(randoGet);
    }

    switch (itemId) {
        case AP_ITEM_ROLL: randoGet = RG_ROLL; break;
        case AP_ITEM_GRAB: randoGet = RG_POWER_BRACELET; break;
        case AP_ITEM_CLIMB: randoGet = RG_CLIMB; break;
        case AP_ITEM_CRAWL: randoGet = RG_CRAWL; break;
        case AP_ITEM_SPEAK: randoGet = RG_SPEAK_HYLIAN; break;
        case AP_ITEM_OPEN_CHEST: randoGet = RG_OPEN_CHEST; break;
        case AP_ITEM_ENEMY_SOUL: randoGet = RG_ENEMY_SOUL; break;
        case AP_ITEM_NPC_SOUL: randoGet = RG_NPC_SOUL; break;
        case AP_ITEM_ANIMAL_SOUL: randoGet = RG_ANIMAL_SOUL; break;
        case AP_ITEM_POT_SOUL: randoGet = RG_POT_SOUL; break;
        case AP_ITEM_CRATE_SOUL: randoGet = RG_CRATE_SOUL; break;
        case AP_ITEM_GRASS_SOUL: randoGet = RG_GRASS_SOUL; break;
        case AP_ITEM_ROCK_SOUL: randoGet = RG_ROCK_SOUL; break;
        case AP_ITEM_TREE_SOUL: randoGet = RG_TREE_SOUL; break;
        case AP_ITEM_BEEHIVE_SOUL: randoGet = RG_BEEHIVE_SOUL; break;
        case AP_ITEM_SIGN_SOUL: randoGet = RG_SIGN_SOUL; break;
        case AP_ITEM_SKULLTULA_SOUL: randoGet = RG_SKULLTULA_SOUL; break;
        case AP_ITEM_BUSINESS_SCRUB_SOUL: randoGet = RG_BUSINESS_SCRUB_SOUL; break;
        case AP_ITEM_SHOVEL: randoGet = RG_SHOVEL; break;
        case AP_ITEM_FLOW_OF_TIME: randoGet = RG_FLOW_OF_TIME; break;
        case AP_ITEM_DMC_BEAN_SOUL: randoGet = RG_DEATH_MOUNTAIN_CRATER_BEAN_SOUL; break;
        case AP_ITEM_DMT_BEAN_SOUL: randoGet = RG_DEATH_MOUNTAIN_TRAIL_BEAN_SOUL; break;
        case AP_ITEM_COLOSSUS_BEAN_SOUL: randoGet = RG_DESERT_COLOSSUS_BEAN_SOUL; break;
        case AP_ITEM_GV_BEAN_SOUL: randoGet = RG_GERUDO_VALLEY_BEAN_SOUL; break;
        case AP_ITEM_GRAVEYARD_BEAN_SOUL: randoGet = RG_GRAVEYARD_BEAN_SOUL; break;
        case AP_ITEM_KF_BEAN_SOUL: randoGet = RG_KOKIRI_FOREST_BEAN_SOUL; break;
        case AP_ITEM_LH_BEAN_SOUL: randoGet = RG_LAKE_HYLIA_BEAN_SOUL; break;
        case AP_ITEM_LW_BRIDGE_BEAN_SOUL: randoGet = RG_LOST_WOODS_BRIDGE_BEAN_SOUL; break;
        case AP_ITEM_LW_BEAN_SOUL: randoGet = RG_LOST_WOODS_BEAN_SOUL; break;
        case AP_ITEM_ZR_BEAN_SOUL: randoGet = RG_ZORAS_RIVER_BEAN_SOUL; break;
        case AP_ITEM_SPEAK_DEKU: randoGet = RG_SPEAK_DEKU; break;
        case AP_ITEM_SPEAK_GERUDO: randoGet = RG_SPEAK_GERUDO; break;
        case AP_ITEM_SPEAK_GORON: randoGet = RG_SPEAK_GORON; break;
        case AP_ITEM_SPEAK_HYLIAN: randoGet = RG_SPEAK_HYLIAN; break;
        case AP_ITEM_SPEAK_KOKIRI: randoGet = RG_SPEAK_KOKIRI; break;
        case AP_ITEM_SPEAK_ZORA: randoGet = RG_SPEAK_ZORA; break;
        case AP_ITEM_ANIMAL_SOUL_COW: randoGet = RG_ANIMAL_SOUL_COW; break;
        case AP_ITEM_ANIMAL_SOUL_CUCCO: randoGet = RG_ANIMAL_SOUL_CUCCO; break;
        case AP_ITEM_ANIMAL_SOUL_DOG: randoGet = RG_ANIMAL_SOUL_DOG; break;
        case AP_ITEM_ANIMAL_SOUL_FISH: randoGet = RG_ANIMAL_SOUL_FISH; break;
        case AP_ITEM_ANIMAL_SOUL_BUG: randoGet = RG_ANIMAL_SOUL_BUG; break;
        case AP_ITEM_ANIMAL_SOUL_BUTTERFLY: randoGet = RG_ANIMAL_SOUL_BUTTERFLY; break;
        case AP_ITEM_ANIMAL_SOUL_FROG: randoGet = RG_ANIMAL_SOUL_FROG; break;
        case AP_ITEM_ANIMAL_SOUL_HORSE: randoGet = RG_ANIMAL_SOUL_HORSE; break;
        case AP_ITEM_ENEMY_SOUL_STALFOS: randoGet = RG_ENEMY_SOUL_STALFOS; break;
        case AP_ITEM_ENEMY_SOUL_OCTOROK: randoGet = RG_ENEMY_SOUL_OCTOROK; break;
        case AP_ITEM_ENEMY_SOUL_WALLMASTER: randoGet = RG_ENEMY_SOUL_WALLMASTER; break;
        case AP_ITEM_ENEMY_SOUL_DODONGO: randoGet = RG_ENEMY_SOUL_DODONGO; break;
        case AP_ITEM_ENEMY_SOUL_KEESE: randoGet = RG_ENEMY_SOUL_KEESE; break;
        case AP_ITEM_ENEMY_SOUL_TEKTITE: randoGet = RG_ENEMY_SOUL_TEKTITE; break;
        case AP_ITEM_ENEMY_SOUL_PEAHAT: randoGet = RG_ENEMY_SOUL_PEAHAT; break;
        case AP_ITEM_ENEMY_SOUL_LIZALFOS_DINOLFOS: randoGet = RG_ENEMY_SOUL_LIZALFOS_DINOLFOS; break;
        case AP_ITEM_ENEMY_SOUL_GOHMA_LARVA: randoGet = RG_ENEMY_SOUL_GOHMA_LARVA; break;
        case AP_ITEM_ENEMY_SOUL_SHABOM: randoGet = RG_ENEMY_SOUL_SHABOM; break;
        case AP_ITEM_ENEMY_SOUL_BABY_DODONGO: randoGet = RG_ENEMY_SOUL_BABY_DODONGO; break;
        case AP_ITEM_ENEMY_SOUL_BIRI_BARI: randoGet = RG_ENEMY_SOUL_BIRI_BARI; break;
        case AP_ITEM_ENEMY_SOUL_TAILPASARAN: randoGet = RG_ENEMY_SOUL_TAILPASARAN; break;
        case AP_ITEM_ENEMY_SOUL_TORCH_SLUG: randoGet = RG_ENEMY_SOUL_TORCH_SLUG; break;
        case AP_ITEM_ENEMY_SOUL_MOBLIN: randoGet = RG_ENEMY_SOUL_MOBLIN; break;
        case AP_ITEM_ENEMY_SOUL_ARMOS: randoGet = RG_ENEMY_SOUL_ARMOS; break;
        case AP_ITEM_ENEMY_SOUL_DEKU_BABA: randoGet = RG_ENEMY_SOUL_DEKU_BABA; break;
        case AP_ITEM_ENEMY_SOUL_DEKU_SCRUB: randoGet = RG_ENEMY_SOUL_DEKU_SCRUB; break;
        case AP_ITEM_ENEMY_SOUL_BUBBLE: randoGet = RG_ENEMY_SOUL_BUBBLE; break;
        case AP_ITEM_ENEMY_SOUL_BEAMOS: randoGet = RG_ENEMY_SOUL_BEAMOS; break;
        case AP_ITEM_ENEMY_SOUL_FLOORMASTER: randoGet = RG_ENEMY_SOUL_FLOORMASTER; break;
        case AP_ITEM_ENEMY_SOUL_REDEAD_GIBDO: randoGet = RG_ENEMY_SOUL_REDEAD_GIBDO; break;
        case AP_ITEM_ENEMY_SOUL_FLARE_DANCER: randoGet = RG_ENEMY_SOUL_FLARE_DANCER; break;
        case AP_ITEM_ENEMY_SOUL_DEAD_HAND: randoGet = RG_ENEMY_SOUL_DEAD_HAND; break;
        case AP_ITEM_ENEMY_SOUL_SHELL_BLADE: randoGet = RG_ENEMY_SOUL_SHELL_BLADE; break;
        case AP_ITEM_ENEMY_SOUL_LIKE_LIKE: randoGet = RG_ENEMY_SOUL_LIKE_LIKE; break;
        case AP_ITEM_ENEMY_SOUL_SPIKE: randoGet = RG_ENEMY_SOUL_SPIKE; break;
        case AP_ITEM_ENEMY_SOUL_ANUBIS: randoGet = RG_ENEMY_SOUL_ANUBIS; break;
        case AP_ITEM_ENEMY_SOUL_IRON_KNUCKLE: randoGet = RG_ENEMY_SOUL_IRON_KNUCKLE; break;
        case AP_ITEM_ENEMY_SOUL_SKULL_KID: randoGet = RG_ENEMY_SOUL_SKULL_KID; break;
        case AP_ITEM_ENEMY_SOUL_FLYING_POT: randoGet = RG_ENEMY_SOUL_FLYING_POT; break;
        case AP_ITEM_ENEMY_SOUL_FREEZARD: randoGet = RG_ENEMY_SOUL_FREEZARD; break;
        case AP_ITEM_ENEMY_SOUL_STINGER: randoGet = RG_ENEMY_SOUL_STINGER; break;
        case AP_ITEM_ENEMY_SOUL_WOLFOS: randoGet = RG_ENEMY_SOUL_WOLFOS; break;
        case AP_ITEM_ENEMY_SOUL_GUAY: randoGet = RG_ENEMY_SOUL_GUAY; break;
        case AP_ITEM_ENEMY_SOUL_JABU_TENTACLE: randoGet = RG_ENEMY_SOUL_JABU_TENTACLE; break;
        case AP_ITEM_ENEMY_SOUL_DARK_LINK: randoGet = RG_ENEMY_SOUL_DARK_LINK; break;
        case AP_ITEM_ENEMY_SOUL_DOOR_TRAP: randoGet = RG_ENEMY_SOUL_DOOR_TRAP; break;
        case AP_ITEM_ENEMY_SOUL_FLYING_FLOOR_TILE: randoGet = RG_ENEMY_SOUL_FLYING_FLOOR_TILE; break;
        case AP_ITEM_ENEMY_SOUL_GERUDO_THIEF: randoGet = RG_ENEMY_SOUL_GERUDO_THIEF; break;
        case AP_ITEM_ENEMY_SOUL_POE_SISTER: randoGet = RG_ENEMY_SOUL_POE_SISTER; break;
        case AP_ITEM_ENEMY_SOUL_POE: randoGet = RG_ENEMY_SOUL_POE; break;
        case AP_ITEM_ENEMY_SOUL_LEEVER: randoGet = RG_ENEMY_SOUL_LEEVER; break;
        case AP_ITEM_ENEMY_SOUL_STALCHILD: randoGet = RG_ENEMY_SOUL_STALCHILD; break;
        case AP_ITEM_ENEMY_SOUL_BIG_OCTO: randoGet = RG_ENEMY_SOUL_BIG_OCTO; break;

        case AP_ITEM_SHADOW_SILVER_BLADES: randoGet = RG_SHADOW_SILVER_BLADES; break;
        case AP_ITEM_SHADOW_SILVER_PIT: randoGet = RG_SHADOW_SILVER_PIT; break;
        case AP_ITEM_SHADOW_SILVER_SPIKES: randoGet = RG_SHADOW_SILVER_SPIKES; break;
        case AP_ITEM_SPIRIT_SILVER_CHILD: randoGet = RG_SPIRIT_SILVER_CHILD; break;
        case AP_ITEM_SPIRIT_SILVER_SUN: randoGet = RG_SPIRIT_SILVER_SUN; break;
        case AP_ITEM_SPIRIT_SILVER_BOULDERS: randoGet = RG_SPIRIT_SILVER_BOULDERS; break;
        case AP_ITEM_BOTW_SILVER: randoGet = RG_BOTW_SILVER; break;
        case AP_ITEM_ICE_CAVERN_SILVER_BLADES: randoGet = RG_ICE_CAVERN_SILVER_BLADES; break;
        case AP_ITEM_ICE_CAVERN_SILVER_BLOCK: randoGet = RG_ICE_CAVERN_SILVER_BLOCK; break;
        case AP_ITEM_GTG_SILVER_SLOPE: randoGet = RG_GTG_SILVER_SLOPE; break;
        case AP_ITEM_GTG_SILVER_LAVA: randoGet = RG_GTG_SILVER_LAVA; break;
        case AP_ITEM_GTG_SILVER_WATER: randoGet = RG_GTG_SILVER_WATER; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_LIGHT: randoGet = RG_GANONS_CASTLE_SILVER_LIGHT; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_FOREST: randoGet = RG_GANONS_CASTLE_SILVER_FOREST; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_FIRE: randoGet = RG_GANONS_CASTLE_SILVER_FIRE; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_SPIRIT: randoGet = RG_GANONS_CASTLE_SILVER_SPIRIT; break;
        case AP_ITEM_DODONGOS_CAVERN_MQ_SILVER: randoGet = RG_DODONGOS_CAVERN_MQ_SILVER; break;
        case AP_ITEM_SHADOW_MQ_SILVER_INVISIBLE_BLADES: randoGet = RG_SHADOW_MQ_SILVER_INVISIBLE_BLADES; break;
        case AP_ITEM_SPIRIT_MQ_SILVER_LOBBY: randoGet = RG_SPIRIT_MQ_SILVER_LOBBY; break;
        case AP_ITEM_SPIRIT_MQ_SILVER_BIG_WALL: randoGet = RG_SPIRIT_MQ_SILVER_BIG_WALL; break;
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_WATER: randoGet = RG_GANONS_CASTLE_MQ_SILVER_WATER; break;
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_SHADOW: randoGet = RG_GANONS_CASTLE_MQ_SILVER_SHADOW; break;
        default:
            if (IsApSongNote(itemId)) {
                randoGet = GetApSongNoteDisplay(itemId); // receipt grants the legacy or next progressive note flag
            }
            break;
    }

    return static_cast<int32_t>(randoGet);
}

static bool ParseFlatStringIntObject(const std::string& raw, std::unordered_map<std::string, int64_t>& out) {
    const auto json = nlohmann::json::parse(raw, nullptr, false);
    if (!json.is_object()) return false;
    std::unordered_map<std::string, int64_t> parsed;
    for (const auto& entry : json.items()) {
        if (!entry.value().is_number_integer() ||
            (entry.value().is_number_unsigned() && entry.value().get<uint64_t>() > INT64_MAX)) return false;
        parsed.emplace(entry.key(), entry.value().get<int64_t>());
    }
    out = std::move(parsed);
    return true;
}

static void RefreshArchipelagoRandomizerHooks() {
    // IMPORTANT: use Ship's own native randomizer refresh path instead of trying
    // to maintain a hand-written list of shuffle modules here.  Normal SoH calls
    // this exact dependency path from the randomizer OnLoadGame hook after
    // IS_RANDO becomes true.  AP changes the quest/settings outside the normal
    // randomizer menu, so without this call modules that were disabled at boot
    // keep their hooks unregistered (MegaSouls was the most visible example: a
    // Pot Soul slot could be ON while pots still spawned normally).
    //
    // Running the complete IS_RANDO dependency makes AP behave the same as a
    // normally configured SoH randomizer save and automatically includes future
    // modules that register with RegisterShipInitFunc(..., { "IS_RANDO" }).
    ShipInit::Init("IS_RANDO");
    SPDLOG_INFO("[Archipelago] Refreshed ALL native IS_RANDO hooks from authoritative AP settings");
}

void ArchipelagoClient::QueueSlotData(const std::string& key, const std::string& raw) {
    if (raw.size() > 8 * 1024 * 1024) {
        SPDLOG_ERROR("[Archipelago] Ignoring oversized slot data {}", key);
        return;
    }
    std::scoped_lock lock(queueMutex);
    pendingSlotData[key] = raw;
}

void ArchipelagoClient::DrainSlotData() {
    std::unordered_map<std::string, std::string> updates;
    {
        std::scoped_lock lock(queueMutex);
        updates.swap(pendingSlotData);
    }
    // Establish ownership before processing any live settings from this batch.
    const auto identity = updates.find("_soh_connection_identity");
    if (identity != updates.end()) SetConnectionIdentityFromJson(identity->second);
    ReconcileSaveConnection();
    // Called only on the game thread, including the file-select readiness path.
    for (const auto& [key, raw] : updates) {
        if (key == "extreme_soh_cvars") {
            connectedSettingsJson = raw;
            if (!currentSaveIsArchipelago || !saveIdentityMismatch) SetSlotSettingsFromJson(raw);
        }
        else if (key == "extreme_shop_prices") SetShopPricesFromJson(raw);
        else if (key == "extreme_active_locations") SetActiveLocationsFromJson(raw);
        else if (key == "extreme_location_name_to_id") SetLocationNameMapFromJson(raw);
        else if (key == "death_link") deathLinkEnabled = raw == "1";
        else if (key == "trap_link") trapLinkEnabled = raw == "1";
        else if (key == "extreme_kakariko_gate_open") kakarikoGateOpen = raw == "1";
    }
}

void ArchipelagoClient::SetSlotSettingsFromJson(const std::string& raw) {
    // Reconciliation runs every frame. Keep a rejected snapshot visible without
    // reparsing or logging it repeatedly until the server supplies new settings.
    if (!rejectedSlotSettingsJson.empty() && raw == rejectedSlotSettingsJson) return;
    auto reject = [this, &raw](const std::string& message) {
        slotSettingsError = message;
        rejectedSlotSettingsJson = raw;
    };
    std::unordered_map<std::string, int64_t> parsed;
    if (!ParseFlatStringIntObject(raw, parsed)) {
        reject("The server's AP settings could not be read. Check the matching APWorld and reconnect.");
        SPDLOG_ERROR("[Archipelago] Invalid extreme_soh_cvars slot data");
        return;
    }

    std::unordered_map<std::string, int> nextSettings;
    nextSettings.reserve(parsed.size());
    for (const auto& [key, value] : parsed) {
        if (value < std::numeric_limits<int>::min() || value > std::numeric_limits<int>::max()) {
            reject("An AP slot setting is out of range. Check the matching APWorld and reconnect.");
            SPDLOG_ERROR("[Archipelago] Slot setting {} is out of range", key);
            return;
        }
        nextSettings[key] = static_cast<int>(value);
    }

    // These native-only rules are not part of the AP ruleset. Old seeds did
    // not publish them and must not inherit a local randomizer menu selection.
    static const std::unordered_map<std::string, int> nativeDefaults = {
#include "ArchipelagoNativeDefaults.inc"
    };
    for (const auto& [key, value] : nativeDefaults) nextSettings.try_emplace(key, value);
    const auto fishMode = nextSettings.find("Fishsanity");
    if (fishMode != nextSettings.end()) {
        const bool pond = fishMode->second == RO_FISHSANITY_POND || fishMode->second == RO_FISHSANITY_BOTH;
        nextSettings.try_emplace("FishsanityPondCount", pond ? 17 : 0);
        nextSettings.try_emplace("FishsanityAgeSplit", pond ? 1 : 0);
    }

    // A complete settings snapshot is not ready until its entrance map can be
    // installed. Reject before changing cached settings, CVars or file creation.
    SohExtreme::EntranceRouting validated;
    std::string entranceError;
    if (!SohExtreme::EntranceRuntime::Validate(nextSettings, validated, entranceError)) {
        reject("Entrance map rejected: " + entranceError);
        SPDLOG_ERROR("[Archipelago] {}", slotSettingsError);
        return;
    }

    size_t loadedCount = 0;
    bool settingsChanged = false;
    {
        std::scoped_lock lock(queueMutex);
        settingsChanged = !slotSettingsLoaded || cachedSlotSettingsJson != raw;
        slotSettings = std::move(nextSettings);
        cachedSlotSettingsJson = raw;
        slotSettingsLoaded = true;
        slotSettingsError.clear();
        rejectedSlotSettingsJson.clear();
        loadedCount = slotSettings.size();
    }

    // APCpp can invoke this callback away from the gameplay thread. Do not
    // mutate CVars, native Settings/Context, ShipInit hooks, or tracker state here.
    if (settingsChanged) {
        slotSettingsPendingApply.store(true);
        SPDLOG_INFO("[Archipelago] Cached {} changed authoritative SoH/Extreme settings for gameplay-thread apply",
                    loadedCount);
    } else {
        SPDLOG_DEBUG("[Archipelago] Live AP settings match the already-applied/cached snapshot; skipping duplicate refresh");
    }
}

void ArchipelagoClient::SetLocationNameMapFromJson(const std::string& raw) {
    std::unordered_map<std::string, int64_t> parsed;
    if (!ParseFlatStringIntObject(raw, parsed)) {
        SPDLOG_ERROR("[Archipelago] Invalid extreme_location_name_to_id slot data");
        return;
    }

    std::unordered_map<std::string, int64_t> next;
    next.reserve(parsed.size());
    for (const auto& [name, locationId] : parsed) {
        const std::string normalized = NormalizeApLocationName(name);
        if (normalized.empty()) {
            continue;
        }
        auto [it, inserted] = next.emplace(normalized, locationId);
        if (!inserted && it->second != locationId) {
            // Never guess if two server locations collapse to the same normalized name.
            it->second = -1;
        }
    }

    {
        std::scoped_lock lock(queueMutex);
        authoritativeLocationNameIndex = std::move(next);
        locationNameMapLoaded = true;
        checkFinderMappingsPrepared = false;
    }

    SPDLOG_INFO("[Archipelago] Loaded {} authoritative SOH-EXTREME location name mappings",
                authoritativeLocationNameIndex.size());
}

void ArchipelagoClient::SetShopPricesFromJson(const std::string& raw) {
    std::unordered_map<std::string, int64_t> parsed;
    if (!ParseFlatStringIntObject(raw, parsed)) {
        SPDLOG_ERROR("[Archipelago] Invalid extreme_shop_prices slot data");
        return;
    }
    shopPrices.clear();
    for (const auto& [key, value] : parsed) {
        try {
            const int64_t location = std::stoll(key);
            shopPrices[location] = static_cast<uint16_t>(std::clamp<int64_t>(value, 0, 65535));
        } catch (...) {
            SPDLOG_WARN("[Archipelago] Ignoring malformed shop location id {}", key);
        }
    }
    shopPricesLoaded = true;
    SPDLOG_INFO("[Archipelago] Loaded {} exact AP shop prices", shopPrices.size());
}

static void ApplyLegacySongNoteMask(std::unordered_map<std::string, int>& settings) {
    const auto songNotes = settings.find("SongNoteShuffle");
    const bool enabled = songNotes != settings.end() && songNotes->second != 0;
    // Defaults come from this slot, never the previously loaded AP/native save.
    // Preserve an explicit selection (including zero) from current generators.
    settings.try_emplace("SongNoteSongMask", enabled ? 0x0FFF : 0);
}

void ArchipelagoClient::ApplySlotSettings() {
    slotSettingsPendingApply.store(false);
    std::unordered_map<std::string, int> settingsSnapshot;
    {
        std::scoped_lock lock(queueMutex);
        if (!slotSettingsLoaded) {
            return;
        }
        if (ammoSourceSettingsJson != cachedSlotSettingsJson) {
            ResetAmmoSources();
            ammoSourceSettingsJson = cachedSlotSettingsJson;
        }
        const auto fish = slotSettings.find("Fishsanity");
        if (fish != slotSettings.end()) {
            const bool pond = fish->second == RO_FISHSANITY_POND || fish->second == RO_FISHSANITY_BOTH;
            slotSettings.try_emplace("FishsanityPondCount", pond ? 17 : 0);
            slotSettings.try_emplace("FishsanityAgeSplit", pond ? 1 : 0);
        }
        // Legacy slots have no traversal locations. Do not inherit this flag
        // from the previously connected save's AP-only CVars.
        slotSettings.try_emplace("SceneTransitionChecks", 0);
        slotSettings.try_emplace("SceneTransitionCatalogVersion", 0);
        // Old seeds have no entrance mapping. Never inherit a previous AP
        // save's native shuffle flags or the user's local randomizer menu.
        for (const char* key : { "EntranceRandomizerRevision", "DecoupleEntrances",
             "ShuffleInteriorsEntrances", "ShuffleThievesHideoutEntrances", "ShuffleDungeonsEntrances",
             "ShuffleGanonTowerEntrance", "ShuffleBossEntrances", "ShuffleGrottosEntrances",
             "ShuffleOverworldEntrances", "ShuffleOwlDrops", "ShuffleWarpSongs", "ShuffleOverworldSpawns",
             "ShuffleDungeonDoors", "EntrancePoolPolicyRevision", "EntranceMixedPoolMask", "DungeonDoorMixedOutside",
             "MixedEntrances", "MixDungeons", "MixBosses", "MixInteriors",
             "MixOverworld", "MixGrottos" }) {
            slotSettings.try_emplace(key, 0);
        }
        // AP routes include Bunny Hood speed/jumps. Upgrade old cached/server
        // settings too; the effect still requires wearing the actual hood.
        slotSettings["BunnyHood"] = 1;
        ApplyLegacySongNoteMask(slotSettings);
        settingsSnapshot = slotSettings;
    }

    SPDLOG_INFO("[Archipelago] SOH-EXTREME AP settings runtime {} active", SohExtreme::kTrackerVersion);

    // APWorld sends extreme_soh_cvars using the *native option suffixes*
    // (ShufflePots, ShuffleGrass, PotSoul, etc.).  Do NOT reconstruct the CVar
    // prefix here.  Ship's Option table is the authority for the exact CVar name
    // consumed by Option::GetOptionIndex()/RAND_GET_OPTION().
    //
    // This fixes the failure where AP successfully wrote/read 223 synthetic CVars,
    // but the real Randomizer Options still read 0.  A normal SoH randomizer menu
    // worked because it writes Option::GetCVarName() directly.
    auto settings = Rando::Settings::GetInstance();
    if (!settings) {
        SPDLOG_ERROR("[Archipelago] Randomizer Settings singleton unavailable; cannot apply AP settings");
        return;
    }

    size_t mappedNativeOptions = 0;
    size_t nativeReadbackMismatches = 0;
    std::set<std::string> consumedKeys;

    for (const auto& option : settings->GetAllOptions()) {
        const std::string& nativeCVar = option.GetCVarName();
        if (nativeCVar.empty()) {
            continue;
        }

        // AP keys are the final component of the native CVar, e.g.
        // gRandomizer.ShufflePots -> ShufflePots in the current build.
        const size_t dot = nativeCVar.find_last_of('.');
        const std::string nativeKey = dot == std::string::npos ? nativeCVar : nativeCVar.substr(dot + 1);
        auto it = settingsSnapshot.find(nativeKey);
        if (it == settingsSnapshot.end()) {
            continue;
        }

        const int requested = it->second;
        CVarSetInteger(nativeCVar.c_str(), requested);
        consumedKeys.insert(nativeKey);
        ++mappedNativeOptions;

        const int readBack = CVarGetInteger(nativeCVar.c_str(), requested - 1);
        if (readBack != requested) {
            ++nativeReadbackMismatches;
            SPDLOG_ERROR("[Archipelago] Native option CVar write failed: {} (AP key {}) requested={} readback={}",
                         nativeCVar, nativeKey, requested, readBack);
        }
    }

    // Preserve AP-only/custom CVars that are not represented by Settings::mOptions.
    // These are intentionally secondary; gameplay randomizer settings above always
    // use the exact CVar name from Ship's native Option table.
    for (const auto& [key, value] : settingsSnapshot) {
        if (consumedKeys.contains(key)) {
            continue;
        }
        // AP-only flags have no native Option entry. Their writer must use
        // the same build-defined prefix as CVAR_RANDOMIZER_SETTING readers.
        const std::string fallbackCVar = std::string(CVAR_RANDOMIZER_SETTING("")) + key;
        CVarSetInteger(fallbackCVar.c_str(), value);
    }

    SPDLOG_INFO("[Archipelago] Scene transition checks: {} (catalog {})",
                CVarGetInteger(CVAR_RANDOMIZER_SETTING("SceneTransitionChecks"), 0) != 0,
                CVarGetInteger(CVAR_RANDOMIZER_SETTING("SceneTransitionCatalogVersion"), 0));

    // Callbacks may change visibility/availability, then copy the now-correct native
    // menu indices into the live Context used by RAND_GET_OPTION.
    settings->UpdateAllOptions();
    settings->SetAllToContext();
    if (!SohExtreme::EntranceRuntime::Apply(settingsSnapshot)) {
        slotSettingsError = "The entrance map could not be installed. See the game log for the reported cause.";
        return;
    }
    SPDLOG_INFO("[Archipelago] {}", GetEntranceStatusText());

    // AP is the authority for logic on an Archipelago save. Native trick flags are
    // stored separately from the normal option array, so a local SoH randomizer
    // session can otherwise leak enabled tricks into Check Finder/reachability even
    // when the AP YAML has no tricks enabled. The current AP slot-data format does
    // not publish a native trick list, so fail closed: no local trick is allowed to
    // alter an AP seed's logic. (The resolved AP world already accounts for any
    // tricks selected on the server side.)
    if (auto randoContext = Rando::Context::GetInstance(); randoContext != nullptr) {
        randoContext->ResetTrickOptions();
    }
    CVarSetString(CVAR_RANDOMIZER_SETTING("EnabledTricks"), "");

    if (IS_RANDO && gPlayState != nullptr) {
        // AP settings are authoritative for BOTH physical SoH behavior and the
        // Check Finder. Refresh native randomizer hooks first, then schedule one
        // deferred reachability pass so the tracker cannot keep logic computed
        // from stale/local menu settings.
        RefreshArchipelagoRandomizerHooks();
        if (CVarGetInteger(CVAR_TRACKER_CHECK("EnableAvailableChecks"), 0)) {
            CheckTracker::RecalculateAvailableChecks();
        }
    }

    auto slotValue = [&settingsSnapshot](const char* key, int fallback = 0) {
        auto it = settingsSnapshot.find(key);
        return it == settingsSnapshot.end() ? fallback : it->second;
    };
    // 0.11.21b: ExtraTraps.* are persistent local menu preferences, not AP
    // slot settings. Writing them here erased the player's choices on create,
    // load and reconnect (and SaveConsoleVariablesNextFrame persisted the loss).
    // ExtraTraps.cpp now reads the authoritative RSK_EXTREME_* options directly
    // for an AP save, without changing any local enhancement preference.

    // Mirror the authoritative AP seed into the same persisted native CVars used
    // by the local Randomizer menu. The local menu therefore shows the AP seed's
    // configuration instead of stale pre-connection values, and local/randomizer
    // runtime logic reads the same settings snapshot.
    Ship::Context::GetRawInstance()->GetWindow()->GetGui()->SaveConsoleVariablesNextFrame();

    // Log AP input AND the live RSK result.  If these differ now, the log tells us
    // which exact layer is wrong instead of merely proving a synthetic CVar exists.
    SPDLOG_INFO(
        "[Archipelago] AP native settings: mapped={}/{} readback_mismatches={} | "
        "Pots AP={} RSK={} PotSoul AP={} RSK={} Grass AP={} RSK={} GrassSoul AP={} RSK={} "
        "Rocks AP={} RSK={} RockSoul AP={} RSK={} Crates AP={} RSK={} CrateSoul AP={} RSK={} "
        "Speak AP={} RSK={} NPCSpeech AP={} RSK={} FlowOfTime AP={} RSK={}",
        mappedNativeOptions, settingsSnapshot.size(), nativeReadbackMismatches,
        slotValue("ShufflePots"), RAND_GET_OPTION(RSK_SHUFFLE_POTS).Get(),
        slotValue("PotSoul"), RAND_GET_OPTION(RSK_SHUFFLE_POT_SOUL).Get(),
        slotValue("ShuffleGrass"), RAND_GET_OPTION(RSK_SHUFFLE_GRASS).Get(),
        slotValue("GrassSoul"), RAND_GET_OPTION(RSK_SHUFFLE_GRASS_SOUL).Get(),
        slotValue("ShuffleRocks"), RAND_GET_OPTION(RSK_SHUFFLE_ROCKS).Get(),
        slotValue("RockSoul"), RAND_GET_OPTION(RSK_SHUFFLE_ROCK_SOUL).Get(),
        slotValue("ShuffleCrates"), RAND_GET_OPTION(RSK_SHUFFLE_CRATES).Get(),
        slotValue("CrateSoul"), RAND_GET_OPTION(RSK_SHUFFLE_CRATE_SOUL).Get(),
        slotValue("ShuffleSpeak"), RAND_GET_OPTION(RSK_SHUFFLE_SPEAK).Get(),
        slotValue("NpcSpeechSanity"), RAND_GET_OPTION(RSK_NPC_SPEECH_SANITY).Get(),
        slotValue("FlowOfTime"), RAND_GET_OPTION(RSK_SHUFFLE_FLOW_OF_TIME).Get());
}

void ArchipelagoClient::EnforceSlotSettings() {
    if (!slotSettingsLoaded || !currentSaveIsArchipelago || gSaveContext.ship.quest.id != QUEST_RANDOMIZER) {
        return;
    }

    std::unordered_map<std::string, int> settingsSnapshot;
    {
        std::scoped_lock lock(queueMutex);
        const auto fish = slotSettings.find("Fishsanity");
        if (fish != slotSettings.end()) {
            const bool pond = fish->second == RO_FISHSANITY_POND || fish->second == RO_FISHSANITY_BOTH;
            slotSettings.try_emplace("FishsanityPondCount", pond ? 17 : 0);
            slotSettings.try_emplace("FishsanityAgeSplit", pond ? 1 : 0);
        }
        settingsSnapshot = slotSettings;
    }

    // AP owns randomizer settings for an AP save. The local randomizer menu is not
    // allowed to silently change physical checks/logic after connection. If a user
    // changes one of those CVars locally, restore the server value and refresh the
    // affected hooks before the next gameplay update.
    auto settings = Rando::Settings::GetInstance();
    if (!settings) return;
    for (const auto& option : settings->GetAllOptions()) {
        const std::string& nativeCVar = option.GetCVarName();
        if (nativeCVar.empty()) continue;
        const size_t dot = nativeCVar.find_last_of('.');
        const std::string key = dot == std::string::npos ? nativeCVar : nativeCVar.substr(dot + 1);
        auto it = settingsSnapshot.find(key);
        if (it == settingsSnapshot.end()) continue;
        const int actual = CVarGetInteger(nativeCVar.c_str(), it->second);
        if (actual != it->second) {
            SPDLOG_WARN("[Archipelago] Native randomizer setting {}={} disagrees with AP {}; restoring server snapshot",
                        nativeCVar, actual, it->second);
            ApplySlotSettings();
            return;
        }
    }
}

bool ArchipelagoClient::IsReadyForFileSelect() const {
    // Do not make file creation wait for every LocationScout reply.  Large
    // all-sanity slots can contain thousands of locations and the old barrier
    // made "New Archipelago File" appear frozen.  Settings + active-location
    // ownership + exact shop prices are the data that must exist before native
    // randomizer initialization.  Scout/model data can finish in the background;
    // actors refresh their concrete placement lazily before drawing/interaction.
    return IsAuthenticated() && slotSettingsLoaded && slotSettingsError.empty() &&
           activeLocationsLoaded && shopPricesLoaded;
}

void ArchipelagoClient::ApplyPostInitSlotState() {
    // Kakariko Gate was removed as a normal setting in this SoH fork. AP still has
    // that setting, so apply its resolved open state after save initialization.
    if (kakarikoGateOpen) {
        Flags_SetInfTable(INFTABLE_SHOWED_ZELDAS_LETTER_TO_GATE_GUARD);
    }
}

void ArchipelagoClient::SetActiveLocationsFromJson(const std::string& raw) {
    const auto json = nlohmann::json::parse(raw, nullptr, false);
    if (!json.is_array()) {
        SPDLOG_ERROR("[Archipelago] Invalid active location manifest");
        return;
    }
    std::unordered_set<int64_t> parsed;
    for (const auto& id : json) {
        if (!id.is_number_integer() || (id.is_number_unsigned() && id.get<uint64_t>() > INT64_MAX) ||
            id.get<int64_t>() <= 0) {
            SPDLOG_ERROR("[Archipelago] Invalid active location ID");
            return;
        }
        parsed.insert(id.get<int64_t>());
    }
    activeLocations = std::move(parsed);
    activeLocationsLoaded = true;
    scoutsRequested = false;
    scoutedLocations.clear();
    scoutedLocationNameIndex.clear();
    checkFinderMappingsPrepared = false;
    SPDLOG_INFO("[Archipelago] Loaded {} active server locations from slot data", activeLocations.size());

    // Network callback: defer tracker mutation/reachability to Update().
    activeLocationsPendingRefresh.store(true);
}

void ArchipelagoClient::RequestLocationScouts() {
    if (!IsAuthenticated()) return;
    const double now = FinderMirrorClock();
    if (scoutsRequested && now < nextScoutRequest) return;

    // Never scout the full static map. Archipelago validates LocationScouts against the
    // current slot, and many SoH checks do not exist for every option combination.
    if (!activeLocationsLoaded) {
        SPDLOG_DEBUG("[Archipelago] Waiting for extreme_active_locations slot data before scouting");
        return;
    }

    // extreme_active_locations already came from the server-generated APWorld, so every
    // ID in it is valid for this slot. Scout the COMPLETE active set, not only locations
    // that happen to exist in the baked rcToApLocation table. The latter was missing a
    // large number of stock SoH freestanding checks (for example KF Behind Mido's House
    // Rupee), which made them impossible to report or receive placements for.
    expectedScoutCount = activeLocations.size();
    std::set<int64_t> locations;
    for (int64_t id : activeLocations) {
        if (!scoutedLocations.contains(id)) locations.insert(id);
    }
    nextScoutRequest = now + 3.0;

    if (locations.empty()) {
        scoutsRequested = true;
        return;
    }

    scoutsRequested = true;
    SPDLOG_INFO("[Archipelago] Scouting {} missing ACTIVE SOH-EXTREME locations in chunks", locations.size());

    // Large all-sanity slots can exceed 2,000 locations.  Split scout requests
    // into modest packets instead of asking APCpp/server to process one giant
    // set in a single callback burst.
    constexpr size_t kScoutChunkSize = 256;
    std::set<int64_t> chunk;
    for (int64_t locationId : locations) {
        chunk.insert(locationId);
        if (chunk.size() >= kScoutChunkSize) {
            AP_SendLocationScouts(chunk, false);
            chunk.clear();
        }
    }
    if (!chunk.empty()) {
        AP_SendLocationScouts(chunk, false);
    }
}

void ArchipelagoClient::IndexScoutedLocation(int64_t locationId, const ScoutedLocation& info) {
    checkFinderMappingsPrepared = false;
    const std::string normalized = NormalizeApLocationName(info.locationName);
    if (normalized.empty()) {
        return;
    }

    auto [it, inserted] = scoutedLocationNameIndex.emplace(normalized, locationId);
    if (!inserted && it->second != locationId) {
        // Never guess when two AP locations normalize to the same name.
        it->second = -1;
    }
}

bool ArchipelagoClient::IsLocationActive(int64_t locationId) const {
    return activeLocationsLoaded && activeLocations.find(locationId) != activeLocations.end();
}

bool ArchipelagoClient::IsLocationSubmitted(int64_t locationId) const {
    return reportedLocations.contains(locationId) || pendingLocationReports.contains(locationId);
}

void ArchipelagoClient::LoadPendingLocations(const std::vector<int64_t>& locations) {
    pendingLocationReports.clear();
    if (!currentSaveIsArchipelago) return;
    for (int64_t id : locations) {
        if (id > 0 && !reportedLocations.contains(id)) pendingLocationReports.insert(id);
    }
}

ArchipelagoSaveSnapshot ArchipelagoClient::CaptureSaveSnapshot() const {
    ArchipelagoSaveSnapshot snapshot;
    snapshot.active = currentSaveIsArchipelago;
    if (snapshot.active) {
        snapshot.receivedItemCount = appliedItemCount;
        snapshot.server = saveServer;
        snapshot.slot = saveSlot;
        snapshot.identity = saveConnectionIdentity;
        snapshot.settingsJson = cachedSlotSettingsJson;
        snapshot.fallbackNpcSpeechHashes = fallbackNpcSpeechHashes;
        snapshot.pendingLocations.assign(pendingLocationReports.begin(), pendingLocationReports.end());
        snapshot.revealedHintTargetsJson = GetRevealedHintTargetsJson();
        // A native check can be saved on the same frame it is collected, before
        // the deferred report reaches SendLocation(). Include that queue too.
        for (int64_t id : gDeferredLocationReports) {
            if (!reportedLocations.contains(id) && !pendingLocationReports.contains(id))
                snapshot.pendingLocations.push_back(id);
        }
    }
    return snapshot;
}

bool ArchipelagoClient::IsLocationReported(int64_t locationId) const {
    return reportedLocations.find(locationId) != reportedLocations.end();
}

size_t ArchipelagoClient::GetActiveLocationCount() const {
    return activeLocationsLoaded ? activeLocations.size() : 0;
}

size_t ArchipelagoClient::GetReportedActiveLocationCount() const {
    if (!activeLocationsLoaded) {
        return 0;
    }
    size_t count = 0;
    for (const int64_t locationId : activeLocations) {
        if (reportedLocations.find(locationId) != reportedLocations.end()) {
            ++count;
        }
    }
    return count;
}

bool ArchipelagoClient::PrepareCheckFinderMappings() {
    if (!currentSaveIsArchipelago || saveIdentityMismatch || !activeLocationsLoaded) {
        return false;
    }

    // Missing native mappings need scout names. Do not run a partial Check Finder
    // that silently omits unvisited scenes; wait until the initial active scout set
    // is resident. Normal gameplay remains scene-local and does not wait on this.
    if (expectedScoutCount > 0 && scoutedLocations.size() < expectedScoutCount) {
        RequestLocationScouts();
        SPDLOG_DEBUG("[Archipelago] Check Finder mapping waiting for scouts ({}/{})",
                     scoutedLocations.size(), expectedScoutCount);
        return false;
    }

    if (checkFinderMappingsPrepared) {
        return true;
    }

    const auto started = std::chrono::steady_clock::now();
    size_t exactMapped = 0;
    size_t suffixMapped = 0;
    size_t ambiguous = 0;
    size_t unresolved = 0;

    // v6 deliberately stopped resolving the entire world on load. Check Finder is
    // the one feature that needs a complete active RC set, so build it on demand.
    //
    // Important performance difference from the old startup path:
    // - AP scout names were normalized ONCE by IndexScoutedLocation().
    // - exact matches are O(1).
    // - suffix fallback compares already-normalized strings and never allocates/
    //   normalizes every scout inside the inner loop.
    // This keeps the scene-local placement architecture while allowing a full-world
    // reachability query when the user explicitly enables Available Checks.
    for (const auto& entry : Rando::StaticData::GetLocationTable()) {
        const int32_t rc = static_cast<int32_t>(entry.GetRandomizerCheck());
        if (rc <= static_cast<int32_t>(RC_UNKNOWN_CHECK)) {
            continue;
        }

        auto existing = rcToApLocation.find(rc);
        if (existing != rcToApLocation.end()) {
            continue;
        }

        const std::string fullName = NormalizeApLocationName(entry.GetName());
        const std::string shortName = NormalizeApLocationName(entry.GetShortName());

        int64_t matched = -1;

        auto tryAuthoritativeExact = [&](const std::string& normalized) {
            if (normalized.empty() || matched >= 0) {
                return;
            }
            auto it = authoritativeLocationNameIndex.find(normalized);
            if (it != authoritativeLocationNameIndex.end() && it->second >= 0 &&
                activeLocations.find(it->second) != activeLocations.end()) {
                matched = it->second;
            }
        };

        // Prefer the exact seed namespace from slot data.  This is the primary path
        // for standalone SOH-EXTREME and survives APWorld location renames.
        tryAuthoritativeExact(fullName);
        tryAuthoritativeExact(shortName);

        auto tryExact = [&](const std::string& normalized) {
            if (normalized.empty() || matched >= 0) {
                return;
            }
            auto it = scoutedLocationNameIndex.find(normalized);
            if (it != scoutedLocationNameIndex.end() && it->second >= 0 &&
                activeLocations.find(it->second) != activeLocations.end()) {
                matched = it->second;
            }
        };

        tryExact(fullName);
        tryExact(shortName);

        if (matched >= 0) {
            ++exactMapped;
        } else if (!shortName.empty()) {
            int64_t authoritativeSuffix = -1;
            bool authoritativeAmbiguous = false;
            for (const auto& [apName, apLocation] : authoritativeLocationNameIndex) {
                if (apLocation < 0 || activeLocations.find(apLocation) == activeLocations.end() ||
                    shortName.size() > apName.size()) {
                    continue;
                }
                if (apName.compare(apName.size() - shortName.size(), shortName.size(), shortName) != 0) {
                    continue;
                }
                if (authoritativeSuffix >= 0 && authoritativeSuffix != apLocation) {
                    authoritativeAmbiguous = true;
                    break;
                }
                authoritativeSuffix = apLocation;
            }
            if (!authoritativeAmbiguous && authoritativeSuffix >= 0) {
                matched = authoritativeSuffix;
                ++suffixMapped;
            }

            int64_t suffixMatch = -1;
            bool suffixAmbiguous = false;

            if (matched < 0) for (const auto& [apName, apLocation] : scoutedLocationNameIndex) {
                if (apLocation < 0 || activeLocations.find(apLocation) == activeLocations.end() ||
                    shortName.size() > apName.size()) {
                    continue;
                }

                if (apName.compare(apName.size() - shortName.size(), shortName.size(), shortName) != 0) {
                    continue;
                }

                if (suffixMatch >= 0 && suffixMatch != apLocation) {
                    suffixAmbiguous = true;
                    break;
                }
                suffixMatch = apLocation;
            }

            if (matched < 0 && !suffixAmbiguous && suffixMatch >= 0) {
                matched = suffixMatch;
                ++suffixMapped;
            } else if (matched < 0 && suffixAmbiguous) {
                ++ambiguous;
            }
        }

        if (matched < 0) {
            ++unresolved;
            continue;
        }

        rcToApLocation[rc] = matched;
        apLocationToRc[matched] = rc;
    }

    checkFinderMappingsPrepared = true;

    size_t activeMapped = 0;
    for (const auto& [rc, apLocation] : rcToApLocation) {
        if (activeLocations.find(apLocation) != activeLocations.end()) {
            ++activeMapped;
        }
    }

    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - started).count();

    SPDLOG_INFO(
        "[Archipelago] Check Finder mapping ready in {}ms: activeMapped={} / activeLocations={}, "
        "newExact={}, newSuffix={}, ambiguous={}, unresolvedNative={}",
        elapsedMs, activeMapped, activeLocations.size(), exactMapped, suffixMapped, ambiguous, unresolved);

    return true;
}

int64_t ArchipelagoClient::ResolveApLocationForCheck(int32_t randomizerCheck) {
    auto direct = rcToApLocation.find(randomizerCheck);
    if (direct != rcToApLocation.end()) {
        return direct->second;
    }

    // Missing static mappings are resolved lazily for the one concrete RC that
    // the game is currently touching.  Do NOT scan every RandomizerCheck at
    // runtime: some table entries are intentionally sparse/conditional, and a
    // full RC_MAX walk added unnecessary crash risk during scout processing.
    auto* location = Rando::StaticData::GetLocation(static_cast<RandomizerCheck>(randomizerCheck));
    if (location == nullptr) {
        return -1;
    }

    const std::string fullName = NormalizeApLocationName(location->GetName());
    const std::string shortName = NormalizeApLocationName(location->GetShortName());
    if (fullName.empty() && shortName.empty()) {
        return -1;
    }

    // Primary path for standalone SOH-EXTREME: use the exact name -> id table
    // published by this seed.  Do not depend on the compiled stock-SoH id map.
    int64_t matched = -1;
    auto tryAuthoritative = [&](const std::string& normalized) {
        if (normalized.empty() || matched >= 0) return;
        auto it = authoritativeLocationNameIndex.find(normalized);
        if (it != authoritativeLocationNameIndex.end() && it->second >= 0 &&
            activeLocations.find(it->second) != activeLocations.end()) {
            matched = it->second;
        }
    };
    tryAuthoritative(fullName);
    tryAuthoritative(shortName);

    // Compatibility fallback for old slots that do not publish the map yet.
    // The scout callback builds a normalized name index once.
    if (matched < 0 && !fullName.empty()) {
        auto indexed = scoutedLocationNameIndex.find(fullName);
        if (indexed != scoutedLocationNameIndex.end() && indexed->second >= 0) {
            matched = indexed->second;
        }
    }

    // Some native short names intentionally omit the AP prefix. First try a
    // unique suffix against the server-authoritative map, then fall back to scouts.
    if (matched < 0 && !shortName.empty()) {
        int64_t suffixMatch = -1;
        for (const auto& [apName, apLocation] : authoritativeLocationNameIndex) {
            if (apLocation < 0 || activeLocations.find(apLocation) == activeLocations.end() ||
                shortName.size() > apName.size() ||
                apName.compare(apName.size() - shortName.size(), shortName.size(), shortName) != 0) {
                continue;
            }
            if (suffixMatch >= 0 && suffixMatch != apLocation) {
                suffixMatch = -1;
                break;
            }
            suffixMatch = apLocation;
        }
        if (suffixMatch >= 0) matched = suffixMatch;
    }

    // Legacy/scout fallback for old slots.
    if (matched < 0 && !shortName.empty()) {
        for (const auto& [apLocation, info] : scoutedLocations) {
            const std::string apName = NormalizeApLocationName(info.locationName);
            if (shortName.size() > apName.size() ||
                apName.compare(apName.size() - shortName.size(), shortName.size(), shortName) != 0) {
                continue;
            }
            if (matched != -1 && matched != apLocation) {
                SPDLOG_WARN("[Archipelago] Ambiguous lazy RC mapping for {} ({})", randomizerCheck, location->GetName());
                return -1;
            }
            matched = apLocation;
        }
    }

    if (matched < 0) {
        return -1;
    }

    rcToApLocation[randomizerCheck] = matched;
    apLocationToRc[matched] = randomizerCheck;
    SPDLOG_DEBUG("[Archipelago] Lazily resolved missing RC mapping: {} -> {} ({})",
                randomizerCheck, matched, location->GetName());
    return matched;
}

// Merchant hint text and remote item presentations use the same literal-name
// encoding as gossip hints. The native page stream handles the complete text.
static std::string ApMessageName(const std::string& name) {
    return SohExtreme::HintLiteral(name);
}

void ArchipelagoClient::DrainMessages() {
    for (int i = 0; i < 32 && AP_IsMessagePending(); ++i) {
        AP_Message* message = AP_GetLatestMessage();
        if (message != nullptr && message->type == AP_MessageType::SeedHints) {
            if (!inGameHints.Load(static_cast<AP_SeedHintListMessage*>(message)->data))
                SPDLOG_WARN("[Archipelago] Invalid in-game hint snapshot");
        } else if (message != nullptr && message->type == AP_MessageType::HintList) {
            // The installed APCpp snapshot has no verified item flags/IDs.
            // The managed official AP client supplies typed progression hints
            // through hint_snapshot; never classify these strings by spelling.
            nextHintRequest = 0.0;
        } else if (message != nullptr) {
            const std::string line = message->text;
            {
                std::scoped_lock lock(queueMutex);
                chatMessages.push_back(line);
                while (chatMessages.size() > 200) chatMessages.pop_front();
            }
            if (IsGameplaySessionActive() &&
                (message->type == AP_MessageType::Chat || message->type == AP_MessageType::ServerChat)) {
                Notification::Emit({ .prefix = "Archipelago", .message = line, .remainingTime = 6.0f });
            }
            SPDLOG_INFO("[Archipelago Chat] {}", line);
        }
        AP_ClearLatestMessage();
    }
}

void ArchipelagoClient::ResetRemotePresentations() {
    songNotePickupDescription.clear();
    remotePresentations.clear();
    presentedRemoteLocations.clear();
    remotePickupDescription.clear();
    remotePresentationActive = false;
    remotePresentationReceived = false;
    remotePresentationFrames = 0;
}

void ArchipelagoClient::QueueRemotePresentation(int64_t locationId) {
    // A fresh physical check is presented once. Reconnect reconciliation never
    // calls this method, and repeated actor hooks cannot replay the presentation.
    if (presentedRemoteLocations.insert(locationId).second) remotePresentations.push_back(locationId);
}

bool ArchipelagoClient::ProcessRemotePresentation() {
    if (remotePresentationActive) {
        if (gPlayState == nullptr) return true;
        Player* player = GET_PLAYER(gPlayState);
        if (player == nullptr) return true;
        ++remotePresentationFrames;
        const bool busy = !SohExtreme::CanReceiveGameplayReward(gPlayState);
        if (busy) return true;
        if (!remotePresentationReceived && remotePresentationFrames < 90) return true;
        if (remotePresentationReceived && !remotePresentations.empty()) remotePresentations.pop_front();
        // Interrupted cosmetics retry; they never alter the AP receipt cursor.
        remotePresentationActive = false;
        remotePickupDescription.clear();
        return true;
    }
    if (awaitingMajorItemReceipt || remotePresentations.empty()) return false;
    {
        std::scoped_lock lock(queueMutex);
        // Deliver incoming rewards before starting another cosmetic send
        // animation. A burst of remote checks must not delay our progression.
        if (!pendingItems.empty()) return false;
    }
    if (!SohExtreme::CanReceiveGameplayReward(gPlayState)) return false;
    const auto scout = scoutedLocations.find(remotePresentations.front());
    if (scout == scoutedLocations.end()) return false; // Metadata can arrive later; receiving still runs.
    const auto& item = scout->second;
    if (item.playerId == AP_GetPlayerID()) {
        remotePresentations.pop_front();
        return false; // Our own reward comes through the normal receipt transaction.
    }
    const std::string itemName = item.itemName.empty() ? "Archipelago Item" : item.itemName;
    const std::string recipient = item.playerName.empty() ? "Player " + std::to_string(item.playerId) : item.playerName;
    if ((item.flags & 3) == 0) { // AP advancement/useful flags; filler stays quick.
        Notification::Emit({ .prefix = "Archipelago", .message = "found " + itemName + " for",
                             .suffix = recipient, .remainingTime = 5.0f });
        remotePresentations.pop_front();
        return false;
    }
    if (!SohExtreme::IsPlayerOnDryGround(GET_PLAYER(gPlayState))) return false;
    remotePickupDescription = ApMessageName(itemName) + " for " + ApMessageName(recipient);
    remotePresentationReceived = false;
    remotePresentationFrames = 0;
    remotePresentationActive = true;
    auto entry = Rando::StaticData::RetrieveItem(RG_AP_REMOTE_IMPORTANT).GetGIEntry_Copy();
    gRemotePresentationEntry = entry;
    if (!GiveItemEntryWithoutActor(gPlayState, entry)) {
        remotePresentationActive = false;
        remotePickupDescription.clear();
        return false;
    }
    Notification::Emit({ .prefix = "Archipelago", .message = "found " + itemName + " for",
                         .suffix = recipient, .remainingTime = 5.0f });
    return true;
}

void ArchipelagoClient::ReofferPendingPresentation() {
    // GiveItemEntryWithoutActor offers an item; it does not start an animation.
    // Attacking/rolling can discard that one-frame offer. Like the native item
    // queue, keep offering after Player_Update until Link accepts it, rather
    // than blocking every later AP item behind a 90-frame timeout.
    const bool remotePending = remotePresentationActive && !remotePresentationReceived;
    if ((!awaitingMajorItemReceipt && !remotePending) || !IsGameplaySessionActive() ||
        !SohExtreme::CanReceiveGameplayReward(gPlayState)) return;
    Player* player = GET_PLAYER(gPlayState);
    if (!SohExtreme::IsPlayerOnDryGround(player)) return;
    const auto& entry = awaitingMajorItemReceipt ? gAwaitingMajorEntry : gRemotePresentationEntry;
    if (player->getItemId != GI_NONE &&
        ((player->interactRangeActor != nullptr && player->interactRangeActor != &player->actor) ||
         player->getItemId != entry.getItemId ||
         player->getItemEntry.modIndex != entry.modIndex ||
         player->getItemEntry.itemId != entry.itemId ||
         player->getItemEntry.getItemId != entry.getItemId)) return;
    // Player_Update clears interactRangeActor after an unaccepted offer while
    // retaining getItemId/getItemEntry. A null source with our exact entry is
    // still ours to re-offer; treating it as another actor stalls the whole AP
    // receive queue until the timeout. Live foreign offers remain protected.
    // Re-offering cannot grant, commit, pop the receive queue or reset its timer.
    GiveItemEntryWithoutActor(gPlayState, entry);
}

std::string ArchipelagoClient::GetHintItemDescription(int32_t randomizerCheck) {
    if (!IsGameplaySessionActive()) return {};
    const int64_t location = ResolveApLocationForCheck(randomizerCheck);
    if (location < 0 && activeLocationsLoaded) {
        // An unshuffled reward has no AP scout; its vanilla item is authoritative.
        auto* loc = Rando::StaticData::GetLocation(static_cast<RandomizerCheck>(randomizerCheck));
        if (loc) return SohExtreme::HintLiteral(Rando::StaticData::RetrieveItem(loc->GetVanillaItem()).GetName().english);
    }
    const auto it = scoutedLocations.find(location);
    if (it == scoutedLocations.end()) return {};
    const auto& item = it->second;
    if (item.itemName.empty()) return {};
    return SohExtreme::HintLiteral(item.itemName) + " for " +
           (item.playerName.empty() ? "Player " + std::to_string(item.playerId)
                                    : SohExtreme::HintLiteral(item.playerName));
}

std::string ArchipelagoClient::GetInGameHint(const std::string& key, int32_t stoneIndex) {
    if (!IsGameplaySessionActive()) return {};
    const auto supplied = inGameHints.Get(key);
    if (!supplied.empty()) return supplied;
    const bool missingTarget = stoneIndex < 0;
    if (missingTarget && !inGameHints.IsLoaded()) return {};
    if (missingTarget) stoneIndex = 0;
    // Older seeds did not generate gossip hints. Their authoritative scouts
    // still reveal the real item/recipient, including another game's items.
    // Keep assignments stable: do not filter on checked state or arrival order.
    if (!scoutsRequested || scoutedLocations.size() < expectedScoutCount) return {};
    std::vector<int64_t> candidates;
    for (const auto& [id, info] : scoutedLocations)
        if (!info.itemName.empty() && !info.locationName.empty() && (info.flags & 1)) candidates.push_back(id);
    if (candidates.empty()) for (const auto& [id, info] : scoutedLocations)
        if (!info.itemName.empty() && !info.locationName.empty()) candidates.push_back(id);
    if (candidates.empty()) return {};
    std::sort(candidates.begin(), candidates.end());
    const auto& item = scoutedLocations.at(candidates[static_cast<size_t>(stoneIndex) % candidates.size()]);
    return std::string(missingTarget ? "This seed did not store this hint's target. Another lead:^" : "") +
           SohExtreme::HintLiteral(item.itemName) + " for " +
           SohExtreme::HintLiteral(item.playerName) + " can be found at " +
           SohExtreme::HintLiteral(item.locationName) + " in your world.";
}

std::string ArchipelagoClient::GetRemoteItemDescription(int32_t randomizerCheck) {
    if (!IsAuthenticated() || scoutedLocations.empty()) return {};
    const int64_t apLocation = ResolveApLocationForCheck(randomizerCheck);
    if (apLocation < 0) return {};
    auto scoutIt = scoutedLocations.find(apLocation);
    if (scoutIt == scoutedLocations.end()) return {};
    const auto& info = scoutIt->second;
    if (info.playerId == AP_GetPlayerID()) return {};

    std::string result = info.itemName.empty() ? "Archipelago Item" : ApMessageName(info.itemName);
    result += " for ";
    if (!info.playerName.empty()) {
        result += ApMessageName(info.playerName);
    } else if (info.playerId > 0) {
        result += "Player " + std::to_string(info.playerId);
    } else {
        result += "another player";
    }
    result += "'s world";
    return result;
}

void ArchipelagoClient::EnsureLocationScouts() {
    DrainSlotData();
    RequestLocationScouts();
}

#include "ArchipelagoHintClient.inc"

int32_t ArchipelagoClient::GetLocationDisplayItem(int64_t locationId) const {
    // AP-only enemy checks have no native RC/ItemLocation. Read the game-thread
    // scout snapshot directly, without inventing a native check or local grant.
    if (!IsGameplaySessionActive()) return RG_AP_REMOTE_IMPORTANT;
    const auto scout = scoutedLocations.find(locationId);
    if (scout == scoutedLocations.end()) return RG_AP_REMOTE_IMPORTANT;
    const auto& info = scout->second;
    // Names and numeric IDs overlap between games. Only the recipient's game
    // (or our own slot) can authorize interpreting them as SOH-EXTREME items.
    if (info.playerId != AP_GetPlayerID() && info.itemGame != "SOH-EXTREME") {
        return GetRemoteArchipelagoDisplay(info.flags);
    }
    RandomizerGet display = MapApItemNameToRandomizerGet(info.itemName);
    if (display == RG_NONE) display = static_cast<RandomizerGet>(MapApItemToRandomizerGet(info.itemId));
    if (display == RG_ICE_TRAP || info.itemName == "Ice Trap") display = GetIceTrapDisguise(locationId);
    return display != RG_NONE ? display : GetRemoteArchipelagoDisplay(info.flags);
}

void ArchipelagoClient::RefreshPlacementForCheck(int32_t randomizerCheck) {
    // Actor draw/drop code can ask for a GetItemEntry long after the initial AP
    // placement reconciliation.  Always make the scouted AP placement authoritative
    // immediately before SoH chooses a model.  This fixes stale native models for
    // freestanding items, shops, and item drops spawned from grass/rocks/etc.
    if (!IsGameplaySessionActive()) return;

    auto ctx = Rando::Context::GetInstance();
    if (!ctx) return;

    const int64_t apLocation = ResolveApLocationForCheck(randomizerCheck);
    if (apLocation < 0) return;

    auto* loc = ctx->GetItemLocation(static_cast<RandomizerCheck>(randomizerCheck));
    if (loc == nullptr) return;

    // Prices arrive in slot data independently of item scouts. They belong to
    // the location and must survive SetPlacedItem's default item-price update.
    auto priceIt = shopPrices.find(apLocation);
    if (priceIt != shopPrices.end()) {
        loc->SetCustomPrice(priceIt->second);
    }
    if (loc->HasObtained()) return;

    auto scoutIt = scoutedLocations.find(apLocation);
    if (scoutIt == scoutedLocations.end()) return;

    const auto& info = scoutIt->second;
    RandomizerGet display = RG_NONE;
    if (info.playerId == AP_GetPlayerID()) {
        display = MapApItemNameToRandomizerGet(info.itemName);
        if (display == RG_NONE) {
            display = static_cast<RandomizerGet>(MapApItemToRandomizerGet(info.itemId));
        }
        if (display == RG_ICE_TRAP || info.itemName == "Ice Trap") {
            display = GetIceTrapDisguise(apLocation);
        }
    } else {
        display = GetRemoteArchipelagoDisplay(info.flags);
    }

    if (display == RG_NONE) {
        display = GetRemoteArchipelagoDisplay(info.flags);
    }

    if (loc->GetPlacedRandomizerGet() != display) {
        SPDLOG_INFO("[Archipelago] Live model refresh RC {} / {} <- {} (AP item {}, RandomizerGet {}, recipient {})",
                    randomizerCheck, info.locationName, info.itemName, info.itemId, static_cast<int>(display),
                    info.playerName);
        loc->SetPlacedItem(display);
    }
}

void ArchipelagoClient::RefreshPlacementsForScene(int16_t sceneNum) {
    if (!IsGameplaySessionActive()) return;

    // Build the native scene -> RC list once. This cache is static game data and
    // does not depend on the AP slot.
    static const std::unordered_map<int16_t, std::vector<int32_t>> checksByScene = []() {
        std::unordered_map<int16_t, std::vector<int32_t>> result;
        for (const auto& entry : Rando::StaticData::GetLocationTable()) {
            const RandomizerCheck rc = entry.GetRandomizerCheck();
            if (rc == RC_UNKNOWN_CHECK || rc == RC_MAX || rc == RC_LINKS_POCKET) continue;
            result[static_cast<int16_t>(entry.GetScene())].push_back(static_cast<int32_t>(rc));
        }
        return result;
    }();

    auto sceneIt = checksByScene.find(sceneNum);
    if (sceneIt == checksByScene.end()) return;

    size_t refreshed = 0;
    for (int32_t rc : sceneIt->second) {
        const size_t before = rcToApLocation.size();
        RefreshPlacementForCheck(rc);
        if (rcToApLocation.size() != before || OwnsCheckCached(rc)) {
            ++refreshed;
        }
    }

    SPDLOG_DEBUG("[Archipelago] Scene-local placement refresh scene={} checks={} mapped/active={}",
                 sceneNum, sceneIt->second.size(), refreshed);
}

void ArchipelagoClient::ApplyScoutedPlacements() {
    if (!IsGameplaySessionActive()) return;
    auto ctx = Rando::Context::GetInstance();
    if (!ctx || scoutedLocations.empty()) return;

    const int selfPlayer = AP_GetPlayerID();
    for (const auto& [apLocation, info] : scoutedLocations) {
        auto rcIt = apLocationToRc.find(apLocation);
        if (rcIt == apLocationToRc.end()) {
            // Do not perform the old AP-location x all-native-locations name
            // search here. On a large all-sanity slot that became an O(N*M)
            // reload stall. Missing static mappings are resolved lazily by
            // RefreshPlacementForCheck()/ResolveApLocationForCheck() only when
            // that concrete actor/check is actually touched.
            continue;
        }

        auto* loc = ctx->GetItemLocation(static_cast<RandomizerCheck>(rcIt->second));
        if (loc == nullptr) continue;

        auto priceIt = shopPrices.find(apLocation);
        if (priceIt != shopPrices.end()) {
            loc->SetCustomPrice(priceIt->second);
        }
        if (loc->HasObtained()) continue;

        RandomizerGet display = RG_NONE;
        if (info.playerId == selfPlayer) {
            // Match the working Shipwright reference: prefer the AP item name when
            // converting a scouted placement into SoH's native RandomizerGet table.
            // SOH-EXTREME numeric IDs remain a fallback for custom/newer items.
            display = MapApItemNameToRandomizerGet(info.itemName);
            if (display == RG_NONE) {
                display = static_cast<RandomizerGet>(MapApItemToRandomizerGet(info.itemId));
            }
            if (display == RG_ICE_TRAP || info.itemName == "Ice Trap") {
                display = GetIceTrapDisguise(apLocation);
            }
        } else {
            // A location containing another player's item cannot use that game's native model.
            // Show the Archipelago logo instead. Progression/useful AP items are colored;
            // filler/junk/trap-only items use the grayscale Archipelago logo.
            display = GetRemoteArchipelagoDisplay(info.flags);
        }

        if (display == RG_NONE) {
            // Unknown same-slot/custom items should also avoid the unrelated Triforce model.
            display = GetRemoteArchipelagoDisplay(info.flags);
        }

        if (loc->GetPlacedRandomizerGet() != display) {
            SPDLOG_INFO("[Archipelago] Placement RC {} / {} <- {} (AP item {}, RandomizerGet {}, recipient {})",
                        rcIt->second, info.locationName, info.itemName, info.itemId, static_cast<int>(display),
                        info.playerName);
            loc->SetPlacedItem(display);
        }
    }
}

bool ArchipelagoClient::ProcessItem(int64_t itemId, bool /*notify*/, uint64_t sequence) {
    if (awaitingMajorItemReceipt) return false;
    if (gPlayState == nullptr) {
        SPDLOG_DEBUG("[Archipelago] Deferring item {} until a save is loaded", itemId);
        return false;
    }

    // Leave both the reward and receipt cursor queued until transitions,
    // cutscenes and other blocking animations have completely finished.
    // This also covers filler, traps and historical new-save reconstruction.
    if (!SohExtreme::CanReceiveGameplayReward(gPlayState)) return false;
    Player* player = GET_PLAYER(gPlayState);

    const bool historicalNewSaveReplay =
        gNewSaveReplayTargetCount != 0 && sequence < gNewSaveReplayTargetCount;

    RandomizerGet randoGet = RG_NONE;
    if (itemId >= AP_BASE_ITEM_MIN && itemId <= AP_BASE_ITEM_MAX) {
        switch (itemId) {
#include "ArchipelagoItemMap.inc"
            default:
                SPDLOG_WARN("[Archipelago] Base item id {} has no SoH mapping yet", itemId);
                return true;
        }
    } else {
        switch (itemId) {
            case AP_ITEM_ROLL: randoGet = RG_ROLL; break;
            case AP_ITEM_GRAB: randoGet = RG_POWER_BRACELET; break;
            case AP_ITEM_CLIMB: randoGet = RG_CLIMB; break;
            case AP_ITEM_CRAWL: randoGet = RG_CRAWL; break;
            case AP_ITEM_SPEAK:
                // Important AP progression item.  Do NOT set the ability here: starting
                // the get-item animation is not a committed receive.  The consolidated
                // Speak flags are applied by FinalizeMajorItemReceipt only after SoH's
                // OnItemReceive confirms the item survived the animation/death boundary.
                randoGet = RG_SPEAK_HYLIAN;
                break;
            case AP_ITEM_OPEN_CHEST: randoGet = RG_OPEN_CHEST; break;
            case AP_ITEM_ENEMY_SOUL: randoGet = RG_ENEMY_SOUL; break;
            case AP_ITEM_NPC_SOUL: randoGet = RG_NPC_SOUL; break;
            case AP_ITEM_ANIMAL_SOUL: randoGet = RG_ANIMAL_SOUL; break;
            case AP_ITEM_POT_SOUL: randoGet = RG_POT_SOUL; break;
            case AP_ITEM_CRATE_SOUL: randoGet = RG_CRATE_SOUL; break;
            case AP_ITEM_GRASS_SOUL: randoGet = RG_GRASS_SOUL; break;
            case AP_ITEM_ROCK_SOUL: randoGet = RG_ROCK_SOUL; break;
            case AP_ITEM_TREE_SOUL: randoGet = RG_TREE_SOUL; break;
            case AP_ITEM_BEEHIVE_SOUL: randoGet = RG_BEEHIVE_SOUL; break;
            case AP_ITEM_SIGN_SOUL: randoGet = RG_SIGN_SOUL; break;
            case AP_ITEM_SKULLTULA_SOUL: randoGet = RG_SKULLTULA_SOUL; break;
            case AP_ITEM_BUSINESS_SCRUB_SOUL: randoGet = RG_BUSINESS_SCRUB_SOUL; break;
            case AP_ITEM_SHOVEL: randoGet = RG_SHOVEL; break;
            case AP_ITEM_DMC_BEAN_SOUL: randoGet = RG_DEATH_MOUNTAIN_CRATER_BEAN_SOUL; break;
            case AP_ITEM_DMT_BEAN_SOUL: randoGet = RG_DEATH_MOUNTAIN_TRAIL_BEAN_SOUL; break;
            case AP_ITEM_COLOSSUS_BEAN_SOUL: randoGet = RG_DESERT_COLOSSUS_BEAN_SOUL; break;
            case AP_ITEM_GV_BEAN_SOUL: randoGet = RG_GERUDO_VALLEY_BEAN_SOUL; break;
            case AP_ITEM_GRAVEYARD_BEAN_SOUL: randoGet = RG_GRAVEYARD_BEAN_SOUL; break;
            case AP_ITEM_KF_BEAN_SOUL: randoGet = RG_KOKIRI_FOREST_BEAN_SOUL; break;
            case AP_ITEM_LH_BEAN_SOUL: randoGet = RG_LAKE_HYLIA_BEAN_SOUL; break;
            case AP_ITEM_LW_BRIDGE_BEAN_SOUL: randoGet = RG_LOST_WOODS_BRIDGE_BEAN_SOUL; break;
            case AP_ITEM_LW_BEAN_SOUL: randoGet = RG_LOST_WOODS_BEAN_SOUL; break;
            case AP_ITEM_ZR_BEAN_SOUL: randoGet = RG_ZORAS_RIVER_BEAN_SOUL; break;
            case AP_ITEM_SPEAK_DEKU: randoGet = RG_SPEAK_DEKU; break;
            case AP_ITEM_SPEAK_GERUDO: randoGet = RG_SPEAK_GERUDO; break;
            case AP_ITEM_SPEAK_GORON: randoGet = RG_SPEAK_GORON; break;
            case AP_ITEM_SPEAK_HYLIAN: randoGet = RG_SPEAK_HYLIAN; break;
            case AP_ITEM_SPEAK_KOKIRI: randoGet = RG_SPEAK_KOKIRI; break;
            case AP_ITEM_SPEAK_ZORA: randoGet = RG_SPEAK_ZORA; break;
            case AP_ITEM_ANIMAL_SOUL_COW: randoGet = RG_ANIMAL_SOUL_COW; break;
            case AP_ITEM_ANIMAL_SOUL_CUCCO: randoGet = RG_ANIMAL_SOUL_CUCCO; break;
            case AP_ITEM_ANIMAL_SOUL_DOG: randoGet = RG_ANIMAL_SOUL_DOG; break;
            case AP_ITEM_ANIMAL_SOUL_FISH: randoGet = RG_ANIMAL_SOUL_FISH; break;
            case AP_ITEM_ANIMAL_SOUL_BUG: randoGet = RG_ANIMAL_SOUL_BUG; break;
            case AP_ITEM_ANIMAL_SOUL_BUTTERFLY: randoGet = RG_ANIMAL_SOUL_BUTTERFLY; break;
            case AP_ITEM_ANIMAL_SOUL_FROG: randoGet = RG_ANIMAL_SOUL_FROG; break;
            case AP_ITEM_ANIMAL_SOUL_HORSE: randoGet = RG_ANIMAL_SOUL_HORSE; break;
            case AP_ITEM_ENEMY_SOUL_STALFOS: randoGet = RG_ENEMY_SOUL_STALFOS; break;
            case AP_ITEM_ENEMY_SOUL_OCTOROK: randoGet = RG_ENEMY_SOUL_OCTOROK; break;
            case AP_ITEM_ENEMY_SOUL_WALLMASTER: randoGet = RG_ENEMY_SOUL_WALLMASTER; break;
            case AP_ITEM_ENEMY_SOUL_DODONGO: randoGet = RG_ENEMY_SOUL_DODONGO; break;
            case AP_ITEM_ENEMY_SOUL_KEESE: randoGet = RG_ENEMY_SOUL_KEESE; break;
            case AP_ITEM_ENEMY_SOUL_TEKTITE: randoGet = RG_ENEMY_SOUL_TEKTITE; break;
            case AP_ITEM_ENEMY_SOUL_PEAHAT: randoGet = RG_ENEMY_SOUL_PEAHAT; break;
            case AP_ITEM_ENEMY_SOUL_LIZALFOS_DINOLFOS: randoGet = RG_ENEMY_SOUL_LIZALFOS_DINOLFOS; break;
            case AP_ITEM_ENEMY_SOUL_GOHMA_LARVA: randoGet = RG_ENEMY_SOUL_GOHMA_LARVA; break;
            case AP_ITEM_ENEMY_SOUL_SHABOM: randoGet = RG_ENEMY_SOUL_SHABOM; break;
            case AP_ITEM_ENEMY_SOUL_BABY_DODONGO: randoGet = RG_ENEMY_SOUL_BABY_DODONGO; break;
            case AP_ITEM_ENEMY_SOUL_BIRI_BARI: randoGet = RG_ENEMY_SOUL_BIRI_BARI; break;
            case AP_ITEM_ENEMY_SOUL_TAILPASARAN: randoGet = RG_ENEMY_SOUL_TAILPASARAN; break;
            case AP_ITEM_ENEMY_SOUL_TORCH_SLUG: randoGet = RG_ENEMY_SOUL_TORCH_SLUG; break;
            case AP_ITEM_ENEMY_SOUL_MOBLIN: randoGet = RG_ENEMY_SOUL_MOBLIN; break;
            case AP_ITEM_ENEMY_SOUL_ARMOS: randoGet = RG_ENEMY_SOUL_ARMOS; break;
            case AP_ITEM_ENEMY_SOUL_DEKU_BABA: randoGet = RG_ENEMY_SOUL_DEKU_BABA; break;
            case AP_ITEM_ENEMY_SOUL_DEKU_SCRUB: randoGet = RG_ENEMY_SOUL_DEKU_SCRUB; break;
            case AP_ITEM_ENEMY_SOUL_BUBBLE: randoGet = RG_ENEMY_SOUL_BUBBLE; break;
            case AP_ITEM_ENEMY_SOUL_BEAMOS: randoGet = RG_ENEMY_SOUL_BEAMOS; break;
            case AP_ITEM_ENEMY_SOUL_FLOORMASTER: randoGet = RG_ENEMY_SOUL_FLOORMASTER; break;
            case AP_ITEM_ENEMY_SOUL_REDEAD_GIBDO: randoGet = RG_ENEMY_SOUL_REDEAD_GIBDO; break;
            case AP_ITEM_ENEMY_SOUL_FLARE_DANCER: randoGet = RG_ENEMY_SOUL_FLARE_DANCER; break;
            case AP_ITEM_ENEMY_SOUL_DEAD_HAND: randoGet = RG_ENEMY_SOUL_DEAD_HAND; break;
            case AP_ITEM_ENEMY_SOUL_SHELL_BLADE: randoGet = RG_ENEMY_SOUL_SHELL_BLADE; break;
            case AP_ITEM_ENEMY_SOUL_LIKE_LIKE: randoGet = RG_ENEMY_SOUL_LIKE_LIKE; break;
            case AP_ITEM_ENEMY_SOUL_SPIKE: randoGet = RG_ENEMY_SOUL_SPIKE; break;
            case AP_ITEM_ENEMY_SOUL_ANUBIS: randoGet = RG_ENEMY_SOUL_ANUBIS; break;
            case AP_ITEM_ENEMY_SOUL_IRON_KNUCKLE: randoGet = RG_ENEMY_SOUL_IRON_KNUCKLE; break;
            case AP_ITEM_ENEMY_SOUL_SKULL_KID: randoGet = RG_ENEMY_SOUL_SKULL_KID; break;
            case AP_ITEM_ENEMY_SOUL_FLYING_POT: randoGet = RG_ENEMY_SOUL_FLYING_POT; break;
            case AP_ITEM_ENEMY_SOUL_FREEZARD: randoGet = RG_ENEMY_SOUL_FREEZARD; break;
            case AP_ITEM_ENEMY_SOUL_STINGER: randoGet = RG_ENEMY_SOUL_STINGER; break;
            case AP_ITEM_ENEMY_SOUL_WOLFOS: randoGet = RG_ENEMY_SOUL_WOLFOS; break;
            case AP_ITEM_ENEMY_SOUL_GUAY: randoGet = RG_ENEMY_SOUL_GUAY; break;
            case AP_ITEM_ENEMY_SOUL_JABU_TENTACLE: randoGet = RG_ENEMY_SOUL_JABU_TENTACLE; break;
            case AP_ITEM_ENEMY_SOUL_DARK_LINK: randoGet = RG_ENEMY_SOUL_DARK_LINK; break;
        case AP_ITEM_ENEMY_SOUL_DOOR_TRAP: randoGet = RG_ENEMY_SOUL_DOOR_TRAP; break;
        case AP_ITEM_ENEMY_SOUL_FLYING_FLOOR_TILE: randoGet = RG_ENEMY_SOUL_FLYING_FLOOR_TILE; break;
        case AP_ITEM_ENEMY_SOUL_GERUDO_THIEF: randoGet = RG_ENEMY_SOUL_GERUDO_THIEF; break;
        case AP_ITEM_ENEMY_SOUL_POE_SISTER: randoGet = RG_ENEMY_SOUL_POE_SISTER; break;
        case AP_ITEM_ENEMY_SOUL_POE: randoGet = RG_ENEMY_SOUL_POE; break;
        case AP_ITEM_ENEMY_SOUL_LEEVER: randoGet = RG_ENEMY_SOUL_LEEVER; break;
        case AP_ITEM_ENEMY_SOUL_STALCHILD: randoGet = RG_ENEMY_SOUL_STALCHILD; break;
        case AP_ITEM_ENEMY_SOUL_BIG_OCTO: randoGet = RG_ENEMY_SOUL_BIG_OCTO; break;

        case AP_ITEM_SHADOW_SILVER_BLADES: randoGet = RG_SHADOW_SILVER_BLADES; break;
        case AP_ITEM_SHADOW_SILVER_PIT: randoGet = RG_SHADOW_SILVER_PIT; break;
        case AP_ITEM_SHADOW_SILVER_SPIKES: randoGet = RG_SHADOW_SILVER_SPIKES; break;
        case AP_ITEM_SPIRIT_SILVER_CHILD: randoGet = RG_SPIRIT_SILVER_CHILD; break;
        case AP_ITEM_SPIRIT_SILVER_SUN: randoGet = RG_SPIRIT_SILVER_SUN; break;
        case AP_ITEM_SPIRIT_SILVER_BOULDERS: randoGet = RG_SPIRIT_SILVER_BOULDERS; break;
        case AP_ITEM_BOTW_SILVER: randoGet = RG_BOTW_SILVER; break;
        case AP_ITEM_ICE_CAVERN_SILVER_BLADES: randoGet = RG_ICE_CAVERN_SILVER_BLADES; break;
        case AP_ITEM_ICE_CAVERN_SILVER_BLOCK: randoGet = RG_ICE_CAVERN_SILVER_BLOCK; break;
        case AP_ITEM_GTG_SILVER_SLOPE: randoGet = RG_GTG_SILVER_SLOPE; break;
        case AP_ITEM_GTG_SILVER_LAVA: randoGet = RG_GTG_SILVER_LAVA; break;
        case AP_ITEM_GTG_SILVER_WATER: randoGet = RG_GTG_SILVER_WATER; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_LIGHT: randoGet = RG_GANONS_CASTLE_SILVER_LIGHT; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_FOREST: randoGet = RG_GANONS_CASTLE_SILVER_FOREST; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_FIRE: randoGet = RG_GANONS_CASTLE_SILVER_FIRE; break;
        case AP_ITEM_GANONS_CASTLE_SILVER_SPIRIT: randoGet = RG_GANONS_CASTLE_SILVER_SPIRIT; break;
        case AP_ITEM_DODONGOS_CAVERN_MQ_SILVER: randoGet = RG_DODONGOS_CAVERN_MQ_SILVER; break;
        case AP_ITEM_SHADOW_MQ_SILVER_INVISIBLE_BLADES: randoGet = RG_SHADOW_MQ_SILVER_INVISIBLE_BLADES; break;
        case AP_ITEM_SPIRIT_MQ_SILVER_LOBBY: randoGet = RG_SPIRIT_MQ_SILVER_LOBBY; break;
        case AP_ITEM_SPIRIT_MQ_SILVER_BIG_WALL: randoGet = RG_SPIRIT_MQ_SILVER_BIG_WALL; break;
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_WATER: randoGet = RG_GANONS_CASTLE_MQ_SILVER_WATER; break;
        case AP_ITEM_GANONS_CASTLE_MQ_SILVER_SHADOW: randoGet = RG_GANONS_CASTLE_MQ_SILVER_SHADOW; break;
            case AP_ITEM_FLOW_OF_TIME: randoGet = RG_FLOW_OF_TIME; break;
            default:
                if (IsApSongNote(itemId)) {
                    randoGet = GetApSongNoteDisplay(itemId);
                    break;
                }
                SPDLOG_WARN("[Archipelago] Unknown SOH-EXTREME item id {}", itemId);
                return true;
        }
    }

    if (randoGet == RG_NONE) {
        return true;
    }

    // SOH-EXTREME inserts one physical tier before the vanilla Strength/Scale
    // upgrades. Resolve those first AP copies explicitly instead of depending on
    // the generic progressive presentation path to infer the fork-only tier:
    //   Strength #1 -> Grab / Power Bracelet (does not increment UPG_STRENGTH)
    //   Scale    #1 -> Swim / Bronze Scale    (does not increment UPG_SCALE)
    // Subsequent copies remain RG_PROGRESSIVE_* and advance the normal tiers.
    if (randoGet == RG_PROGRESSIVE_STRENGTH && OTRGlobals::Instance->gRandomizer->GetRandoSettingValue(RSK_SHUFFLE_GRAB) &&
        !Flags_GetRandomizerInf(RAND_INF_CAN_GRAB)) {
        SPDLOG_INFO("[Archipelago] Resolving first Strength Upgrade as Grab / Power Bracelet");
        randoGet = RG_POWER_BRACELET;
    } else if (randoGet == RG_PROGRESSIVE_SCALE && OTRGlobals::Instance->gRandomizer->GetRandoSettingValue(RSK_SHUFFLE_SWIM) &&
               !Flags_GetRandomizerInf(RAND_INF_CAN_SWIM)) {
        SPDLOG_INFO("[Archipelago] Resolving first Progressive Scale as Swim / Bronze Scale");
        randoGet = RG_BRONZE_SCALE;
    }

    // SoH traps are transient effects, not persistent inventory. A brand-new
    // local save reconstructing old ReceivedItems must not retrigger historical
    // traps. Live traps still use the normal pendingIceTrapCount path.
    if (randoGet == RG_ICE_TRAP) {
        if (historicalNewSaveReplay) {
            return true;
        }
        const auto beforeTrapCount = gSaveContext.ship.pendingIceTrapCount;
        gSaveContext.ship.pendingIceTrapCount++;
        if (gSaveContext.ship.pendingIceTrapCount <= beforeTrapCount) {
            SPDLOG_ERROR("[Archipelago] Ice Trap failed to queue; retrying");
            return false;
        }
        SPDLOG_INFO("[Archipelago] Queued Ice Trap (pending={})", gSaveContext.ship.pendingIceTrapCount);
        Notification::Emit({ .prefix = "Archipelago", .message = "received", .suffix = "Ice Trap",
                             .remainingTime = 4.0f });
        SendTrapLink("Ice Trap");
        return true;
    }

    auto item = Rando::StaticData::RetrieveItem(randoGet);
    GetItemEntry giEntry;
    if (randoGet == RG_PROGRESSIVE_WALLET && !historicalNewSaveReplay) {
        // Choose the overhead model from the real save, never the check finder's
        // simulated inventory. Let that native item grant exactly one tier.
        const int level = CUR_UPG_VALUE(UPG_WALLET);
        const bool tycoon = RAND_GET_OPTION(RSK_INCLUDE_TYCOON_WALLET).Get();
        RandomizerGet wallet = RG_CHILD_WALLET;
        if (Flags_GetRandomizerInf(RAND_INF_HAS_WALLET)) {
            if (level == 0) wallet = RG_ADULT_WALLET;
            else if (level == 1) wallet = RG_GIANT_WALLET;
            else if (level == 2 && tycoon) wallet = RG_TYCOON_WALLET;
            else if (RAND_GET_OPTION(RSK_INFINITE_UPGRADES).IsNot(RO_INF_UPGRADES_OFF)) wallet = RG_WALLET_INF;
            else wallet = tycoon ? RG_TYCOON_WALLET : RG_GIANT_WALLET;
        }
        giEntry = Rando::StaticData::RetrieveItem(wallet).GetGIEntry_Copy();
    } else {
        giEntry = item.GetGIEntry_Copy();
    }

    // These rewards must behave identically during live delivery and historical
    // replay. Neither path relies on the native local-check animation hook.
    if ((randoGet == RG_GOLD_SKULLTULA_TOKEN && (historicalNewSaveReplay || !item.IsMajorItem())) ||
        randoGet == RG_PIECE_OF_HEART || randoGet == RG_HEART_CONTAINER) {
        if (giEntry.itemId == ITEM_NONE) return false;
        Item_Give(gPlayState, static_cast<uint8_t>(giEntry.itemId));
        if (randoGet == RG_PIECE_OF_HEART || randoGet == RG_HEART_CONTAINER) {
            // Item_Give adds the fourth piece; the local-check receive handler
            // normally converts it into capacity, but AP does not enter that handler.
            const uint32_t pieces = (gSaveContext.inventory.questItems >> (QUEST_HEART_PIECE + 4)) & 0xF;
            if (pieces >= 4) {
                gSaveContext.inventory.questItems = (gSaveContext.inventory.questItems & 0x0FFFFFFF) |
                    ((pieces % 4) << (QUEST_HEART_PIECE + 4));
                gSaveContext.healthCapacity += (pieces / 4) * FULL_HEART_HEALTH;
            }
            gSaveContext.health = gSaveContext.healthCapacity;
            gSaveContext.healthAccumulator = 0;
        }
        if (!historicalNewSaveReplay) {
            Notification::Emit({ .prefix = "Archipelago", .message = "received",
                                 .suffix = item.GetName().english, .remainingTime = 4.0f });
        }
        return true;
    }

    if (randoGet == RG_PROGRESSIVE_WALLET && historicalNewSaveReplay) {
        // Resolve from the live save, not the check finder's simulated inventory.
        const int level = CUR_UPG_VALUE(UPG_WALLET);
        const int maxLevel = RAND_GET_OPTION(RSK_INCLUDE_TYCOON_WALLET).Get() ? 3 : 2;
        if (!Flags_GetRandomizerInf(RAND_INF_HAS_WALLET)) {
            Flags_SetRandomizerInf(RAND_INF_HAS_WALLET);
        } else if (level < maxLevel) {
            Inventory_ChangeUpgrade(UPG_WALLET, level + 1);
        } else if (RAND_GET_OPTION(RSK_INFINITE_UPGRADES).IsNot(RO_INF_UPGRADES_OFF)) {
            Randomizer_Item_Give(gPlayState, Rando::StaticData::RetrieveItem(RG_WALLET_INF).GetGIEntry_Copy());
        }
        if (RAND_GET_OPTION(RSK_FULL_WALLETS).Get()) {
            gSaveContext.rupees = static_cast<s16>(CUR_CAPACITY(UPG_WALLET));
            gSaveContext.rupeeAccumulator = 0;
        }
        if (!historicalNewSaveReplay) {
            Notification::Emit({ .prefix = "Archipelago", .message = "received",
                                 .suffix = item.GetName().english, .remainingTime = 4.0f });
        }
        // An extra wallet at the maximum tier is still a valid AP receipt.
        return true;
    }

    // A newly-created local AP file may need to reconstruct a large server-side
    // ReceivedItems history. Starting a hold-item cutscene for every historical
    // major item can leave the first session effectively locked in item presentation
    // for minutes. Apply historical rewards directly and silently instead.
    if (historicalNewSaveReplay) {
        if (IsApSongNote(itemId)) {
            if (!ApplyApSongNote(itemId)) return false;
            RefreshSongNotes();
            return true;
        }
        if (ApplyExtremePersistentApItem(itemId)) {
            return true;
        }

        if (giEntry.modIndex == MOD_RANDOMIZER) {
            Randomizer_Item_Give(gPlayState, giEntry);
        } else if (giEntry.itemId != ITEM_NONE) {
            Item_Give(gPlayState, static_cast<uint8_t>(giEntry.itemId));
        } else {
            SPDLOG_WARN("[Archipelago] Historical AP item {} ({}) has no direct give path; treating as consumed",
                        itemId, item.GetName().english);
        }
        return true;
    }

    // Match normal randomizer UX more closely: only advancement/major items interrupt
    // gameplay with the hold-item animation. Refills, ammo, rupees, maps/compasses,
    // ordinary hearts, and other non-major rewards are applied immediately and shown
    // in the side notification feed instead. This is especially important for AP
    // starting inventory/replayed filler, which should not repeatedly stop the player.
    const bool isExtremeProgression =
        ((itemId >= AP_EXTREME_ITEM_BASE && itemId <= AP_ITEM_ENEMY_SOUL_BIG_OCTO &&
          !IsApSongNote(itemId)) ||
         (itemId >= AP_FIRST_SILVER_ITEM && itemId <= AP_LAST_SILVER_ITEM));
    const GetItemCategory apCategory = item.GetCategory();
    const bool forceHoldAnimation =
        isExtremeProgression ||
        apCategory == ITEM_CATEGORY_MAJOR ||
        apCategory == ITEM_CATEGORY_SMALL_KEY ||
        apCategory == ITEM_CATEGORY_BOSS_KEY;

    if (!item.IsMajorItem() && !forceHoldAnimation) {
        SPDLOG_INFO("[Archipelago] Applying non-major item id {} ({}) without get-item animation",
                    itemId, item.GetName().english);

        // Native-backed randomizer entries (MOD_NONE) must use vanilla Item_Give.
        // Only show the side receipt if persistent state actually changed.
        const uint64_t fillerDigestBefore = CaptureApPersistentGrantDigest();
        if (giEntry.modIndex == MOD_RANDOMIZER) {
            Randomizer_Item_Give(gPlayState, giEntry);
        } else if (giEntry.itemId != ITEM_NONE) {
            Item_Give(gPlayState, static_cast<uint8_t>(giEntry.itemId));
        } else {
            SPDLOG_ERROR("[Archipelago] Non-major item {} ({}) has neither a randomizer handler nor a vanilla ItemID",
                         itemId, item.GetName().english);
            return true;
        }

        const bool fillerStateChanged =
            CaptureApPersistentGrantDigest() != fillerDigestBefore;

        // The side feed is also the user's complete same-game receive history.
        // Capped ammo/rupees/hearts are still real AP receives, so notify them too.
        // Important/progression items remain stricter and are notified only after
        // their persistent save-state verification succeeds.
        Notification::Emit({
            .prefix = "Archipelago",
            .message = "received",
            .suffix = item.GetName().english,
            .remainingTime = 4.0f,
        });

        if (!fillerStateChanged) {
            SPDLOG_INFO("[Archipelago] Non-major item {} ({}) was received but inventory state was capped/unchanged",
                        itemId, item.GetName().english);
        }
        return true;
    }

    SPDLOG_INFO("[Archipelago] Presenting major item id {} as RandomizerGet {}", itemId, static_cast<int>(randoGet));

    // Important hold-item rewards should not start while Link is swimming or
    // airborne. Some SoH get-item paths can begin in water without completing the
    // matching receive lifecycle cleanly. Leave the AP item at the queue front and
    // retry once Link is safely standing on land.
    if (!SohExtreme::IsPlayerOnDryGround(player)) {
        SPDLOG_DEBUG("[Archipelago] Deferring important item {} until Link is grounded on land", itemId);
        return false;
    }

    // Every live major receipt must survive the actual engine grant. Merely
    // offering getItemEntry is not an animation or a receipt: another actor,
    // a trap or a scene transition can replace that offer before Link handles it.
    // Flag-backed souls/abilities/door keys use Return_Item_Entry just like other
    // randomizer items. Arm BEFORE the give so synchronous callbacks count too.
    const bool transactionalBaseMajor = true;
    if (transactionalBaseMajor) {
        gAwaitingMajorEntry = giEntry;
        awaitingMajorItemReceipt = true;
        awaitingMajorSequence = sequence;
        awaitingMajorApItemId = itemId;
        awaitingMajorModIndex = static_cast<int>(giEntry.modIndex);
        awaitingMajorItemId = static_cast<int>(giEntry.itemId);
        awaitingMajorGetItemId = static_cast<int>(giEntry.getItemId);
        gAwaitingMajorFrames = 0;
    }

    if (IsApSongNote(itemId)) {
        songNotePickupDescription = BuildApSongNotePickupDescription(itemId);
    }

    if (!GiveItemEntryWithoutActor(gPlayState, giEntry)) {
        // Give did not begin. Undo only the transaction we just armed; the item
        // remains pendingItems.front() and will be retried on a later safe frame.
        if (transactionalBaseMajor && awaitingMajorItemReceipt &&
            awaitingMajorSequence == sequence) {
            awaitingMajorItemReceipt = false;
            awaitingMajorSequence = 0;
            awaitingMajorApItemId = 0;
            awaitingMajorModIndex = 0;
            awaitingMajorItemId = 0;
            awaitingMajorGetItemId = 0;
            gAwaitingMajorFrames = 0;
        }

        SPDLOG_DEBUG("[Archipelago] Link cannot receive major item {} yet; retrying", itemId);
        return false;
    }

    // If OnItemReceive fired synchronously inside GiveItemEntryWithoutActor(),
    // FinalizeMajorItemReceipt() has already cleared the awaiting state and advanced
    // appliedItemCount. That is a successful receive, not a reason to re-arm it.
    if (!awaitingMajorItemReceipt || awaitingMajorSequence != sequence) {
        SPDLOG_INFO("[Archipelago] Major AP receive #{} committed synchronously during give", sequence);
        return true;
    }

    SPDLOG_INFO("[Archipelago] Major AP receive #{} started; waiting for asynchronous OnItemReceive commit", sequence);

    // The side receipt is emitted from FinalizeMajorItemReceipt(), after SoH's
    // OnItemReceive confirms the item was really granted. That avoids claiming a
    // major item was received if a death/reset interrupts its get-item animation.
    return true;
}

void ArchipelagoClient::QueueDeathLink(const std::string& source, const std::string& cause) {
    // Network callback: only copy data under the mutex. Do not read CVars or touch
    // gameplay state from APCpp's websocket thread.
    std::scoped_lock lock(queueMutex);
    pendingDeathLinks.push_back({ source, cause });
}

void ArchipelagoClient::QueueTrapLink(const std::string& source, const std::string& trapName) {
    // Network callback: only copy data under the mutex.
    std::scoped_lock lock(queueMutex);
    pendingTrapLinks.push_back({ source, trapName.empty() ? "Trap" : trapName });
}

void ArchipelagoClient::SendDeathLink() {
    if (!deathLinkEnabled || !IsAuthenticated()) return;
    const char* slot = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("SlotName"), "SOH-EXTREME");
    const auto now = std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    AP_Bounce bounce{};
    std::vector<std::string> tags{ "DeathLink" };
    bounce.tags = &tags;
    bounce.data = "{\"time\":" + std::to_string(now) + ",\"source\":\"" +
                  EscapeJsonString(slot == nullptr ? "SOH-EXTREME" : slot) +
                  "\",\"cause\":\"" + EscapeJsonString(slot == nullptr ? "Link" : slot) +
                  " met with a terrible fate.\"}";
    AP_SendBounce(bounce);
    SPDLOG_INFO("[Archipelago] Sent DeathLink");
}

void ArchipelagoClient::SendTrapLink(const std::string& trapName) {
    if (!trapLinkEnabled || !IsAuthenticated()) return;
    const char* slot = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("SlotName"), "SOH-EXTREME");
    const auto now = std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    AP_Bounce bounce{};
    std::vector<std::string> tags{ "TrapLink" };
    bounce.tags = &tags;
    bounce.data = "{\"time\":" + std::to_string(now) + ",\"source\":\"" +
                  EscapeJsonString(slot == nullptr ? "SOH-EXTREME" : slot) +
                  "\",\"trap_name\":\"" + EscapeJsonString(trapName) + "\"}";
    AP_SendBounce(bounce);
    SPDLOG_INFO("[Archipelago] Sent TrapLink: {}", trapName);
}

void ArchipelagoClient::RefreshSongNotes() {


    int offset = 0;
    for (const auto& song : kApSongNotes) {
        int collected = 0;
        for (int i = 0; i < song.count; ++i) {
            if (HasNote(RAND_INF_SONG_NOTE_0, offset + i)) ++collected;
        }

        const bool complete = collected == song.count;
        const bool alreadyOwned = (gSaveContext.inventory.questItems & (1u << song.quest)) != 0;
        if (complete && !alreadyOwned) {
            SetQuestSong(song.quest);
            SPDLOG_INFO("[Archipelago] Song Notes complete: {} ({}/{}) -> song unlocked",
                        song.name, collected, song.count);
            Notification::Emit({
                .prefix = "Song Notes",
                .message = "completed",
                .suffix = song.name,
                .remainingTime = 5.0f,
            });
        }
        offset += song.count;
    }
}

bool ArchipelagoClient::IsGameplaySessionActive() const {
    return currentSaveIsArchipelago && !saveIdentityMismatch &&
           gPlayState != nullptr && gSaveContext.ship.quest.id == QUEST_RANDOMIZER;
}

void ArchipelagoClient::BeginFileSelectActivation() {
    fileSelectActivationRequested = true;
}

void ArchipelagoClient::EndFileSelectActivation() {
    fileSelectActivationRequested = false;
}

std::vector<std::string> ArchipelagoClient::GetChatMessages() {
    std::scoped_lock lock(queueMutex);
    return std::vector<std::string>(chatMessages.begin(), chatMessages.end());
}

void ArchipelagoClient::SendChatMessage(const std::string& message) {
    if (!IsAuthenticated()) return;
    std::string trimmed = message;
    while (!trimmed.empty() && std::isspace(static_cast<unsigned char>(trimmed.front()))) trimmed.erase(trimmed.begin());
    while (!trimmed.empty() && std::isspace(static_cast<unsigned char>(trimmed.back()))) trimmed.pop_back();
    if (trimmed.empty()) return;
    AP_Say(trimmed);
    SPDLOG_INFO("[Archipelago] Chat sent: {}", trimmed);
}

void ArchipelagoClient::UpdateGoal() {
    if (!IsGameplaySessionActive() || gPlayState == nullptr) return;
    if (!IsAuthenticated()) goalReported = false;
    auto ctx = Rando::Context::GetInstance();
    if (!ctx) return;
    auto* win = ctx->GetItemLocation(RC_WINCON);
    const int required = RAND_GET_OPTION(RSK_WINCON_TRIFORCE_COUNT).Get();
    const bool huntComplete = RAND_GET_OPTION(RSK_WINCON).Is(RO_WINCON_TRIFORCE_PIECES) &&
        required > 0 && gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected >= required;
    // An interrupted item presentation is not a committed goal.
    if (awaitingMajorItemReceipt) return;
    if (huntComplete && win != nullptr && !win->HasObtained()) {
        win->SetCheckStatus(RCSHOW_COLLECTED);
    }
    const bool complete = gSaveContext.ship.stats.gameComplete || (win != nullptr && win->HasObtained());
    if (complete && IsAuthenticated() && !goalReported) {
        AP_StoryComplete();
        goalReported = true;
        SPDLOG_INFO("[Archipelago] Goal complete; sent CLIENT_GOAL");
    }
    Player* player = GET_PLAYER(gPlayState);
    if (huntComplete && !gSaveContext.ship.stats.gameComplete && player != nullptr &&
        gSaveContext.health > 0 && !GameInteractor::IsGameplayPaused() &&
        gPlayState->transitionTrigger == TRANS_TRIGGER_OFF &&
        !Player_InBlockingCsMode(gPlayState, player) &&
        !(player->stateFlags1 & (PLAYER_STATE1_IN_ITEM_CS | PLAYER_STATE1_GETTING_ITEM))) {
        GameInteractor_SetTriforceHuntCreditsWarpActive(true);
    }
}

void ArchipelagoClient::Update() {
    if (enabled.load()) DrainSlotData();
    ReconcileSaveConnection();
    ServiceFinderWorker();
    if (!enabled.load()) return;
    DrainMessages();
    ServiceHintBridge();

    // Title/file-select safety boundary. APCpp may stay connected so authentication
    // can complete, but NOTHING that mutates gameplay state is processed until the
    // player actually chooses an AP file or a randomizer save is active.
    if (gPlayState == nullptr) {
        saveRuntimeSynchronized = false;
        deathStateInitialized = false;

        if (!fileSelectActivationRequested) {
            return;
        }

        // The user clicked Start/New AP File. During this narrow preparation phase,
        // only receive scout metadata needed by the file-select readiness barrier.
        // Do not apply placements, items, checks, DeathLink/TrapLink, time, or inventory.
        std::deque<PendingScout> scouts;
        {
            std::scoped_lock lock(queueMutex);
            scouts.swap(pendingScouts);
        }
        for (auto& scout : scouts) {
            IndexScoutedLocation(scout.locationId, scout.info);
            scoutedLocations[scout.locationId] = std::move(scout.info);
        }
        if (IsAuthenticated()) {
            RequestLocationScouts();
        }
        return;
    }

    // A non-randomizer save must never consume AP gameplay queues either.
    if (gSaveContext.ship.quest.id != QUEST_RANDOMIZER) {
        saveRuntimeSynchronized = false;
        deathStateInitialized = false;
        return;
    }

    // From 0.5.9 onward AP ownership is a property of the SAVE, not merely of
    // "being a randomizer file while the AP client happens to be connected".
    // This prevents a normal local randomizer save from consuming server items.
    if (!currentSaveIsArchipelago || saveIdentityMismatch) {
        saveRuntimeSynchronized = false;
        deathStateInitialized = false;
        return;
    }

    fileSelectActivationRequested = false;

    // New AP file creation only stamps metadata. Build the potentially large
    // historical ReceivedItems replay now, after gameplay exists and file-select
    // has already returned. This removes AP queue/history work from Sram_InitSave().
    if (newSaveReplayPending) {
        PrepareNewSaveItemReplay();
    }

    // Consume APCpp-published work only from the gameplay thread.
    if (IsAuthenticated() && slotSettingsLoaded && slotSettingsPendingApply.exchange(false)) {
        ApplySlotSettings();
    }

    // Load may have preceded uncached slot data. Ownership was verified above;
    // finish that one request when gameplay can safely transition. Reconnects
    // and ordinary settings refreshes do not arm another spawn request.
    if (SohExtreme::EntranceRuntime::ServicePendingSpawn(SohExtreme::CanReceiveGameplayReward(gPlayState))) {
        SPDLOG_INFO("[Archipelago] Applied pending load spawn from this save's verified entrance map");
        return;
    }

    if (activeLocationsPendingRefresh.exchange(false)) {
        // The server active-location set is authoritative. Invalidate the full
        // Check Finder map and schedule ONE deferred availability pass instead
        // of letting rows keep stale visibility/reachability until a reload.
        checkFinderMappingsPrepared = false;
        if (CVarGetInteger(CVAR_TRACKER_CHECK("EnableAvailableChecks"), 0)) {
            CheckTracker::RecalculateAvailableChecks();
        }
        SPDLOG_DEBUG("[Archipelago] Active AP location set refreshed; Check Finder resync scheduled");
    }

    // Keep AP authoritative without scanning every randomizer option every frame.
    // A local menu edit is repaired within roughly one second.
    if (IsAuthenticated() && slotSettingsLoaded) {
        if (++settingsEnforceFrameCounter >= 60) {
            settingsEnforceFrameCounter = 0;
            EnforceSlotSettings();
        }
    } else {
        settingsEnforceFrameCounter = 0;
    }

    // Existing-save reconciliation happens exactly once after gameplay really exists.
    // Slot settings were already applied either from the per-save cached snapshot
    // during LoadSaveMetadata() or from slotSettingsPendingApply above. Re-running
    // ApplySlotSettings() here repeats ShipInit::Init("IS_RANDO") on the load frame
    // and causes an avoidable hitch.
    if (!saveRuntimeSynchronized && IsAuthenticated() && slotSettingsLoaded) {
        // Placement data is lazy per-check.  A whole-table pass here recreates
        // the same multi-thousand-entry startup hitch we intentionally avoid in
        // file-select/new-file creation.
        ApplyPostInitSlotState();
        saveRuntimeSynchronized = true;
        SPDLOG_INFO("[Archipelago] Reconciled loaded randomizer save with authoritative AP slot state (lazy placements)");
    }

    std::deque<int64_t> checked;
    std::deque<PendingScout> scouts;
    std::deque<PendingDeathLink> deaths;
    std::deque<PendingTrapLink> traps;
    {
        std::scoped_lock lock(queueMutex);
        checked.swap(pendingCheckedLocations);
        scouts.swap(pendingScouts);
        deaths.swap(pendingDeathLinks);
        traps.swap(pendingTrapLinks);
    }

    // Apply link events only on the gameplay thread. APCpp callbacks run from its
    // networking context, so touching gSaveContext/player state in the callback itself
    // would be unsafe. Ignore our own Bounce echo here as well.
    const char* ownSlotPtr = CVarGetString(CVAR_REMOTE_ARCHIPELAGO("SlotName"), "");
    const std::string ownSlot = ownSlotPtr == nullptr ? "" : ownSlotPtr;
    while (!deaths.empty() && !ownSlot.empty() && deaths.front().source == ownSlot) deaths.pop_front();
    while (!traps.empty() && !ownSlot.empty() && traps.front().source == ownSlot) traps.pop_front();

    if (!deathLinkEnabled) deaths.clear();
    if (!trapLinkEnabled) traps.clear();
    if (!deaths.empty()) {
        if (gPlayState != nullptr && GET_PLAYER(gPlayState) != nullptr) {
            const auto& death = deaths.front();
            suppressNextDeathLinkSend = true;
            GameInteractor::RawAction::SetPlayerHealth(0);
            Notification::Emit({ .prefix = "DeathLink", .message = "received from", .suffix = death.source,
                                 .remainingTime = 5.0f });
            SPDLOG_INFO("[Archipelago] Applied DeathLink from {}: {}", death.source, death.cause);
            deaths.pop_front();
        }
        if (!deaths.empty()) {
            std::scoped_lock lock(queueMutex);
            while (!deaths.empty()) { pendingDeathLinks.push_front(std::move(deaths.back())); deaths.pop_back(); }
        }
    }

    if (!traps.empty()) {
        if (gPlayState != nullptr && GET_PLAYER(gPlayState) != nullptr) {
            const auto& trap = traps.front();
            gSaveContext.ship.pendingIceTrapCount++;
            Notification::Emit({ .prefix = "TrapLink", .message = "received", .suffix = trap.trapName,
                                 .remainingTime = 5.0f });
            SPDLOG_INFO("[Archipelago] Queued TrapLink '{}' from {}", trap.trapName, trap.source);
            traps.pop_front();
        }
        if (!traps.empty()) {
            std::scoped_lock lock(queueMutex);
            while (!traps.empty()) { pendingTrapLinks.push_front(std::move(traps.back())); traps.pop_back(); }
        }
    }

    // Verified major-item completion.
    //
    // Presentation/callback alone is never enough. The side popup and AP receive
    // cursor advance only after persistent inventory/save state actually changed.
    if (awaitingMajorItemReceipt && gPlayState != nullptr) {
        ++gAwaitingMajorFrames;

        Player* majorPlayer = GET_PLAYER(gPlayState);
        if (majorPlayer != nullptr && gSaveContext.health > 0) {
            const bool stillInMajorReceive = !SohExtreme::CanReceiveGameplayReward(gPlayState);

            // Never infer a receipt from unrelated inventory changes. If the
            // engine did not report this item, retry after its presentation ends.
            if (!stillInMajorReceive && gAwaitingMajorFrames >= AP_MAJOR_RECEIVE_VERIFY_TIMEOUT_FRAMES) {
                SPDLOG_WARN("[Archipelago] AP receive #{} item {} had no matching receipt; retrying",
                            awaitingMajorSequence, awaitingMajorApItemId);

                awaitingMajorItemReceipt = false;
                awaitingMajorSequence = 0;
                awaitingMajorApItemId = 0;
                awaitingMajorModIndex = 0;
                awaitingMajorItemId = 0;
                awaitingMajorGetItemId = 0;
                gAwaitingMajorFrames = 0;
            }
        }
    }

    // Brand-new local AP files reconstruct already-received server history silently
    // and in a small per-frame batch. Live rewards remain strictly one-at-a-time so
    // normal hold-item animations cannot overwrite one another.
    if (ProcessRemotePresentation()) {
        // One presentation owns Link's get-item entry until it finishes.
    } else if (gNewSaveReplayGraceFrames > 0) {
        --gNewSaveReplayGraceFrames;
    } else {
        const bool reconstructing =
            gNewSaveReplayTargetCount != 0 && appliedItemCount < gNewSaveReplayTargetCount;
        const int itemBudget = reconstructing ? AP_NEW_SAVE_REPLAY_ITEMS_PER_FRAME : 1;

        for (int processed = 0; processed < itemBudget; ++processed) {
            PendingItem nextItem{};
            {
                std::scoped_lock lock(queueMutex);
                while (!pendingItems.empty() && pendingItems.front().sequence < appliedItemCount) {
                    pendingItems.pop_front();
                }
                if (awaitingMajorItemReceipt || pendingItems.empty()) {
                    break;
                }
                // PEEK only. MarkItemApplied() owns removal after a successful grant.
                nextItem = pendingItems.front();
            }

            if (!ProcessItem(nextItem.id, nextItem.notify, nextItem.sequence)) {
                SPDLOG_DEBUG("[Archipelago] Receive #{} not granted yet; leaving it at queue front",
                             nextItem.sequence);
                break;
            }

            if (awaitingMajorItemReceipt && awaitingMajorSequence == nextItem.sequence) {
                SPDLOG_DEBUG("[Archipelago] Receive #{} is awaiting actual major-item grant; cursor not advanced",
                             nextItem.sequence);
                break;
            }

            MarkItemApplied(nextItem.sequence);

            if (gNewSaveReplayTargetCount != 0 && appliedItemCount >= gNewSaveReplayTargetCount) {
                SPDLOG_INFO("[Archipelago] New-save historical item reconstruction complete at {} items",
                            appliedItemCount);
                gNewSaveReplayTargetCount = 0;
                break;
            }
        }
    }

    for (auto& scout : scouts) {
        IndexScoutedLocation(scout.locationId, scout.info);
        scoutedLocations[scout.locationId] = std::move(scout.info);
    }
    if (!scouts.empty()) {
        SPDLOG_INFO("[Archipelago] Received {} scouted placement records ({}/{})", scouts.size(),
                    scoutedLocations.size(), expectedScoutCount);
        // Scout chunks can arrive after a scene has already initialized. Refresh only
        // the current scene; never bulk-apply the accumulated world table.
        if (gPlayState != nullptr) {
            RefreshPlacementsForScene(static_cast<int16_t>(gPlayState->sceneNum));
            const RandomizerCheckArea area = CheckTracker::GetCheckArea();
            if (area != RCAREA_INVALID) {
                CheckTracker::RecalculateAreaTotals(area);
                CheckTracker::UpdateAreas(area);
            }
        }
        // Scout replies can arrive in several chunks. Re-applying the entire
        // accumulated placement table after every chunk makes reload work grow
        // quadratically. Do not bulk-apply the entire accumulated table when the
        // last scout chunk arrives; concrete actors/checks stay scene-local.
        //
        // Check Finder is different: if the user enabled it, the completed scout
        // set is now sufficient to build its fast full RC mapping on demand.
        if (expectedScoutCount == 0 || scoutedLocations.size() >= expectedScoutCount) {
            if (CVarGetInteger(CVAR_TRACKER_CHECK("EnableAvailableChecks"), 0)) {
                CheckTracker::RecalculateAvailableChecks();
            }
        }
    }

    // APCpp tells us about locations already checked on the server. Remember those so
    // the periodic local reconciliation pass does not spam duplicate sends.
    for (int64_t loc : checked) {
        const bool newlyConfirmed = reportedLocations.insert(loc).second;
        pendingLocationReports.erase(loc);
        if (newlyConfirmed) {
            CheckTracker::NotifyArchipelagoLocationReported(loc);
        }
        SPDLOG_DEBUG("[Archipelago] Server confirms location {} checked", loc);
    }

    if (!checked.empty()) RebuildHints();

    // Newly collected local checks are deferred out of the collection callback, but
    // only until the next normal gameplay update (typically one frame). This avoids
    // synchronous websocket work inside the pickup hook without the old ~1 second delay.
    for (int sent = 0; sent < AP_LOCATION_REPORTS_PER_FRAME && !gDeferredLocationReports.empty(); ++sent) {
        const int64_t locationId = gDeferredLocationReports.front();
        gDeferredLocationReports.pop_front();
        SendLocation(locationId, false);
    }

    const bool authenticated = IsAuthenticated();
    if (authenticated) {
        // Every fresh authentication gets a full local -> server reconciliation. This
        // fixes checks collected before connecting, while loading a save, or during a
        // moment where OnRandoSetCheckStatus was missed.
        if (!wasAuthenticated) {
            {
                std::scoped_lock lock(queueMutex);
                ResetFinderMirror();
            }
            std::vector<std::string> linkTags;
            if (deathLinkEnabled) linkTags.emplace_back("DeathLink");
            if (trapLinkEnabled) linkTags.emplace_back("TrapLink");
            AP_UpdateTags(linkTags);
            linkTagsSynchronized = true;
            SPDLOG_INFO("[Archipelago] Link tags: DeathLink={}, TrapLink={}", deathLinkEnabled, trapLinkEnabled);
            SPDLOG_INFO("[Archipelago] Authenticated; synchronizing collected locations");
            // Do not clear server-confirmed checks here. QueueCheckedLocation()
            // may already have populated speech/fallback locations during the
            // authentication handshake; clearing them here made first-talk checks
            // repeat after reconnect/load.
            syncFrameCounter = 0;
            scoutsRequested = false;
            RequestLocationScouts();
            SyncCollectedLocations();
        } else if (++syncFrameCounter >= 60) {
            // Retry LocationChecks until the AP server confirms them.
            syncFrameCounter = 0;
            if (!pendingLocationReports.empty()) {
                std::vector<int64_t> retryLocations(pendingLocationReports.begin(),
                                                    pendingLocationReports.end());
                pendingLocationReports.clear();
                for (int64_t locationId : retryLocations) {
                    SendLocation(locationId, false);
                }
            }
            SyncCollectedLocations();
        }


        // Throttled internally; retries only missing records after a partial reply.
        RequestLocationScouts();
    } else if (wasAuthenticated) {
        // Preserve the last server-confirmed location set across a temporary
        // disconnect. Enable() clears it when intentionally connecting to a
        // different session; retaining it here prevents duplicate first-talk
        // checks while reconnecting to the same slot.
        syncFrameCounter = 0;
        scoutsRequested = false;
    }
    wasAuthenticated = authenticated;

    // Detect a local living -> dead transition exactly once. An incoming DeathLink
    // sets suppressNextDeathLinkSend so it cannot echo back into the link group.
    if (gPlayState == nullptr) {
        deathStateInitialized = false;
    } else {
        const bool alive = gSaveContext.health > 0;
        if (!deathStateInitialized) {
            lastPlayerAlive = alive;
            deathStateInitialized = true;
        } else {
            if (lastPlayerAlive && !alive) {
                if (suppressNextDeathLinkSend) {
                    suppressNextDeathLinkSend = false;
                } else {
                    SendDeathLink();
                }
            }
            if (alive) suppressNextDeathLinkSend = false;
            lastPlayerAlive = alive;
        }
    }

    UpdateGoal();

}

void ArchipelagoClient::SyncCollectedLocations() {
    if (!IsAuthenticated() || !IsGameplaySessionActive()) return;

    auto ctx = Rando::Context::GetInstance();
    if (!ctx) return;

    if (!activeLocationsLoaded) return;

    // Reconcile missed/already-saved checks in small batches. Fresh checks use the
    // next-frame gDeferredLocationReports queue above, so this path is primarily for
    // reload/reconnect recovery and never needs to flood the websocket.
    constexpr size_t kMaxLocationReportsPerPass = 8;
    size_t sentThisPass = 0;
    for (const auto& [rcValue, apLocation] : rcToApLocation) {
        if (activeLocations.find(apLocation) == activeLocations.end()) continue;
        if (reportedLocations.find(apLocation) != reportedLocations.end()) continue;

        auto* location = ctx->GetItemLocation(static_cast<RandomizerCheck>(rcValue));
        if (location != nullptr && location->HasObtained()) {
            SendLocation(apLocation);
            if (++sentThisPass >= kMaxLocationReportsPerPass) {
                break;
            }
        }
    }
}


bool ArchipelagoClient::OwnsCheck(int32_t randomizerCheck) {
    if (!currentSaveIsArchipelago || saveIdentityMismatch) return false;

    const int64_t apLocation = ResolveApLocationForCheck(randomizerCheck);
    if (apLocation < 0) return false;

    // Before slot data arrives, stay conservative and prevent the local randomizer from
    // awarding a fake item. Once authenticated slot data is loaded, only actual AP slot
    // locations are owned by Archipelago.
    if (!activeLocationsLoaded) return true;
    return activeLocations.find(apLocation) != activeLocations.end();
}

bool ArchipelagoClient::OwnsCheckCached(int32_t randomizerCheck) const {
    if (!currentSaveIsArchipelago || saveIdentityMismatch) return false;

    auto it = rcToApLocation.find(randomizerCheck);
    if (it == rcToApLocation.end()) {
        return false;
    }

    if (!activeLocationsLoaded) {
        return true;
    }
    return activeLocations.find(it->second) != activeLocations.end();
}

void ArchipelagoClient::ReportCheck(int32_t randomizerCheck) {
    if (!IsGameplaySessionActive()) return;
    const int64_t apLocation = ResolveApLocationForCheck(randomizerCheck);
    if (apLocation < 0) {
        SPDLOG_WARN("[Archipelago] RandomizerCheck {} has no AP location mapping", randomizerCheck);
        return;
    }
    if (activeLocationsLoaded && activeLocations.find(apLocation) == activeLocations.end()) {
        SPDLOG_DEBUG("[Archipelago] RC {} maps to AP location {}, but that location is not active in this slot",
                     randomizerCheck, apLocation);
        return;
    }

    // Do not serialize/send LocationChecks on the exact gameplay collection frame.
    // SyncCollectedLocations() already reconciles obtained native checks roughly
    // once per second and SendLocation() deduplicates them. Keeping this callback
    // lightweight removes the visible freeze while preserving reliable delivery.
    //
    // Remote-item feedback does not require a network round-trip, so keep that
    // immediate using the scout data that is already resident in memory.
    if (reportedLocations.count(apLocation) == 0 && pendingLocationReports.count(apLocation) == 0) {
        QueueRemotePresentation(apLocation);
    }

    if (reportedLocations.find(apLocation) == reportedLocations.end() &&
        std::find(gDeferredLocationReports.begin(), gDeferredLocationReports.end(), apLocation) ==
            gDeferredLocationReports.end()) {
        gDeferredLocationReports.push_back(apLocation);
    }

    SPDLOG_DEBUG("[Archipelago] Deferred checked location {} to next gameplay update", apLocation);
}




static uint64_t Archipelago_NpcSpeechIdentity(const Actor* actor, int16_t sceneNum) {
    if (actor == nullptr) return 0;

    // FNV-1a over immutable spawn identity. home.pos is the actor's spawn position,
    // not the current animated position. Params separates NPC variants sharing a
    // model/actor type.
    uint64_t hash = 1469598103934665603ULL;
    auto mix = [&hash](uint64_t value) {
        for (int i = 0; i < 8; ++i) {
            hash ^= (value >> (i * 8)) & 0xFFULL;
            hash *= 1099511628211ULL;
        }
    };

    mix(static_cast<uint16_t>(sceneNum));
    mix(static_cast<uint16_t>(actor->id));
    mix(static_cast<uint16_t>(actor->params));
    mix(static_cast<uint16_t>(static_cast<int16_t>(actor->home.pos.x)));
    mix(static_cast<uint16_t>(static_cast<int16_t>(actor->home.pos.y)));
    mix(static_cast<uint16_t>(static_cast<int16_t>(actor->home.pos.z)));
    return hash == 0 ? 1 : hash;
}

static bool Archipelago_IsManualSpeechActor(const Actor* actor) {
    if (actor == nullptr || actor->category != ACTORCAT_NPC ||
        (actor->flags & ACTOR_FLAG_TALK_OFFER_AUTO_ACCEPTED)) {
        return false;
    }

    // Keep this list aligned with RegisterShuffleSpeak().  The generic
    // Archipelago speech bank is only for actors the fork itself considers a
    // manual Speak interaction.  Named/native speech checks are resolved before
    // this fallback and are unaffected by this filter.
    switch (actor->id) {
        case ACTOR_EN_DNS:
        case ACTOR_EN_DNT_JIJI:
        case ACTOR_EN_HINTNUTS:
        case ACTOR_EN_KAKASI:
        case ACTOR_EN_KAKASI2:
        case ACTOR_EN_KAKASI3:
        case ACTOR_OBJ_DEKUJR:
        case ACTOR_EN_GE1:
        case ACTOR_EN_GE3:
        case ACTOR_EN_NB:
        case ACTOR_EN_GO:
        case ACTOR_EN_GO2:
        case ACTOR_EN_GM:
        case ACTOR_EN_DU:
        case ACTOR_EN_ANI:
        case ACTOR_EN_BOM_BOWL_MAN:
        case ACTOR_EN_CS:
        case ACTOR_EN_DAIKU:
        case ACTOR_EN_DAIKU_KAKARIKO:
        case ACTOR_EN_DS:
        case ACTOR_EN_FU:
        case ACTOR_EN_GB:
        case ACTOR_EN_GIRLA:
        case ACTOR_EN_GUEST:
        case ACTOR_EN_HEISHI1:
        case ACTOR_EN_HEISHI2:
        case ACTOR_EN_HEISHI3:
        case ACTOR_EN_HEISHI4:
        case ACTOR_EN_HS:
        case ACTOR_EN_HS2:
        case ACTOR_EN_HY:
        case ACTOR_EN_IN:
        case ACTOR_EN_JS:
        case ACTOR_EN_MA1:
        case ACTOR_EN_MA2:
        case ACTOR_EN_MA3:
        case ACTOR_EN_MK:
        case ACTOR_EN_MM:
        case ACTOR_EN_MM2:
        case ACTOR_EN_MS:
        case ACTOR_EN_MU:
        case ACTOR_EN_NIW_GIRL:
        case ACTOR_EN_NIW_LADY:
        case ACTOR_EN_SSH:
        case ACTOR_EN_STH:
        case ACTOR_EN_SYATEKI_MAN:
        case ACTOR_EN_TA:
        case ACTOR_EN_TAKARA_MAN:
        case ACTOR_EN_TG:
        case ACTOR_EN_TK:
        case ACTOR_EN_PO_RELAY:
        case ACTOR_EN_TORYO:
        case ACTOR_EN_XC:
        case ACTOR_EN_ZL1:
        case ACTOR_EN_ZL2:
        case ACTOR_EN_ZL3:
        case ACTOR_EN_ZL4:
        case ACTOR_FISHING:
        case ACTOR_EN_KO:
        case ACTOR_EN_SA:
        case ACTOR_EN_MD:
        case ACTOR_EN_SKJ:
        case ACTOR_EN_DIVING_GAME:
        case ACTOR_EN_KZ:
        case ACTOR_EN_RU1:
        case ACTOR_EN_RU2:
        case ACTOR_EN_ZO:
        case ACTOR_EN_OWL:
            return true;

        case ACTOR_EN_OSSAN:
            switch (actor->params) {
                case OSSAN_TYPE_KOKIRI:
                case OSSAN_TYPE_KAKARIKO_POTION:
                case OSSAN_TYPE_BOMBCHUS:
                case OSSAN_TYPE_MARKET_POTION:
                case OSSAN_TYPE_BAZAAR:
                case OSSAN_TYPE_ADULT:
                case OSSAN_TYPE_TALON:
                case OSSAN_TYPE_INGO:
                case OSSAN_TYPE_MASK:
                case OSSAN_TYPE_GORON:
                case OSSAN_TYPE_ZORA:
                    return true;
                default:
                    return false;
            }

        // ACTOR_EN_GE2 is intentionally excluded, matching ShuffleSpeak, so the
        // player can always ask to be thrown in jail.
        default:
            return false;
    }
}

static bool Archipelago_HasNpcLanguage(int language) {
    if (!RAND_GET_OPTION(RSK_SHUFFLE_SPEAK)) return true;
    static constexpr RandomizerInf flags[] = {
        RAND_INF_CAN_SPEAK_DEKU, RAND_INF_CAN_SPEAK_GERUDO, RAND_INF_CAN_SPEAK_GORON,
        RAND_INF_CAN_SPEAK_HYLIAN, RAND_INF_CAN_SPEAK_KOKIRI, RAND_INF_CAN_SPEAK_ZORA,
    };
    if (language >= 0 && language < 6) return Flags_GetRandomizerInf(flags[language]);
    // Reserved for catalogue entries explicitly marked as language "Any".
    // Kaepora uses the Hylian entry, matching ShuffleSpeak.
    for (const auto flag : flags) if (Flags_GetRandomizerInf(flag)) return true;
    return false;
}

static int64_t Archipelago_ResolveScrubConversation(const Actor* actor, int16_t scene) {
    if (actor == nullptr || actor->id != ACTOR_EN_DNS || OTRGlobals::Instance->gRandomizer == nullptr) return -1;
    int params = actor->params == 6 ? 3 : actor->params;
    if (scene == SCENE_GROTTOS) {
        params = TWO_ACTOR_PARAMS(params, gSaveContext.respawn[RESPAWN_MODE_RETURN].data & 0xFF);
    }
    const auto* location = OTRGlobals::Instance->gRandomizer->GetCheckObjectFromActor(ACTOR_EN_DNS, scene, params);
    if (location == nullptr) return -1;
    struct Entry { RandomizerCheck rc; int64_t location; };
    static const Entry entries[] = {
#include "NpcSpeechScrubs.inc"
    };
    for (const auto& e : entries) if (e.rc == location->GetRandomizerCheck()) return e.location;
    return -1;
}

static int64_t Archipelago_ConversationForActor(const Actor* actor) {
    if (gPlayState == nullptr || actor == nullptr) return -1;
    const auto* identity = SohExtreme::ResolveNpcSpeechIdentity(
        actor->id, gPlayState->sceneNum, actor->params, actor->room, LINK_IS_ADULT,
        static_cast<int>(actor->home.pos.x), static_cast<int>(actor->home.pos.y),
        static_cast<int>(actor->home.pos.z));
    return identity != nullptr ? identity->location :
        Archipelago_ResolveScrubConversation(actor, gPlayState->sceneNum);
}

extern "C" bool Archipelago_HasPendingNpcConversation(const Actor* actor) {
    auto& client = ArchipelagoClient::GetInstance();
    if (!client.IsGameplaySessionActive() ||
        !CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return false;
    const auto location = Archipelago_ConversationForActor(actor);
    return location >= 0 && client.IsLocationActive(location) && !client.IsLocationSubmitted(location);
}

static int64_t Archipelago_ResolveNpcSpeechLocation(const Actor* actor, int16_t sceneNum) {
    if (actor == nullptr) return -1;

    struct SpeechMapEntry {
        int32_t rc;
        int64_t apLocation;
    };
    static const SpeechMapEntry speechMap[] = {
#include "ArchipelagoSpeechMap.inc"
    };

    // First pass: exact scene + actor + params. This is preferred because several
    // scenes contain multiple actors of the same type.
    for (const auto& entry : speechMap) {
        auto* data = Rando::StaticData::GetLocation(static_cast<RandomizerCheck>(entry.rc));
        if (data == nullptr) continue;
        if (static_cast<int16_t>(data->GetScene()) == sceneNum &&
            static_cast<int16_t>(data->GetActorID()) == actor->id &&
            data->GetActorParams() == actor->params) {
            return entry.apLocation;
        }
    }

    // Dialogue-backed checks frequently transform their actor params at runtime.
    // If scene+actor identifies exactly ONE speech check, use it even when params
    // no longer match the spawn-table value.
    int64_t unique = -1;
    for (const auto& entry : speechMap) {
        auto* data = Rando::StaticData::GetLocation(static_cast<RandomizerCheck>(entry.rc));
        if (data == nullptr) continue;
        if (static_cast<int16_t>(data->GetScene()) == sceneNum &&
            static_cast<int16_t>(data->GetActorID()) == actor->id) {
            if (unique != -1 && unique != entry.apLocation) {
                unique = -2; // ambiguous: do not award the wrong NPC
                break;
            }
            unique = entry.apLocation;
        }
    }
    return unique >= 0 ? unique : -1;
}


bool ArchipelagoClient::ShouldHighlightNpcSpeech(const Actor* actor) const {
    if (!IsGameplaySessionActive() || gPlayState == nullptr || actor == nullptr ||
        actor->init != nullptr || actor->draw == nullptr || actor->update == nullptr ||
        !RAND_GET_OPTION(RSK_NPC_SPEECH_SANITY) ||
        !CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return false;
    if (RAND_GET_OPTION(RSK_SHUFFLE_NPC_SOUL) && !Flags_GetRandomizerInf(RAND_INF_NPC_SOUL) &&
        !MegaSoul_IsPathBlockingNpc(actor)) return false;

    // The same immutable character identity as the first-talk hooks, including
    // moving NPCs, age variants, shopkeepers and the exact grotto scrub.
    const int64_t conversation = Archipelago_ConversationForActor(actor);
    if (conversation >= 0 && IsLocationActive(conversation)) {
        // Pending includes the local outbox, so the glow ends on collection
        // even offline or before the server acknowledges this conversation.
        return !IsLocationSubmitted(conversation);
    }

    // Old seeds used reward-based speech IDs and a persistent generic bank.
    // Keep this bounded and read-only: no name lookup, scout request, actor
    // cache, or assignment of a fallback check is performed during drawing.
    if (!IsLocationActive(AP_EXTREME_SPEECH_FALLBACK_BASE) || !Archipelago_IsManualSpeechActor(actor)) return false;
    const auto rando = OTRGlobals::Instance->gRandomizer;
    if (rando != nullptr) {
        auto* location = rando->GetCheckObjectFromActor(actor->id, gPlayState->sceneNum, actor->params);
        if (location == nullptr || location->GetRandomizerCheck() == RC_UNKNOWN_CHECK) {
            location = rando->GetCheckObjectFromActor(actor->id, gPlayState->sceneNum, actor->textId);
        }
        if (location != nullptr && location->GetRandomizerCheck() != RC_UNKNOWN_CHECK) {
            const auto base = rcToApLocation.find(static_cast<int32_t>(location->GetRandomizerCheck()));
            if (base != rcToApLocation.end()) {
                const int64_t candidate = AP_EXTREME_SPEECH_BASE + base->second;
                if (IsLocationActive(candidate)) return !IsLocationSubmitted(candidate);
                if (IsLocationSubmitted(candidate)) return false;
            }
        }
    }
    const int64_t legacy = Archipelago_ResolveNpcSpeechLocation(actor, gPlayState->sceneNum);
    if (legacy >= 0 && IsLocationActive(legacy)) return !IsLocationSubmitted(legacy);
    if (legacy >= 0 && IsLocationSubmitted(legacy)) return false;
    const uint64_t identity = Archipelago_NpcSpeechIdentity(actor, gPlayState->sceneNum);
    if (identity == 0 || fallbackNpcSpeechSeen.find(identity) != fallbackNpcSpeechSeen.end()) return false;
    for (int64_t i = 0; i < AP_EXTREME_SPEECH_FALLBACK_COUNT; ++i) {
        const int64_t candidate = AP_EXTREME_SPEECH_FALLBACK_BASE + i;
        if (IsLocationActive(candidate) && !IsLocationSubmitted(candidate)) return true;
    }
    return false;
}

extern "C" bool Archipelago_ShouldHighlightNpcSpeech(const Actor* actor) {
    return ArchipelagoClient::GetInstance().ShouldHighlightNpcSpeech(actor);
}

void ArchipelagoClient::LoadFallbackNpcSpeechHashes(const std::vector<uint64_t>& hashes) {
    fallbackNpcSpeechHashes = hashes;
    fallbackNpcSpeechSeen.clear();
    for (uint64_t hash : fallbackNpcSpeechHashes) {
        if (hash != 0) fallbackNpcSpeechSeen.insert(hash);
    }
    SPDLOG_INFO("[Archipelago] Loaded {} generic NPC first-talk identities", fallbackNpcSpeechHashes.size());
}

std::vector<uint64_t> ArchipelagoClient::GetFallbackNpcSpeechHashes() const {
    return fallbackNpcSpeechHashes;
}

bool ArchipelagoClient::ReportFallbackNpcSpeech(const Actor* actor) {
    if (!IsGameplaySessionActive() || actor == nullptr) return false;
    if (!CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return false;
    if (!Archipelago_IsManualSpeechActor(actor)) return false;

    const uint64_t identity = Archipelago_NpcSpeechIdentity(actor, static_cast<int16_t>(gPlayState->sceneNum));
    if (identity == 0 || fallbackNpcSpeechSeen.find(identity) != fallbackNpcSpeechSeen.end()) {
        return false;
    }

    // Use exactly one still-unchecked generic AP location for this persisted
    // manual-talk identity. 0.7.47 makes this bank part of normal AP fill; the
    // APWorld applies Speak/NPC Soul/Flow-of-Time safety gates to the bank.
    int64_t speechLocation = -1;
    for (int64_t i = 0; i < AP_EXTREME_SPEECH_FALLBACK_COUNT; ++i) {
        const int64_t candidate = AP_EXTREME_SPEECH_FALLBACK_BASE + i;
        if (activeLocations.find(candidate) != activeLocations.end() &&
            !IsLocationSubmitted(candidate)) {
            speechLocation = candidate;
            break;
        }
    }

    if (speechLocation < 0) {
        SPDLOG_WARN("[Archipelago] Generic NPC Speech fallback bank exhausted; scene={} actor={} params={}",
                    gPlayState->sceneNum, actor->id, actor->params);
        return false;
    }

    if (!ReportNpcSpeechLocation(speechLocation)) {
        return false;
    }

    fallbackNpcSpeechSeen.insert(identity);
    fallbackNpcSpeechHashes.push_back(identity);
    SPDLOG_INFO("[Archipelago] Generic NPC first-talk mapped to fallback location {} "
                "(scene={} actor={} params={} home=({}, {}, {}))",
                speechLocation, gPlayState->sceneNum, actor->id, actor->params,
                actor->home.pos.x, actor->home.pos.y, actor->home.pos.z);
    return true;
}

void ArchipelagoClient::ReportNpcSpeech(int32_t randomizerCheck) {
    if (!IsGameplaySessionActive()) return;
    if (!CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return;

    const int64_t baseLocation = ResolveApLocationForCheck(randomizerCheck);
    if (baseLocation < 0) return;
    ReportNpcSpeechLocation(AP_EXTREME_SPEECH_BASE + baseLocation);
}

bool ArchipelagoClient::ReportNpcSpeechLocation(int64_t speechLocation) {
    if (!IsGameplaySessionActive()) return false;
    if (!CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return false;
    if (!activeLocationsLoaded || activeLocations.find(speechLocation) == activeLocations.end()) return false;

    // This is the critical "first interaction" test. reportedLocations is also
    // rebuilt from Archipelago's checked-locations callback after reconnect/load,
    // so an NPC already checked on the server immediately goes back to normal dialog.
    if (IsLocationSubmitted(speechLocation)) return false;

    auto scoutIt = scoutedLocations.find(speechLocation);
    const std::string speechName =
        scoutIt != scoutedLocations.end() ? scoutIt->second.locationName : "NPC Speech";

    // Reserve the check locally before waiting for the network acknowledgment.
    // The saved outbox retries even if the connection drops on this interaction.
    SendLocation(speechLocation, true);

    if (!IsLocationSubmitted(speechLocation)) {
        // Authentication/session changed between the tests above and SendLocation.
        return false;
    }

    Notification::Emit({
        .prefix = "Archipelago",
        .message = "checked",
        .suffix = speechName,
        .remainingTime = 4.0f,
    });
    SPDLOG_INFO("[Archipelago] NPC Speech Sanity first-talk intercepted: {}", speechLocation);
    // NPC Speech is a distinct AP-only tracker row.  Queue one deferred finder
    // refresh so its checked/available totals update without hijacking the native
    // reward check that shares the same physical interaction anchor.
    CheckTracker::RecalculateAvailableChecks();
    return true;
}

bool ArchipelagoClient::HasSceneTransitionChecks() const {
    return currentSaveIsArchipelago && CVarGetInteger(CVAR_RANDOMIZER_SETTING("SceneTransitionChecks"), 0) != 0;
}

void ArchipelagoClient::ReportTransition(int64_t location) {
    if (!location || !HasSceneTransitionChecks() || !IsGameplaySessionActive() ||
        !IsLocationActive(location) || IsLocationSubmitted(location)) return;
    // The existing saved outbox supplies deduplication and reconnect retry.
    // Item presentations still wait for GameplayDeliverySafety after the fade.
    SendLocation(location, true);
    if (IsLocationSubmitted(location)) CheckTracker::RecalculateAvailableChecks();
}

void ArchipelagoClient::CaptureSceneTransition() {
    AdvanceDoorTransition();
    SohExtreme::EntranceRuntime::CaptureSceneDeparture();
    if (!HasSceneTransitionChecks() || !IsGameplaySessionActive() || !gPlayState ||
        gSaveContext.health <= 0 || gPlayState->gameOverCtx.state != GAMEOVER_INACTIVE ||
        gSaveContext.gameMode != GAMEMODE_NORMAL) {
        gCrossingJournal.Reset();
        if (const auto* source=SohExtreme::EntranceRuntime::crossingSource;
            source && SohExtreme::FindWarpSongCrossing(source->id)) {
            SohExtreme::EntranceRuntime::crossingSource=SohExtreme::EntranceRuntime::crossingTarget=nullptr;
        }
        return;
    }
    if (SohExtreme::EntranceRuntime::suppressTransitionChecks) {
        gCrossingJournal.Reset();
        return;
    }
    // Normal and skipped song animations both use respawnFlag=-3. Keep the
    // actual departure identity instead of broadly allowing that respawn flag
    // to match ordinary scene portals or warp-pad spawn/save destinations.
    const auto* warp=gCrossingJournal.CaptureWarpSong(gPlayState->sceneNum,gPlayState->nextEntranceIndex,
        gSaveContext.respawnFlag,gSaveContext.fileNum,LINK_IS_CHILD);
    if (const auto* source=SohExtreme::EntranceRuntime::crossingSource) {
        // Mapped warps credit the original song, never the destination doorway.
        // A save/void path that happens to resolve that index is not a song.
        if (SohExtreme::FindWarpSongCrossing(source->id) && (!warp || warp->location!=source->check)) {
            SohExtreme::EntranceRuntime::crossingSource=SohExtreme::EntranceRuntime::crossingTarget=nullptr;
        }
        gCrossingJournal.Reset();
        return;
    }
    if (warp) return;
    const auto& back=gSaveContext.respawn[RESPAWN_MODE_RETURN];
    const int returnScene=back.entranceIndex>=0 && back.entranceIndex<ENTR_MAX
        ? gEntranceTable[back.entranceIndex].scene : -1;
    const auto* crossing=SohExtreme::FindSceneCrossing(gPlayState->sceneNum,
        gPlayState->nextEntranceIndex,gSaveContext.respawnFlag,back.data,returnScene);
    gCrossingJournal.BeginScene(crossing && IsLocationActive(crossing->location) ? crossing : nullptr);
}

void ArchipelagoClient::CompleteSceneTransition(int16_t scene) {
    const bool recovery = SohExtreme::EntranceRuntime::suppressTransitionChecks;
    const int64_t entranceCheck = SohExtreme::EntranceRuntime::Complete(scene);
    if (recovery) {
        // Save/death/water recovery did not cross a physical doorway. Suppress
        // both AP routing and the ordinary scene journal for this transition.
        gCrossingJournal.Reset();
        return;
    }
    ReportTransition(entranceCheck);
    ReportTransition(gCrossingJournal.Arrive(scene,gSaveContext.fileNum,LINK_IS_CHILD));
}

void ArchipelagoClient::BeginDoorTransition(int door, int fromRoom, int toRoom, const Actor* actor, int side) {
    SohExtreme::EntranceRuntime::BeginDoor(door, fromRoom, toRoom, actor, side);
    if (SohExtreme::EntranceRuntime::openedDoor) { gCrossingJournal.Reset(); return; }
    if (!HasSceneTransitionChecks() || !IsGameplaySessionActive() || !actor || !gPlayState) return;
    const auto* crossing=SohExtreme::FindDoorCrossing(gPlayState->sceneNum,door,fromRoom,toRoom,
                                                    actor->world.pos.x,actor->world.pos.z,side);
    const Player* player=GET_PLAYER(gPlayState);
    if (!player) return;
    gCrossingJournal.BeginDoor(crossing && IsLocationActive(crossing->location) ? crossing : nullptr,
        player->actor.world.pos.x,player->actor.world.pos.z,
        Math_SinS(actor->shape.rot.y),Math_CosS(actor->shape.rot.y));
}

void ArchipelagoClient::AdvanceDoorTransition() {
    SohExtreme::EntranceRuntime::AdvanceDoor();
    if (!IsGameplaySessionActive() || !gPlayState) { gCrossingJournal.Reset(); return; }
    if (gPlayState->transitionTrigger==TRANS_TRIGGER_OFF) gCrossingJournal.CancelPendingWarpSong();
    const Player* player=GET_PLAYER(gPlayState);
    if (!player) return;
    ReportTransition(gCrossingJournal.AdvanceDoor(gPlayState->sceneNum,gPlayState->roomCtx.curRoom.num,
        player->actor.world.pos.x,player->actor.world.pos.z,
        gSaveContext.health>0 && gPlayState->gameOverCtx.state==GAMEOVER_INACTIVE));
}

void ArchipelagoClient::SendLocation(int64_t locationId, bool notifyRemote) {
    if (!IsGameplaySessionActive()) return;
    if (!activeLocationsLoaded) return;
    if (activeLocations.find(locationId) == activeLocations.end()) {
        SPDLOG_WARN("[Archipelago] Refusing to send inactive/invalid AP location {}", locationId);
        return;
    }

    // reportedLocations means SERVER-CONFIRMED only. Never mark a location reported
    // merely because we attempted to send it: a websocket disconnect between here and
    // APCpp would otherwise permanently eat the check and reconciliation would skip it.
    if (reportedLocations.find(locationId) != reportedLocations.end()) return;

    // Keep only one outstanding attempt for a location. It remains pending until
    // AP's checked-location callback confirms the LocationChecks packet.
    if (!pendingLocationReports.insert(locationId).second) return;

    // A remote item is never received back through our ReceivedItems callback, so
    // the player needs feedback at the moment this location is checked.  Use the
    // scout record we already loaded for the physical placement.  Reconciliation
    // calls SendLocation() with notifyRemote=false, preventing old checks from
    // spamming notifications after reconnect/load.
    if (notifyRemote) QueueRemotePresentation(locationId);

    SPDLOG_INFO("[Archipelago] Sending checked location {} (awaiting server confirmation)", locationId);
    if (IsAuthenticated()) AP_SendItem(locationId);
}

void ArchipelagoClient::RegisterHooks() {
    // Legacy fallback only.  Standalone SOH-EXTREME publishes the exact active
    // location namespace in slot data and ResolveApLocationForCheck prefers it.
    rcToApLocation = {
#include "ArchipelagoLocationMap.inc"
    };
    apLocationToRc.clear();
    for (const auto& [rc, apLocation] : rcToApLocation) {
        apLocationToRc[apLocation] = rc;
    }
    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnGameFrameUpdate>([]() {
        ArchipelagoClient::GetInstance().Update();
    });
    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnPlayerUpdate>([]() {
        ArchipelagoClient::GetInstance().AdvanceDoorTransition();
        ArchipelagoClient::GetInstance().ReofferPendingPresentation();
    });

    // Resolve/apply only the scene being entered. Actor/model hooks can still call
    // RefreshPlacementForCheck() individually, but this warms the whole scene in
    // one small batch before normal gameplay starts.
    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnSceneInit>([](int16_t sceneNum) {
        auto& client = ArchipelagoClient::GetInstance();
        client.CompleteSceneTransition(sceneNum);
        if (client.IsGameplaySessionActive() && client.IsCurrentSaveArchipelago()) {
            client.RefreshPlacementsForScene(sceneNum);
        }
    });

    // A major AP item is durable only after SoH has actually executed its item-give
    // path. This hook closes that transaction and immediately saves both inventory
    // and the per-save AP receive cursor.
    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnItemReceive>([](GetItemEntry itemEntry) {
        auto& client = ArchipelagoClient::GetInstance();
        if (client.remotePresentationActive && itemEntry.modIndex == MOD_RANDOMIZER &&
            itemEntry.getItemId == RG_AP_REMOTE_IMPORTANT) {
            client.remotePresentationReceived = true;
            return;
        }
        client.FinalizeMajorItemReceipt(
            static_cast<int>(itemEntry.modIndex), static_cast<int>(itemEntry.itemId),
            static_cast<int>(itemEntry.getItemId));
    });

    // Some real conversations (including the Skull Kid duet) are started by
    // the NPC script instead of Player_ActionHandler_Talk. Observe the actual
    // opening textbox as well; queued/server-confirmed IDs deduplicate both paths.
    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnDialogMessage>([]() {
        if (gPlayState == nullptr || gPlayState->msgCtx.msgMode != MSGMODE_TEXT_START ||
            gPlayState->msgCtx.talkActor == nullptr ||
            !ArchipelagoClient::GetInstance().IsGameplaySessionActive()) return;
        Actor* actor = gPlayState->msgCtx.talkActor;
        // An actor can destroy itself after opening a textbox. Never dereference
        // a stale message pointer; only inspect actors still owned by the scene.
        bool live = false;
        for (int category = 0; category < ACTORCAT_MAX && !live; ++category) {
            for (Actor* candidate = gPlayState->actorCtx.actorLists[category].head;
                 candidate != nullptr; candidate = candidate->next) {
                if (candidate == actor) { live = true; break; }
            }
        }
        if (!live || (actor->naviEnemyId != 0xFF &&
            gPlayState->msgCtx.textId == actor->naviEnemyId + 0x600)) return;
        // The game has already begun this conversation. Do not reject a forced
        // introduction after it happened just because it bypassed manual Speak.
        ArchipelagoClient::GetInstance().ReportNpcSpeechLocation(Archipelago_ConversationForActor(actor));
    });

    // First conversation with a real NPC = one persistent AP location. Later
    // conversations retain their normal behavior, including while offline or
    // while the first check is awaiting server acknowledgment.
    COND_VB_SHOULD(VB_SKIP_TALKING, true, {
        Actor* actor = va_arg(args, Actor*);
        auto& client = ArchipelagoClient::GetInstance();
        if (!*should || gPlayState == nullptr || actor == nullptr ||
            !client.IsGameplaySessionActive() ||
            !CVarGetInteger(CVAR_RANDOMIZER_SETTING("NpcSpeechSanity"), 0)) return;
        // C-Up enemy information is Navi's dialogue, not an NPC conversation.
        if (actor->naviEnemyId != 0xFF && actor->textId == actor->naviEnemyId + 0x600) return;
        if (RAND_GET_OPTION(RSK_SHUFFLE_NPC_SOUL) && !Flags_GetRandomizerInf(RAND_INF_NPC_SOUL) &&
            !MegaSoul_IsPathBlockingNpc(actor)) return;
        const auto* identity = SohExtreme::ResolveNpcSpeechIdentity(
            actor->id, gPlayState->sceneNum, actor->params, actor->room, LINK_IS_ADULT,
            static_cast<int>(actor->home.pos.x), static_cast<int>(actor->home.pos.y),
            static_cast<int>(actor->home.pos.z));
        const int64_t conversation = identity != nullptr ? identity->location :
            Archipelago_ResolveScrubConversation(actor, gPlayState->sceneNum);
        if (conversation >= 0 && client.IsLocationActive(conversation)) {
            if (!Archipelago_HasNpcLanguage(identity != nullptr ? identity->language : 0)) return;
            const bool checked = client.ReportNpcSpeechLocation(conversation);
            // Scripted/automatic dialogue must run its actor state machine. It
            // still checks once; receipt presentation waits until Link is free.
            if (checked && !(actor->flags & ACTOR_FLAG_TALK_OFFER_AUTO_ACCEPTED)) *should = false;
            return; // Also return for pending/checked identities: never take another NPC's item.
        }
        // Compatibility with seeds generated before identity version 2. These
        // checks keep their original reward-based meanings and server IDs.
        if (actor->flags & ACTOR_FLAG_TALK_OFFER_AUTO_ACCEPTED) return;
        if (!Archipelago_HasNpcLanguage(identity != nullptr ? identity->language : 6)) return;
        int64_t speechLocation = -1;

        auto rando = OTRGlobals::Instance->gRandomizer;
        if (rando != nullptr) {
            Rando::Location* location =
                rando->GetCheckObjectFromActor(actor->id, gPlayState->sceneNum, actor->params);
            if (location == nullptr || location->GetRandomizerCheck() == RC_UNKNOWN_CHECK) {
                location = rando->GetCheckObjectFromActor(actor->id, gPlayState->sceneNum, actor->textId);
            }

            if (location != nullptr && location->GetRandomizerCheck() != RC_UNKNOWN_CHECK) {
                const int64_t baseLocation =
                    ArchipelagoClient::GetInstance().ResolveApLocationForCheck(
                        static_cast<int32_t>(location->GetRandomizerCheck()));
                if (baseLocation >= 0) {
                    const int64_t candidate = AP_EXTREME_SPEECH_BASE + baseLocation;
                    if (ArchipelagoClient::GetInstance().ReportNpcSpeechLocation(candidate)) {
                        *should = false;
                        return;
                    }
                    // Already checked mapped NPC -> normal dialogue.
                    if (client.IsLocationSubmitted(candidate)) {
                        return;
                    }
                }
            }
        }

        if (speechLocation < 0) {
            speechLocation =
                Archipelago_ResolveNpcSpeechLocation(actor, static_cast<int16_t>(gPlayState->sceneNum));
        }
        if (speechLocation >= 0) {
            if (ArchipelagoClient::GetInstance().ReportNpcSpeechLocation(speechLocation)) {
                *should = false;
                return;
            }
            if (client.IsLocationSubmitted(speechLocation)) {
                return;
            }
        }

        // No native speech location exists for this NPC (for example ordinary
        // Kokiri/Market flavor NPCs). Only true manual-Speak actors are eligible
        // for the persistent generic first-talk bank.
        if (client.IsLocationActive(AP_EXTREME_SPEECH_FALLBACK_BASE) &&
            Archipelago_IsManualSpeechActor(actor) &&
            ArchipelagoClient::GetInstance().ReportFallbackNpcSpeech(actor)) {
            *should = false;
        }
    });

    GameInteractor::Instance->RegisterGameHook<GameInteractor::OnRandoSetCheckStatus>(
        [](RandomizerCheck rc, RandomizerCheckStatus status) {
            // RCSHOW_SAVED is also an obtained check. This matters when loading a file:
            // those checks may never transition through RCSHOW_COLLECTED this session.
            if (status != RCSHOW_COLLECTED && status != RCSHOW_SAVED) return;

            auto& apClient = ArchipelagoClient::GetInstance();

            if (status == RCSHOW_COLLECTED) {
                apClient.ReportCheck(static_cast<int32_t>(rc));
            } else {
                // RCSHOW_SAVED is emitted in bulk while a file is loading. Sending
                // LocationChecks synchronously here bypassed all reconciliation batching
                // and could issue hundreds of websocket sends during Save_LoadFile().
                // SyncCollectedLocations() handles these saved checks safely afterward.
                SPDLOG_DEBUG("[Archipelago] Loaded saved check {}; deferred to batched reconciliation",
                             static_cast<int32_t>(rc));
            }

            // UpdateGoal reports completion from the active gameplay save and
            // retries once per authentication, including already-completed saves.

        });
}

static void InitArchipelagoClient() {
    SPDLOG_INFO("[Archipelago] SOH-EXTREME runtime {} loaded (built {} {})",
                SohExtreme::kTrackerVersion, __DATE__, __TIME__);
    auto& client = ArchipelagoClient::GetInstance();
    client.RegisterHooks();
    if (CVarGetInteger(CVAR_REMOTE_ARCHIPELAGO("Enabled"), 0)) {
        client.Enable();
    }
}

static RegisterShipInitFunc initArchipelagoClient(InitArchipelagoClient);


extern "C" bool Archipelago_IsAuthenticatedForFileSelect(void) {
    auto& client = ArchipelagoClient::GetInstance();
    if (!client.IsAuthenticated()) return false;
    client.BeginFileSelectActivation();

    // Starting an AP file is now a synchronization barrier, not merely an auth check.
    // Do not enter name-entry/create the save until settings, active locations, exact
    // shop prices, and all physical AP placements have arrived.
    client.EnsureLocationScouts();
    return client.IsReadyForFileSelect();
}

extern "C" bool Archipelago_IsCurrentSaveFile(void) {
    return ArchipelagoClient::GetInstance().IsCurrentSaveArchipelago();
}

extern "C" int32_t Archipelago_AdjustAmmoChange(int32_t item, int32_t currentAmmo, int32_t change) {
    return ArchipelagoClient::GetInstance().AdjustAmmoChange(item, currentAmmo, change);
}

extern "C" void Archipelago_ObserveAmmoSource(int32_t randomizerCheck, int32_t actorId,
                                               int32_t sourceDropParams, int32_t collectibleInput) {
    ArchipelagoClient::GetInstance().ObserveAmmoSource(randomizerCheck, actorId, sourceDropParams, collectibleInput);
}

extern "C" bool Archipelago_ShouldFreezeTime(void) {
    // Physical save rules apply offline too. Only passive clock progression is
    // frozen; the engine must still be able to execute Sun's Song time changes.
    return Archipelago_IsCurrentSaveFile() && gSaveContext.gameMode == GAMEMODE_NORMAL &&
           CVarGetInteger(CVAR_RANDOMIZER_SETTING("ShuffleFlowOfTime"), 0) &&
           !Flags_GetRandomizerInf(RAND_INF_FLOW_OF_TIME);
}

extern "C" bool Archipelago_IsCurrentSaveActive(void) {
    auto& client = ArchipelagoClient::GetInstance();
    return client.IsEnabled() && client.IsCurrentSaveArchipelago();
}

extern "C" bool Archipelago_ShouldHandleCheck(int32_t randomizerCheck) {
    return ArchipelagoClient::GetInstance().OwnsCheck(randomizerCheck);
}

extern "C" bool Archipelago_IsCheckMappedActive(int32_t randomizerCheck) {
    return ArchipelagoClient::GetInstance().OwnsCheckCached(randomizerCheck);
}

extern "C" bool Archipelago_PrepareCheckFinderMappings(void) {
    return ArchipelagoClient::GetInstance().PrepareCheckFinderMappings();
}

extern "C" bool Archipelago_IsLocationActive(int64_t locationId) {
    return ArchipelagoClient::GetInstance().IsLocationActive(locationId);
}

extern "C" bool Archipelago_IsLocationSubmitted(int64_t locationId) {
    return ArchipelagoClient::GetInstance().IsLocationSubmitted(locationId);
}

extern "C" bool Archipelago_IsLocationReported(int64_t locationId) {
    return ArchipelagoClient::GetInstance().IsLocationReported(locationId);
}

extern "C" uint32_t Archipelago_GetActiveLocationCount(void) {
    return static_cast<uint32_t>(ArchipelagoClient::GetInstance().GetActiveLocationCount());
}

extern "C" uint32_t Archipelago_GetReportedActiveLocationCount(void) {
    return static_cast<uint32_t>(ArchipelagoClient::GetInstance().GetReportedActiveLocationCount());
}

extern "C" void Archipelago_RefreshScenePlacements(int16_t sceneNum) {
    ArchipelagoClient::GetInstance().RefreshPlacementsForScene(sceneNum);
}

extern "C" void Archipelago_ReportCheck(int32_t randomizerCheck) {
    ArchipelagoClient::GetInstance().ReportCheck(randomizerCheck);
}

extern "C" void Archipelago_ReportLocation(int64_t locationId) {
    // Physical AP-only pickup, including enemy defeat rewards.
    ArchipelagoClient::GetInstance().SendLocation(locationId, true);
}

extern "C" bool Archipelago_HasSceneTransitionChecks(void) {
    return ArchipelagoClient::GetInstance().HasSceneTransitionChecks();
}
extern "C" void Archipelago_CaptureSceneTransition(void) {
    ArchipelagoClient::GetInstance().CaptureSceneTransition();
}
void ArchipelagoClient::BeginWarpSongTransition(int song) {
    int entrance=-1;
    switch (song) {
        case OCARINA_SONG_MINUET: entrance=ENTR_SACRED_FOREST_MEADOW_WARP_PAD; break;
        case OCARINA_SONG_BOLERO: entrance=ENTR_DEATH_MOUNTAIN_CRATER_WARP_PAD; break;
        case OCARINA_SONG_SERENADE: entrance=ENTR_LAKE_HYLIA_WARP_PAD; break;
        case OCARINA_SONG_REQUIEM: entrance=ENTR_DESERT_COLOSSUS_WARP_PAD; break;
        case OCARINA_SONG_NOCTURNE: entrance=ENTR_GRAVEYARD_WARP_PAD; break;
        case OCARINA_SONG_PRELUDE: entrance=ENTR_TEMPLE_OF_TIME_WARP_PAD; break;
    }
    const auto* crossing=SohExtreme::FindWarpSongCrossing(entrance);
    if (!HasSceneTransitionChecks() || !IsGameplaySessionActive() || !gPlayState ||
        gPlayState->transitionTrigger!=TRANS_TRIGGER_START || gSaveContext.health<=0 ||
        gPlayState->gameOverCtx.state!=GAMEOVER_INACTIVE || gSaveContext.gameMode!=GAMEMODE_NORMAL ||
        SohExtreme::EntranceRuntime::suppressTransitionChecks || !crossing || !IsLocationActive(crossing->location)) {
        gCrossingJournal.CancelPendingWarpSong();
        return;
    }
    gCrossingJournal.ArmWarpSong(crossing,gPlayState->sceneNum,gPlayState->nextEntranceIndex,
        gSaveContext.respawnFlag,gSaveContext.fileNum,LINK_IS_CHILD);
}

extern "C" void Archipelago_BeginWarpSongTransition(int song) {
    ArchipelagoClient::GetInstance().BeginWarpSongTransition(song);
}
extern "C" void Archipelago_BeginDoorTransition(int door, int fromRoom, int toRoom, const Actor* actor, int side) {
    ArchipelagoClient::GetInstance().BeginDoorTransition(door,fromRoom,toRoom,actor,side);
}

extern "C" void Archipelago_ReconcileLocation(int64_t locationId) {
    // Saved journals replay delivery only, never past pickup animations.
    ArchipelagoClient::GetInstance().SendLocation(locationId, false);
}

extern "C" const char* Archipelago_GetRemoteItemDescription(int32_t randomizerCheck) {
    static thread_local std::string description;
    description = ArchipelagoClient::GetInstance().GetRemoteItemDescription(randomizerCheck);
    return description.c_str();
}

extern "C" void Archipelago_RefreshPlacementForCheck(int32_t randomizerCheck) {
    ArchipelagoClient::GetInstance().RefreshPlacementForCheck(randomizerCheck);
}

extern "C" int32_t Archipelago_GetLocationDisplayItem(int64_t locationId) {
    return ArchipelagoClient::GetInstance().GetLocationDisplayItem(locationId);
}

extern "C" void Archipelago_InitSaveFile(void) {
    auto& client = ArchipelagoClient::GetInstance();

    // Keep AP file creation intentionally close to the working normal-randomizer
    // creation path. Only authoritative settings that Randomizer_InitSaveFile()
    // actually needs are applied here. Network/scout/history work is deferred
    // until the first gameplay Update().
    gSaveContext.ship.quest.id = QUEST_RANDOMIZER;
    client.ApplySlotSettings();
    OTRGlobals::Instance->gRandoContext->GetDungeons()->ClearAllMQ();

    // A brand-new AP file must never inherit Triforce progress from the
    // previously loaded file/save-context.  Randomizer_InitSaveFile() does not
    // guarantee this custom counter is cleared on every AP creation path, so
    // zero it on both sides of initialization.  Historical AP ReceivedItems are
    // replayed later and will legitimately rebuild the count for an existing
    // server slot.
    gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected = 0;
    Randomizer_InitSaveFile();
    gSaveContext.ship.quest.data.randomizer.triforcePiecesCollected = 0;
    client.ApplyPostInitSlotState();

    // Choose the frozen phase once. Saved time and explicit Sun's Song changes
    // must survive loading, scene changes and reconnects.
    if (CVarGetInteger(CVAR_RANDOMIZER_SETTING("ShuffleFlowOfTime"), 0)) {
        static constexpr u16 kTimes[] = { 0x4555, 0x8000, 0xB555, 0x0000 };
        int selected = CVarGetInteger(CVAR_RANDOMIZER_SETTING("FrozenStartingTime"), 1);
        if (selected <= 0 || selected > 4) selected = 1;
        gSaveContext.dayTime = kTimes[selected - 1];
        gSaveContext.skyboxTime = gSaveContext.dayTime;
        gSaveContext.nightFlag = selected == 4;
    }

    // SaveManager needs the AP marker/identity on the very first disk write, but
    // rebuilding ReceivedItems here can contend with APCpp callbacks and stall
    // the name-entry transition. Prime metadata only; replay begins in gameplay.
    client.PrimeNewSaveMetadata();

    client.EndFileSelectActivation();
    SPDLOG_INFO("[Archipelago] Initialized new SOH-EXTREME save; AP replay/scout work deferred to gameplay");
}

extern "C" const char* Archipelago_GetRemotePickupDescription(void) {
    return ArchipelagoClient::GetInstance().GetRemotePickupDescription().c_str();
}

extern "C" const char* Archipelago_GetSongNotePickupDescription(void) {
    return ArchipelagoClient::GetInstance().GetSongNotePickupDescription().c_str();
}
