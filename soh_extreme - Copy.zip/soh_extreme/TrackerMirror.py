"""Bounded, read-only UT -> C++ Check Finder transport.

The payload contains evaluated location IDs, not a second set of access rules.
No locations/items are granted or checked by this module. Strings use UTF-8.
"""
from __future__ import annotations
import base64
import struct
from .NpcSpeech import display_region
from typing import Any

PROTOCOL = "SOHExtremeFinder1"
# Release metadata for diagnostics; never require equal releases for display.
# Keep the wire format stable across release bumps; change its identifier only
# when the data layout changes and provide an explicit compatible decoder.
VERSION = "1.8.22"
TAG = "SOHExtremeUT"
MAX_ENTRIES = 20000
MAX_BYTES = 750000
MAGIC = b"SEFT1\0"


def _integer(value: Any, low: int, high: int) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError("Invalid tracker protocol integer")
    return value


def encode_snapshot(*, nonce: str, request: int, revision: int, slot: int,
                    producer: str, received: int, active: set[int], checked: set[int],
                    rows: list[dict], manual_count: int = 0, ignored_count: int = 0,
                    version: str = VERSION, live_shields: int | None = None,
                    live_time: int | None = None, live_clock: int | None = None,
                    live_time_flags: int = 0, live_ammo: int | None = None,
                    live_ammo_owned: int = 0, live_rupees: int = 0,
                    live_ammo_flags: int = 0, live_ammo_state: int = 0,
                    ammo_refills: int = 0) -> str:
    if not nonce or len(nonce) > 64 or not producer or len(producer) > 64:
        raise ValueError("Invalid tracker session identity")
    if len(active) > MAX_ENTRIES or len(rows) > MAX_ENTRIES or not checked <= active:
        raise ValueError("Invalid tracker location manifest")
    out = bytearray(MAGIC)
    def u32(n): out.extend(struct.pack("<I", _integer(n, 0, 0xffffffff)))
    def u64(n): out.extend(struct.pack("<Q", _integer(n, 0, 0xffffffffffffffff)))
    def text(s):
        if not isinstance(s, str) or any(ord(c) < 32 or ord(c) == 127 for c in s):
            raise ValueError("Invalid tracker label")
        b = s.encode("utf-8")
        if len(b) > 2048: raise ValueError("Tracker label too long")
        out.extend(struct.pack("<H",len(b)));out.extend(b)
    text(nonce); text(producer); text(version)
    u32(slot);u64(request);u64(revision);u64(received)
    u32(manual_count);u32(ignored_count)
    u32(0xffffffff if live_shields is None else _integer(live_shields, 0, 3))
    for ids in (active, checked):
        u32(len(ids))
        for i in sorted(ids):u64(_integer(i, 1, 0x7fffffffffffffff))
    u32(len(rows));seen=set()
    for row in rows:
        i=_integer(row['id'],1,0x7fffffffffffffff)
        if i in seen or i not in active or i in checked:
            raise ValueError("Duplicate, inactive, or checked tracker row")
        seen.add(i);u64(i)
        out.append(_integer(row['state'],1,2))
        text(row['name']);text(row['region'])
    # Append only for a client that requested this extension. Older clients
    # continue receiving the original wire layout, independent of release labels.
    if live_time is not None:
        out.extend(b'TIME');u32(_integer(live_time, 0, 1))
    if live_clock is not None:
        if live_time is None:raise ValueError("Clock extension needs a phase")
        out.extend(b'CLCK');u32(_integer(live_clock, 0, 0xffff));u32(_integer(live_time_flags, 0, 1))
    # Explicitly negotiated by the managed client. Older clients keep their
    # original payload and continue to display checks without this extension.
    if live_ammo is not None:
        if live_clock is None:raise ValueError("Ammo extension needs a live clock")
        if live_ammo & ~live_ammo_owned:raise ValueError("Ammo without an owned container")
        out.extend(b'AMMO')
        for value in (live_ammo, live_ammo_owned):u32(_integer(value, 0, 31))
        u32(_integer(live_rupees, 0, 65535));u32(_integer(live_ammo_flags, 0, 3))
        u64(_integer(live_ammo_state, 1, 0xffffffffffffffff))
        u32(_integer(ammo_refills, 0, 31))
    if len(out)>MAX_BYTES:raise ValueError("Tracker snapshot too large")
    return base64.b64encode(out).decode('ascii')


def snapshot_rows(core, tracker_state, world, active: set[int], checked: set[int]) -> list[dict]:
    """Use the exact returned normal/glitched lists displayed by UT.

    UT's returned lists alone decide which checks are shown. Age annotations
    query those same rules using a copy of UT's evaluated inventory/events;
    they do not add/remove checks or change UT's state or filters.
    """
    normal=list(tracker_state.in_logic_locations)
    glitched=list(tracker_state.glitched_locations) if core.enable_glitched_logic else []
    aliases=getattr(core,'location_alias_map',{})
    rows=[];seen=set()
    for status,names in ((1,normal),(2,glitched)):
        state=getattr(tracker_state,'state' if status==1 else 'glitches_state',None)
        age_state=state.copy() if state is not None and names else None
        for name in names:
            loc=world.get_location(name)
            i=loc.address
            if type(i) is not int:
                continue  # Non-network events are not location checks.
            if i not in active or i in checked:
                # Newer APWorlds may define locations not present in an older
                # seed. The live server manifest, not the local source catalog,
                # decides which checks belong to this connection.
                continue
            if i in seen:raise ValueError('UT returned duplicate network check: '+str(name))
            seen.add(i)
            label=getattr(world,"_er_labels",{}).get(i,str(loc.name))
            if i in aliases:label+=' ('+str(aliases[i])+')'
            if age_state is not None and hasattr(loc,'can_reach_as_age') and not hasattr(loc, 'transition_age'):
                # Age-dependent scene checks already carry [Child]/[Adult] in
                # their permanent identity. Don't append the same age twice.
                # Keep transport-only use independent of AP's rule modules.
                from ._vendor_oot_soh.Enums import Ages
                child=loc.can_reach_as_age(age_state,Ages.CHILD)
                adult=loc.can_reach_as_age(age_state,Ages.ADULT)
                if child and adult:label+=' [Any age]'
                elif child:label+=' [Child]'
                elif adult:label+=' [Adult]'
            rows.append({'id':i,'state':status,'name':label,
                         'region':display_region(loc)})
    # Age-dependent scene/room checks are AP-only locations, not stock SoH
    # checks. Some Universal Tracker versions omit these extra numeric locations
    # from their default location enumeration even though their source regions
    # and access rules are fully evaluated in the real CollectionState.  They
    # must still appear in Check Finder when their *physical source* is usable.
    #
    # The server manifest remains authoritative: do not recreate retired
    # checks, and never use a destination's region as proof of source access.
    # Evaluate on a COPY so age switching / region cache invalidation cannot
    # change UT's own inventory or cached frontier.
    probe_state = getattr(tracker_state, 'state', None)
    transition_entries = getattr(world, '_scene_transition_entries', ())
    if probe_state is not None and transition_entries:
        probe_state = probe_state.copy()
        player = world.player
        # The seed's ER mapping is installed after UT constructs its initial
        # CollectionState. Flush both generic and SOH-specific cached regions
        # before checking source locations against the final shuffled graph.
        if hasattr(probe_state, '_soh_extreme_invalidate'):
            probe_state._soh_extreme_invalidate(player)
        if hasattr(probe_state, 'reachable_regions'):
            probe_state.reachable_regions[player] = set()
        if hasattr(probe_state, 'blocked_connections'):
            probe_state.blocked_connections[player] = set()
        if hasattr(probe_state, 'stale'):
            probe_state.stale[player] = True
        for entry in transition_entries:
            check_id = entry['id']
            if check_id not in active or check_id in checked or check_id in seen:
                continue
            location = world.get_location(entry['name'])
            if not location.can_reach(probe_state):
                continue
            seen.add(check_id)
            rows.append({
                'id': check_id, 'state': 1,
                'name': getattr(world, '_er_labels', {}).get(check_id, str(location.name)),
                'region': display_region(location),
            })
    rows.sort(key=lambda r:(r['state'],r['region'],r['name'],r['id']))
    return rows
