"""Authoritative, coupled physical entrance shuffle shared by AP and UT.

Traversal predicates belong to source endpoints. A routed arrival adds its own
physical hazards, never the old source's requirements. Crossing checks retain
source-only credit. One-way routes add exactly one directed edge.
"""
from collections import defaultdict
import logging
from time import monotonic
from importlib.resources import files
import json

from BaseClasses import CollectionState, ItemClassification, Location, LocationProgressType
from Options import OptionError
from rule_builder.rules import True_, And, Has, Or, Rule
from .EntranceOptions import ENTRANCE_OPTIONS
from . import EntranceSafety as Safety
from . import EntranceMapIntegrity as MapIntegrity
from . import EntranceTopologyAudit as TopologyAudit
from .SceneTransitions import region_name
from . import SceneTransitions
from .CheckDescriptions import shuffled_check_label
from ._vendor_oot_soh.Enums import Regions, Items, Events, Ages
from ._vendor_oot_soh.Regions import SohRegion
from ._vendor_oot_soh.Items import SohItem
from ._vendor_oot_soh import LogicHelpers as H
from .EnemyRoomLogic import GRAPH, NativeEnemyRegions, resolve_enemy_region
from .BoulderEntrances import BOULDER_BLOCKED_ENDPOINTS

REVISION = 1
# Revision 1 partitions unmixed room doors by their physical dungeon scene.
# Keep topology revision separate so earlier saved maps can still be restored.
POOL_POLICY_REVISION = 1
RIVER_PATH_REVISION = 1
# These are four physical crossings. Earlier seeds stored only the land pair.
# The aliases below are for restoring those saved destinations, never new pools.
RIVER_WATER_ALIASES = {473: 234, 785: 385}
CATALOG = tuple(json.loads(files(__package__).joinpath('EntranceCatalog.json').read_text()))
Safety.validate_catalog(CATALOG)
ENDPOINTS = {e['id']: e for e in CATALOG}
# These six Jabu doors carry Ruto between her rescue rooms, the corridor,
# the Stinger room and Big Octo. A full shuffled scene load deletes held actors.
# Keep their two directions as explicit identity routes and let the native
# door/check path cross rooms without reloading the scene. Their checks remain
# in the pool. Keep this contract aligned with IsLocalCarrierDoor in C++.
LOCAL_CARRIER_DOORS = frozenset(e['id'] for e in CATALOG
                              if e['source_scene'] == 2 and e['door'] in {2, 4, 11, 12, 14, 21})
KEY_DOORS = {3: ('FOREST_TEMPLE', 5), 4: ('FIRE_TEMPLE', 8), 5: ('WATER_TEMPLE', 6),
             6: ('SPIRIT_TEMPLE', 5), 7: ('SHADOW_TEMPLE', 5), 8: ('BOTTOM_OF_THE_WELL', 3),
             11: ('TRAINING_GROUND', 9), 13: ('GANONS_CASTLE', 2)}
DUNGEON_ROUTES = json.loads(files(__package__).joinpath('DungeonLocationRoutes.json').read_text())
# Reviewed main-water-body arrivals: the lower doors are dry at Low, and the
# middle doors are dry at Low or Mid. Otherwise the landing is submerged.
# Usable Iron Boots include Swim and the actual age requirement. Upper ledges
# and separate basement puzzle ledges must not inherit a scene-wide water gate.
# Physical submerged entrance/exit mouths. Apply Swim to both the source
# crossing (and its scene-transition check) and a shuffled arrival at the
# underwater mouth. This is not a Water Temple-wide condition: dry interior
# doors and checks retain their normal requirements.
WATER_SUBMERGED_ENDPOINTS = frozenset({
    16, 541,        # Lake Hylia <-> Water Temple entrance, underwater
    477, 1242,      # Lost Woods <-> Zora's River submerged tunnel
    808, 1376,      # Lake Hylia <-> Zora's Domain submerged shortcut
    473, 785,       # Hyrule Field <-> Zora's River water path
})

WATER_ARRIVAL_LEVELS = {
    8860: 'WL_LOW', 8861: 'WL_LOW',
    8878: 'WL_LOW', 8879: 'WL_LOW',
    8862: 'WL_LOW_OR_MID', 8863: 'WL_LOW_OR_MID',
    8866: 'WL_LOW_OR_MID', 8867: 'WL_LOW_OR_MID',
}
CATEGORIES = {
    'overworld': 'shuffle_overworld_entrances',
    'interiors': 'shuffle_interior_entrances',
    'dungeons': 'shuffle_dungeon_entrances',
    'grottos': 'shuffle_grotto_entrances',
    'bosses': 'shuffle_boss_entrances',
    'one_ways': 'shuffle_one_way_entrances',
    'owls': 'shuffle_owl_drops',
    'warp_songs': 'shuffle_warp_songs',
    'child_spawn': 'shuffle_child_spawn',
    'adult_spawn': 'shuffle_adult_spawn',
    'dungeon_doors': 'shuffle_dungeon_doors',
}


def enabled(world):
    return any(getattr(world.options, option).value for option in CATEGORIES.values())


def enabled_categories(world):
    return {key for key, option in CATEGORIES.items() if getattr(world.options, option).value}


# Stable bits exported with the slot's native settings. Append future categories
# instead of reordering these; old saves retain their exact metadata.
MIXED_CATEGORY_BITS = {name: 1 << bit for bit, name in enumerate((
    'overworld', 'interiors', 'dungeons', 'grottos', 'bosses', 'one_ways',
    'owls', 'warp_songs', 'child_spawn', 'adult_spawn', 'dungeon_doors',
))}
DUNGEON_CATEGORIES = frozenset({'dungeons', 'bosses', 'dungeon_doors'})


def mixed_categories(world):
    """Return the enabled categories selected to mix; 'all' enables no shuffle."""
    selected = set(world.options.mixed_entrance_pools.value)
    enabled = enabled_categories(world)
    return enabled if 'all' in selected else selected & enabled


def dungeon_doors_are_mixed(world):
    mixed = mixed_categories(world)
    return 'dungeon_doors' in mixed and len(mixed) > 1


def dungeon_doors_mix_outside(world):
    mixed = mixed_categories(world)
    return 'dungeon_doors' in mixed and bool(mixed - DUNGEON_CATEGORIES)


def _paired_pool_key(row, mixed):
    # Selecting only room doors has no second category to mix with. Those doors
    # keep the same per-dungeon behavior as an empty mixed-pool selection.
    if row['category'] == 'dungeon_doors' and not ('dungeon_doors' in mixed and len(mixed) > 1):
        return ('dungeon_doors', row['source_scene'])
    return 'mixed' if row['category'] in mixed else row['category']


def _pool_policy_revision(world):
    if world.using_ut:
        return world.passthrough.get('entrance_randomizer', {}).get('pool_policy_revision', 0)
    return POOL_POLICY_REVISION


def _river_path_revision(world):
    if not world.using_ut:
        return RIVER_PATH_REVISION
    saved = world.passthrough.get('entrance_randomizer', {})
    revision = saved.get('river_path_revision')
    if revision is None:
        # Permit maps assembled by older tools that already carry explicit
        # water IDs; truly old server maps have neither water endpoint.
        connections = saved.get('connections', {})
        revision = int(any(str(endpoint) in connections or endpoint in connections
                           for endpoint in RIVER_WATER_ALIASES)
                       or any(target in RIVER_WATER_ALIASES for target in connections.values()))
    if type(revision) is not int or revision not in (0, RIVER_PATH_REVISION):
        raise OptionError("Unsupported Zora's River entrance policy")
    return revision


def _routed_destination(world, mapping, source):
    if source not in mapping and source in RIVER_WATER_ALIASES and _river_path_revision(world) == 0:
        return mapping.get(RIVER_WATER_ALIASES[source], source)
    return mapping.get(source, source)


def _changed_route_ids(previous, current):
    """Only rebuild edges whose installed destination changed.

    `previous` describes the *currently installed* graph, not the last
    accepted mapping. Rejected probes also change the live graph temporarily.
    """
    return [source for source, destination in current.items()
            if previous.get(source) != destination]


def _distinct_reachability_probes(locations):
    """Reduce identical required-check reachability tests without changing rules.

    BaseClasses.Location.can_reach only evaluates the parent region and its
    access_rule. Locations sharing *both exact objects* therefore yield the
    same result in one state. Never merge overridden Location.can_reach methods,
    which may implement game-specific checks not represented by these fields.
    """
    seen = set()
    probes = []
    for loc in locations:
        if type(loc).can_reach is Location.can_reach:
            key = (id(loc.parent_region), id(loc.access_rule))
            if key in seen:
                continue
            seen.add(key)
        probes.append(loc)
    return probes


def _requested_goal_reachability(world):
    """Read the user's YAML option without changing the saved configuration."""
    return world.options.entrance_reachability.value == 1


def _is_full_accessibility(world):
    """Full accessibility takes precedence over the entrance-only goal mode.

    Otherwise the entrance randomizer can disconnect hundreds of optional checks
    with complete inventory, which necessarily makes Archipelago's Full setting
    impossible regardless of where the item filler places items.
    """
    return str(getattr(world.options.accessibility, 'current_key', 'full')).lower() == 'full'


def _is_goal_reachability(world):
    """Honor the explicit entrance policy, independently of AP accessibility.

    The earlier Full-accessibility override rejected almost every mixed-pool
    candidate by demanding that all stock rooms remain reachable *during each
    intermediate swap*.  Goal Reachable is an explicit request to permit
    optional disconnected destinations, even when AP accessibility is Full.
    In that combination, structurally inaccessible optional checks are retired
    before fill; all surviving checks still use the normal AP Full fill rules.
    All Destinations remains the strict mode whenever the user selects it.
    """
    return _requested_goal_reachability(world)


def _reachable_stock_destinations(world, rows, baseline):
    """Deduplicate the entrance destinations reachable with all stock items.

    Some disabled/unused native exits are unreachable even in an unshuffled
    world; those cannot be required in every seed. The strict setting preserves
    every initially reachable destination region, plus the existing baseline
    item-location probes. The goal setting deliberately skips both tests.
    """
    seen = set()
    result = []
    for row in rows:
        target_name = region_name(row['target'])
        if target_name in seen:
            continue
        seen.add(target_name)
        target = world.get_region(target_name)
        if target.can_reach(baseline):
            result.append(target)
    return result


def _entrance_objective_met(world, state, goal_only, required_checks, required_destinations):
    """The expensive mode-dependent component of an entrance safety check.

    Always use the SOH player's completion goal, never every other game's goal.
    Entry/age/start/return validation belongs to the caller in both modes.
    """
    if goal_only:
        return world.multiworld.has_beaten_game(state, world.player)
    return (all(loc.can_reach(state) for loc in required_checks)
            and all(region.can_reach(state) for region in required_destinations))


def _slot_lock_targets_soh(world):
    """Apply the bounded ER search only when SlotLock really locks this SOH slot.

    All worlds have created their items before connect_entrances(), including
    SlotLock's `slots_to_lock` list.  A SlotLock world that locks only other
    players must not change this player's entrance-shuffle behavior.
    """
    player_name = world.multiworld.player_name[world.player]
    return any(getattr(other, 'game', None) == 'SlotLock'
               and player_name in getattr(other, 'slots_to_lock', ())
               for other in world.multiworld.worlds.values())


def restore_legacy_defaults(world):
    if not world.using_ut: return
    if 'entrance_randomizer' not in world.passthrough:
        for key, cls in ENTRANCE_OPTIONS.items():
            setattr(world.options, key, cls.from_any(set() if key == 'mixed_entrance_pools' else 0))
        return
    # Earlier mapped seeds did not have a paired overworld pool. A new local
    # template must not add endpoints that are absent from the server's map.
    snapshot = world.passthrough.get('extreme_all_options', world.passthrough)
    option = 'shuffle_overworld_entrances'
    if option not in snapshot and option not in world.passthrough:
        setattr(world.options, option, ENTRANCE_OPTIONS[option].from_any(0))


def prepare_location_routes(world):
    """Compile exact local collection routes before native action sites install."""
    if not enabled(world): return
    world._er_local_item_rules = defaultdict(list)
    world._er_locations = {}
    compiler = world._extreme_room_compiler
    for location in world.get_locations():
        address = location.address if location.address is not None else world.location_name_to_id.get(location.name)
        routes = DUNGEON_ROUTES.get(str(address))
        if not routes: continue
        compiler.location = location.name
        proxy = SohRegion('EXTREME Entrance Collection: '+location.name, world.player, world.multiworld)
        world.multiworld.regions.append(proxy)
        alternatives = defaultdict(list)
        for route in routes:
            rr = route['region']
            alternatives[rr].append(compiler.expr(route['condition'], rr))
        for rr, rules in alternatives.items():
            H.connect_regions(NativeEnemyRegions[rr], world, [(proxy.name, Or(*rules))])
        world._er_locations[location.name] = proxy


def _disconnect(edge):
    if edge.connected_region is not None:
        edge.connected_region.entrances.remove(edge)
    edge.parent_region.exits.remove(edge)
    edge.connected_region = None


def _native_stock_bindings():
    aliases = {'BOTW': 'BOTTOM_OF_THE_WELL', 'DODONGOS_CAVERN_BOSS_AREA': 'DODONGOS_CAVERN_BOSS_REGION',
               'GANONS_TOWER_BEFORE_GANONDORF_LAIR': 'GANONS_TOWER_BEFORE_GANONDORFS_LAIR',
               'GANONS_TOWER_GANONDORF_LAIR': 'GANONDORFS_LAIR', 'GANONS_CASTLE_GANON_ARENA': 'GANONS_ARENA'}
    result = defaultdict(list)
    for rr in GRAPH:
        token = rr[3:]
        if token.startswith('BOTW_'): token = 'BOTTOM_OF_THE_WELL_'+token[5:]
        token = aliases.get(token, token)
        if token in Regions.__members__: result[str(Regions[token])].append(rr)
    return result


def finalize_room_graph(world):
    """Retire the contracted vanilla dungeon graph; never leave bypass edges.

Old region names remain as read-only reachability views for inherited local
events/helpers. All traversal uses the exact native room graph.
"""
    if not enabled(world): return
    bindings = _native_stock_bindings()
    # Include contracted parents that have no native enum equivalent. Their
    # read-only view is the union of their actual collection rooms.
    for name, proxy in world._er_locations.items():
        location = world.get_location(name)
        parent = location.parent_region
        if parent.name not in {str(r) for r in Regions} or parent.name == str(Regions.ROOT): continue
        for edge in proxy.entrances:
            rr = next(k for k, v in NativeEnemyRegions.__members__.items() if str(v) == edge.parent_region.name)
            if rr not in bindings[parent.name]: bindings[parent.name].append(rr)
    world._er_stock_to_native = bindings
    # Save source predicates before disconnecting stock exit edges.
    world._er_stock_edges = {(r.name, e.connected_region.name): e.access_rule
                             for r in world.get_regions() for e in r.exits if e.connected_region}
    for name, rr_list in bindings.items():
        stock = world.get_region(name)
        for edge in list(stock.exits): _disconnect(edge)
        for incoming in list(stock.entrances):
            # Physical external ingress is redirected to the exact native entry.
            # No stock dungeon node retains traversal into another room.
            if incoming.parent_region.name in bindings: continue
            incoming.connected_region.entrances.remove(incoming)
            incoming.connect(world.get_region(str(NativeEnemyRegions[rr_list[0]])))
        for rr in rr_list:
            H.connect_regions(NativeEnemyRegions[rr], world, [(name, True_())])
    for name, proxy in world._er_locations.items():
        location = world.get_location(name)
        location._er_display_region = location.parent_region.name
        location.parent_region.locations.remove(location)
        location.parent_region = proxy
        proxy.locations.append(location)
        rules = world._er_local_item_rules.get(name, [])
        world.set_rule(location, And(*rules) if rules else True_())
    # The private graph normally stops at dungeon boundaries. ER needs the
    # physical exits too, with the exact source action predicate.
    external = json.loads(files(__package__).joinpath('DungeonExternalEdges.json').read_text())
    for e in external:
        H.connect_regions(NativeEnemyRegions[e['source']], world,
                          [(region_name(e['target']), world._extreme_room_compiler.expr(e['condition'], e['source']))])


def _source_rule(world, row):
    source = world.get_region(region_name(row['source']))
    source_key = (NativeEnemyRegions[row['source']] if row['source'].startswith('RR_')
                  else Regions[row['source']])
    bundle = (source_key, world)
    target = region_name(row['target'])
    if 'condition' in row:
        rule = world._extreme_room_compiler.expr(row['condition'], row['source']).resolve(world)
    elif row.get('traversal_rule') == 'day':
        rule = H.at_day((Regions[row['source']], world)).resolve(world)
    else:
        edges = [e for e in source.exits if e.connected_region and e.connected_region.name == target]
        if len(edges) != 1:
            # Synthetic boss returns have no physical reverse door. They are
            # arrival targets only; do not invent a usable exit in logic.
            if row['category'] == 'bosses' and not row['primary'] and not edges:
                return None
            raise OptionError(f"Entrance source route is ambiguous or missing: {row['name']} ({len(edges)})")
        rule = edges[0].access_rule
    extras = []
    # Rock/boulder Soul belongs to the *physical source crossing*.
    # A shuffled destination never inherits a requirement from its former
    # overworld entrance, and leaving a grotto/fountain remains free.
    if (row['id'] in BOULDER_BLOCKED_ENDPOINTS
            and world.options.shuffle_rock_boulder_soul.value):
        extras.append(Has("Rock / Boulder Soul").resolve(world))
    if row['door'] >= 0 and world.options.shuffle_dungeon_doors.value:
        # A new arrival can approach either side of an unopened physical lock.
        # Vanilla cumulative counts and free reverse edges assume a particular
        # route. Require the complete key budget for shuffled small-key doors;
        # this remains safe after spending keys on any other shuffled branch.
        actor, params = row['actor'], row['params']
        small = (actor == 46 and (params >> 6) & 15 == 11) or (actor == 9 and (params >> 7) & 7 == 1)
        if small:
            dungeon, count = KEY_DOORS[row['source_scene']]
            extras.append(H.small_keys(Items[dungeon+'_SMALL_KEY'], count, bundle).resolve(world))
    early_pot_door = row['source_scene'] == 10 and row['door'] in (6, 7) and world.options.shuffle_pots.value in (1, 3)
    if 'extra_condition' in row and not early_pot_door:
        extras.append(world._extreme_room_compiler.expr(row['extra_condition'], row['source']).resolve(world))
    if row.get('gate') == 'swim' or row['id'] in WATER_SUBMERGED_ENDPOINTS:
        extras.append(H.can_swim(bundle).resolve(world))
    if row.get('gate') == 'horse': extras.append(H.can_use(Items.EPONA, bundle).resolve(world))
    # The north Lake Hylia / Hyrule Field fence has a real vertical ladder.
    # Swimming and riding Epona do not allow passage from the fenced landing
    # into the rest of Hyrule Field. Require Climb on the physical crossing,
    # including the associated scene-transition check.
    if row['id'] in (HF_FENCE_TO_LAKE, HF_LAKE_TO_FENCE):
        extras.append(H.can_climb(bundle).resolve(world))
    # The Treasure Chest Game's external door is usable only by child at night
    # and with its building key when Overworld Door Locks are enabled. Do not
    # confuse this *entry* with the inside-to-outside exit check (469): a valid
    # mixed-pool arrival may legitimately reach that exit by another route.
    if row['id'] == 99:
        extras.append((H.is_child(bundle) & H.at_night(bundle) &
                       H.can_open_overworld_door(Items.TREASURE_CHEST_GAME_BUILDING_KEY, bundle)).resolve(world))
    components = (rule, *extras)
    dependencies = tuple(part for part in components if isinstance(part, Rule.Resolved))
    for part in dependencies:
        # These physical predicates are newly compiled outside create_entrance.
        # Without registration a cached "missing key/soul" result never changes
        # when that item is received, despite a fresh full-inventory state passing.
        world.register_rule_dependencies(part)
    def combined(state):
        return all(part(state) for part in components)
    combined._er_dependencies = dependencies
    return combined


def _arrival_rule(world, row):
    # The native catalog groups the Hyrule Field fence-side landing into the
    # whole HYRULE_FIELD region. A mixed-pool arrival at endpoint 393 must NOT
    # grant every field check or certify a safe spawn without Climb. This also
    # fixes UT for already-generated maps (which we cannot silently reroll).
    if row['id'] == HF_LAKE_TO_FENCE:
        rule = H.can_climb((resolve_enemy_region(row['target']), world)).resolve(world)
    elif row.get('arrival_gate') == 'swim' or row['id'] in WATER_SUBMERGED_ENDPOINTS:
        # A dry source can be paired with a water landing. Its crossing check
        # still uses the dry source rule, but entering the destination needs Swim.
        rule = H.can_swim((resolve_enemy_region(row['target']), world)).resolve(world)
    else:
        level = WATER_ARRIVAL_LEVELS.get(row['id'])
        if level is None:
            return None
        rule = world._extreme_room_compiler.expr(
            f'WaterLevel({level}) || CanUse(RG_IRON_BOOTS)', row['target']).resolve(world)
    world.register_rule_dependencies(rule)
    return rule


def _routed_rule(source_rule, arrival_rule):
    if arrival_rule is None:
        return source_rule
    def combined(state):
        return source_rule(state) and arrival_rule(state)
    combined._er_dependencies = (*getattr(source_rule, '_er_dependencies', ()), arrival_rule)
    return combined


def _eligible(world):
    cats = enabled_categories(world)
    result = []
    for e in CATALOG:
        if e['category'] not in cats: continue
        if e['id'] in RIVER_WATER_ALIASES and _river_path_revision(world) == 0: continue
        if e['category'] == 'dungeon_doors' and e['reverse'] < 0:
            # A physically unopenable reverse stays unopenable. Forward-only
            # dungeon shutters join the directed pool when one-ways is enabled.
            if 'one_ways' not in cats: continue
        result.append(e)
    return result


def validate_mapping(world, mapping, *, legacy_dungeon_pools=False):
    eligible = {e['id'] for e in _eligible(world)}
    try:
        MapIntegrity.validate_complete(mapping, eligible)
    except ValueError as exc:
        raise OptionError(str(exc)) from exc
    mixed = mixed_categories(world)
    for source, dest in mapping.items():
        if type(source) is not int or type(dest) is not int:
            raise OptionError('Entrance mapping endpoints must be integers')
        a, b = ENDPOINTS[source], ENDPOINTS.get(dest)
        if b is None: raise OptionError(f'Unknown entrance destination {dest}')
        if not Safety.allowed_route(source, dest):
            raise OptionError('Entrance destination is unreviewed or incompatible with the source age')
        if (not legacy_dungeon_pools and a['category'] == 'dungeon_doors'
                and not dungeon_doors_are_mixed(world)
                and (b['category'] != 'dungeon_doors' or b['source_scene'] != a['source_scene'])):
            raise OptionError('Unmixed dungeon room doors must stay inside their own dungeon')
        if source in LOCAL_CARRIER_DOORS and dest != source:
            raise OptionError(
                'This seed shuffles a Jabu-Jabu door needed to carry Ruto. '
                'Generate a new seed with the matching SOH-EXTREME APWorld.'
            )
        if a['reverse'] >= 0:
            if b['reverse'] < 0 or mapping.get(b['reverse']) != a['reverse']:
                raise OptionError('Unpaired entrance mapping; decoupled entrances are not supported')
            if a['category'] != b['category'] and not {a['category'], b['category']} <= mixed:
                raise OptionError('Entrance destination crosses pools without mixed entrances enabled')
        elif dest != source and dest not in {e['id'] for e in _one_way_targets(
                world, a, legacy_dungeon_pools=legacy_dungeon_pools)}:
            raise OptionError('One-way destination is outside its selected pool')


def _one_way_targets(world, source, *, legacy_dungeon_pools=False):
    mixed = mixed_categories(world)
    if (source['category'] == 'dungeon_doors' and not legacy_dungeon_pools
            and not dungeon_doors_are_mixed(world)):
        # Forward-only shutters remain dungeon doors, even though the one-way
        # option is needed to shuffle them. They must not inherit the ordinary
        # river/fence destinations outside their dungeon.
        targets = [e for e in CATALOG if e['category'] == 'dungeon_doors'
                   and e['source_scene'] == source['source_scene'] and e['primary']]
    elif source['category'] in mixed:
        targets = [e for e in CATALOG if e['category'] in mixed & enabled_categories(world) and e['primary']]
    else:
        targets = [e for e in CATALOG if e['category'] in ('overworld', 'owls', 'warp_songs')]
    return [e for e in targets if Safety.allowed_route(source['id'], e['id'])
            and not (e['id'] in RIVER_WATER_ALIASES and _river_path_revision(world) == 0)
            # One-way songs/spawns/owl drops must never bypass the fixed pair
            # and dump a Climb-less player on the isolated fence landing.
            and not (_fence_pair_must_stay_vanilla(world)
                     and e['id'] == HF_LAKE_TO_FENCE)]


def _candidate(world):
    eligible = _eligible(world); mixed = mixed_categories(world)
    pools = defaultdict(list); one_ways = []
    for e in eligible:
        if e['reverse'] < 0: one_ways.append(e)
        elif (e['primary'] and e['id'] not in LOCAL_CARRIER_DOORS
              and not (_fence_pair_must_stay_vanilla(world)
                       and e['id'] == HF_FENCE_TO_LAKE)):
            pools[_paired_pool_key(e, mixed)].append(e)
    mapping = {e['id']: e['id'] for e in eligible
               if e['id'] in LOCAL_CARRIER_DOORS
               or (_fence_pair_must_stay_vanilla(world)
                   and e['id'] in (HF_FENCE_TO_LAKE, HF_LAKE_TO_FENCE))}
    for pool in pools.values():
        targets = pool.copy(); world.random.shuffle(targets)
        for source, dest in zip(pool, targets):
            mapping[source['id']] = dest['id']
            mapping[dest['reverse']] = source['reverse']
    for source in one_ways:
        targets = [target for target in _one_way_targets(world, source)
                   if _spawn_destination_allowed(world, source, target['id'])]
        if not targets:
            raise OptionError('No reviewed, age-compatible one-way destination is enabled')
        mapping[source['id']] = world.random.choice(targets)['id']
    return mapping


# Minuet's warp pad (endpoint 1536) is inside Sacred Forest Meadow, behind
# the Wolfos gate when played as Child. The only dependable physical exit from
# that starting position is the climbable maze. When Climb is shuffled, the
# child may start without it, so never choose this pad as their starting spawn.
# Intentionally apply this only to new seed placement; reading an existing
# server's recorded entrance map must not silently change its destinations.
SFM_MINUET_WARP_PAD = 1536

# Hyrule Field's Lake Hylia north arrival (393) is the small *fence-side*
# landing, NOT the accessible Hyrule Field overworld. Without shuffled Climb,
# arriving here from an unrelated shuffled door can strand Link at the ladder.
# Keep this coupled physical pair at its stock routing while Climb is shuffled.
# The paired IDs must remain in the emitted map as identity endpoints for UT
# and the native client. Do not remove them from the catalog/eligible set.
HF_FENCE_TO_LAKE = 258
HF_LAKE_TO_FENCE = 393


def _fence_pair_must_stay_vanilla(world):
    # For existing UT saves, accept the recorded map as-is. New maps must not
    # route players into the unsafe fence-side landing before they have Climb.
    return bool(world.options.shuffle_climb.value) and not world.using_ut


def _spawn_destination_allowed(world, source, target_id):
    return not (source['category'] == 'child_spawn'
                and target_id == SFM_MINUET_WARP_PAD
                and world.options.shuffle_climb.value)


def _is_default_spawn(source, target):
    # Physical aliases share a scene: child spawn and house entry; adult spawn,
    # Temple entrance and Prelude pad. Fresh shuffled spawns must leave home.
    return (source['category'] in ('child_spawn', 'adult_spawn')
            and ENDPOINTS[target]['scene'] == source['scene'])


def _validate_spawn_pools(world, rows):
    for source in rows:
        if source['category'] not in ('child_spawn', 'adult_spawn'): continue
        if not any(not _is_default_spawn(source, target['id'])
                   and _spawn_destination_allowed(world, source, target['id'])
                   for target in _one_way_targets(world, source)):
            name = source['category'].replace('_', ' ')
            raise OptionError(
                f'No alternate {name} destination exists in the enabled mixed entrance pools. '
                'Enable another destination category or use separate pools '
                '(mixed_entrance_pools: []).'
            )


def _place_one_way(world, mapping, source, viable, *, allow_failure=False, limit=None):
    """Find a legal one-way destination using a bounded targeted search.

    Starting spawns intentionally retain exhaustive search, since a missing
    playable start is an error. Optional one-way sources (songs, owl drops,
    fences, forward-only room shutters) may remain at their valid identity
    instead of burning hundreds of full-state validations on an impossible
    alternate. `limit` never weakens a route predicate.
    """
    targets = list(dict.fromkeys(target['id'] for target in _one_way_targets(world, source)
                                 if not _is_default_spawn(source, target['id'])
                                 and _spawn_destination_allowed(world, source, target['id'])))
    world.random.shuffle(targets)
    if limit is not None and source['category'] not in ('child_spawn', 'adult_spawn'):
        targets = targets[:limit]
    for target in targets:
        candidate = dict(mapping)
        candidate[source['id']] = target
        if viable(candidate):
            return candidate
    if source['category'] in ('child_spawn', 'adult_spawn') and not allow_failure:
        name = source['category'].replace('_', ' ')
        raise OptionError(
            f'No playable alternate {name} was found after checking all '
            f'{len(targets)} allowed destinations. A start needs reachable '
            'progression beyond Link\'s Pocket, a usable return, and a route '
            'to Hyrule Field with the configured starting inventory.'
        )
    return None


def _swap_coupled_pair(mapping, first, second):
    """Change exactly the two selected entrances and their coupled returns.

    Never rebuild or reroll unrelated pools. `mapping` is a private candidate,
    so failures cannot change the last accepted topology.
    """
    a, b = mapping[first], mapping[second]
    mapping[first], mapping[second] = b, a
    mapping[ENDPOINTS[b]['reverse']] = ENDPOINTS[first]['reverse']
    mapping[ENDPOINTS[a]['reverse']] = ENDPOINTS[second]['reverse']


def _pair_static_safe(mapping, first, second):
    """Reject impossible endpoints before an expensive AP reachability sweep."""
    if first == second:
        return False
    a, b = mapping[first], mapping[second]
    return (Safety.allowed_route(first, b)
            and Safety.allowed_route(second, a)
            and Safety.allowed_route(ENDPOINTS[b]['reverse'], ENDPOINTS[first]['reverse'])
            and Safety.allowed_route(ENDPOINTS[a]['reverse'], ENDPOINTS[second]['reverse']))


def _repair_swap_batch(mapping, swaps, viable):
    """Validate several local swaps once, then isolate any invalid piece.

    A successful batch replaces N full progression checks with one. If a batch
    fails, split it into smaller parts, retaining each independently validated
    part and leaving only the rejected connections unchanged. This preserves
    the same fail-closed tests as a one-at-a-time swap without rerolling the
    complete entrance map. Return (mapping, accepted_count, clean_batch).
    """
    if not swaps:
        return mapping, 0, True
    candidate = dict(mapping)
    for first, second in swaps:
        _swap_coupled_pair(candidate, first, second)
    if viable(candidate):
        return candidate, len(swaps), True
    if len(swaps) == 1:
        return mapping, 0, False
    midpoint = len(swaps) // 2
    left, left_accepted, _ = _repair_swap_batch(mapping, swaps[:midpoint], viable)
    right, right_accepted, _ = _repair_swap_batch(left, swaps[midpoint:], viable)
    return right, left_accepted + right_accepted, False


def _shuffle_paired_pool(world, mapping, pool, viable, *, slot_lock_mode=False):
    """Adaptive local repair for coupled entrances, with bounded full checks.

    Pairs are disjoint within a batch so static eligibility is stable. Each
    candidate is either accepted after the complete physical safety check or
    discarded. Failed batches shrink automatically; valid batches grow to
    amortize the expensive reachability computations. Normal seeds get a
    repair pass over still-unshuffled endpoints. SlotLock receives a small,
    bounded local repair attempt (at most eight unchanged sources per pool).
    """
    accepted = 0
    order = pool.copy()
    world.random.shuffle(order)
    for pass_number in range(2):
        if pass_number:
            order = [source for source in pool if mapping[source] == source]
            world.random.shuffle(order)
            if slot_lock_mode:
                # Retry a handful of the actual failed/unshuffled endpoints,
                # not every entrance and not a fresh whole-world permutation.
                order = order[:8]
        pending = iter(order)
        batch_size = 6
        exhausted = False
        while not exhausted:
            # Build a handful of mutually independent candidate swaps. A
            # statically invalid combination never reaches the AP logic sweep.
            swaps = []
            used = set()
            while len(swaps) < batch_size:
                try:
                    first = next(pending)
                except StopIteration:
                    exhausted = True
                    break
                if first in used:
                    continue
                partner_order = pool.copy()
                world.random.shuffle(partner_order)
                second = next((other for other in partner_order
                               if other not in used and _pair_static_safe(mapping, first, other)), None)
                if second is None:
                    continue
                used.update((first, second))
                swaps.append((first, second))
            if not swaps:
                continue
            mapping, count, clean = _repair_swap_batch(mapping, swaps, viable)
            accepted += count
            batch_size = min(12, batch_size + 2) if clean else max(1, batch_size // 2)
    return mapping, accepted


def _repair_directed_batch(mapping, edits, viable):
    """Commit several independent one-way assignments, or isolate failures."""
    if not edits:
        return mapping, 0, []
    candidate = dict(mapping)
    for source_id, destination_id in edits:
        candidate[source_id] = destination_id
    if viable(candidate):
        return candidate, len(edits), []
    if len(edits) == 1:
        return mapping, 0, [edits[0][0]]
    middle = len(edits) // 2
    left, left_count, left_failed = _repair_directed_batch(mapping, edits[:middle], viable)
    right, right_count, right_failed = _repair_directed_batch(left, edits[middle:], viable)
    return right, left_count + right_count, left_failed + right_failed


def _place_optional_one_ways(world, mapping, sources, viable, *, limit=8):
    """Batch optional one-way sources and retry only failed individual sources.

    Target lists are bounded, not blindly exhausted. A rejected one-way retains
    its physically valid original route. Spawns are deliberately not handled
    here: they must be chosen with exhaustive start/return verification.
    """
    choices = {}
    for source in sources:
        targets = list(dict.fromkeys(target['id'] for target in _one_way_targets(world, source)
                                     if target['id'] != source['id']
                                     and not _is_default_spawn(source, target['id'])
                                     and _spawn_destination_allowed(world, source, target['id'])))
        world.random.shuffle(targets)
        choices[source['id']] = targets[:limit]
    edits = [(source['id'], choices[source['id']][0]) for source in sources
             if choices[source['id']]]
    accepted = 0
    failed = []
    for index in range(0, len(edits), 8):
        mapping, count, rejects = _repair_directed_batch(mapping, edits[index:index + 8], viable)
        accepted += count
        failed.extend(rejects)
    # Only retry sources whose proposed alternate actually failed. Accepted
    # directions never get rerolled, and the remainder of the map stays fixed.
    for source_id in failed:
        for destination_id in choices[source_id][1:]:
            candidate = dict(mapping)
            candidate[source_id] = destination_id
            if viable(candidate):
                mapping = candidate
                accepted += 1
                break
    return mapping, accepted


def _place_spawns(world, mapping, rows, viable, *, allow_failure=False):
    """Establish the actual starting age first, then the other enabled spawn."""
    starting = 'adult_spawn' if world.options.starting_age == 'adult' else 'child_spawn'
    spawns = [row for row in rows if row['category'] in ('child_spawn', 'adult_spawn')]
    spawns.sort(key=lambda row: row['category'] != starting)
    result = mapping
    for source in spawns:
        candidate = _place_one_way(world, result, source, viable, allow_failure=allow_failure)
        if candidate is None: return None
        result = candidate
    return result


def _reachable_as_age(world, state, spot, age):
    """Use one age's own region fixed point and restore the caller's context."""
    previous = state._soh_extreme_age[world.player]
    try:
        state._soh_extreme_age[world.player] = age
        if hasattr(spot, 'can_reach_as_age'):
            return spot.can_reach_as_age(state, age)
        return spot.can_reach(state)
    finally:
        state._soh_extreme_age[world.player] = previous


def _reachable_at_starting_age(world, state, spot):
    """Use the selected age, including the world's normal age-specific rules."""
    age = Ages.ADULT if world.options.starting_age == 'adult' else Ages.CHILD
    return _reachable_as_age(world, state, spot, age)


def _age_routes_are_safe(world, mapping, edges, state):
    """Prove that every physically reachable route accepts its actual age.

    Interior return doors are not inherently child-only or adult-only. A mixed
    entrance, song or spawn can expose them to a different age. Check the
    candidate's fresh, fully swept inventory state, including restricted
    identity exits whose shuffle category is disabled. Do not hide a bad
    physical route by adding a destination age predicate to the AP graph.
    """
    for row in CATALOG:
        target = mapping.get(row['id'], row['id'])
        allowed = Safety.arrival_age_mask(target)
        if not allowed:
            return False
        if allowed == Safety.BOTH:
            continue
        edge = edges.get(row['id'])
        if edge is not None:
            physical_edges = (edge,)
        elif row['category'] == 'bosses' and not row['primary']:
            # This synthetic return has no physical door. The actual boss exit
            # is the derived blue warp, which is checked separately.
            continue
        else:
            source = world.get_region(region_name(row['source']))
            physical_edges = tuple(edge for edge in source.exits
                                   if edge.connected_region is not None
                                   and edge.connected_region.name == region_name(row['target']))
            if not physical_edges:
                raise OptionError('Cannot verify the age requirements of entrance: ' + row['name'])
        for age, bit in ((Ages.CHILD, Safety.CHILD), (Ages.ADULT, Safety.ADULT)):
            if not allowed & bit and any(_reachable_as_age(world, state, edge, age)
                                         for edge in physical_edges):
                return False
    return True


def _initial_state_for_age(world, age):
    """A fresh private spawn probe with only configured items and local prefill.

    Testing the later age assumes only that time travel has occurred. This
    private event opens that age's root; it adds no equipment, song, ability,
    soul, starting item or event to the generated seed or its real state.
    """
    state = CollectionState(world.multiworld, allow_partial_entrances=True)
    starting_age = Ages.ADULT if world.options.starting_age == 'adult' else Ages.CHILD
    if age != starting_age:
        state.collect(SohItem(str(Events.TIME_TRAVEL), ItemClassification.progression,
                              None, world.player), True)
    local_events = getattr(world, '_er_local_seed_events', None)
    if local_events is None:
        local_events = [loc for loc in world.get_locations()
                        if loc.item is not None and loc.item.player == world.player]
    state.sweep_for_advancements(locations=local_events)
    return state


def _spawn_return_is_usable(world, state, target, edges, age):
    if target['reverse'] < 0:
        return True
    # A paired arrival must leave its actual reverse usable. Synthetic boss
    # returns are not physical doors and cannot certify a safe spawn.
    reverse = ENDPOINTS[target['reverse']]
    return_edge = edges.get(reverse['id'])
    if return_edge is None:
        source = world.get_region(region_name(reverse['source']))
        destination = region_name(reverse['target'])
        return_edges = [edge for edge in source.exits
                        if edge.connected_region is not None
                        and edge.connected_region.name == destination]
    else:
        return_edges = (return_edge,)
    return any(_reachable_as_age(world, state, edge, age) for edge in return_edges)


def _starting_state_is_viable(world, mapping, edges, fill_locations):
    """Prove the selected start and each enabled age's own save/spawn escape.

    Rebuild these states after every topology change. A full-inventory route,
    another age's reachability, or Link's Pocket cannot certify a playable
    spawn. Unmapped vanilla starts retain their ordinary progression rules.
    """
    starting_age = Ages.ADULT if world.options.starting_age == 'adult' else Ages.CHILD
    state = _initial_state_for_age(world, starting_age)
    category = 'adult_spawn' if starting_age == Ages.ADULT else 'child_spawn'
    spawn = next(e for e in CATALOG if e['category'] == category)

    # The Water Temple's ordinary entrance and room-door arrivals can start
    # submerged. Both spawns must be safe with the configured initial Swim.
    if world.options.shuffle_swim.value and not state.has('Swim', world.player):
        for row in CATALOG:
            if row['category'] not in ('child_spawn', 'adult_spawn'):
                continue
            if row['id'] != spawn['id'] and row['id'] not in mapping:
                continue
            if ENDPOINTS[mapping.get(row['id'], row['id'])]['scene'] == 5:
                return False

    for row in CATALOG:
        if row['category'] not in ('child_spawn', 'adult_spawn') or row['id'] not in mapping:
            continue
        age = Ages.CHILD if row['category'] == 'child_spawn' else Ages.ADULT
        bit = Safety.CHILD if age == Ages.CHILD else Safety.ADULT
        target = ENDPOINTS[mapping[row['id']]]
        if not Safety.allowed_age(target['id'], bit):
            return False
        probe = state if age == starting_age else _initial_state_for_age(world, age)
        # The physical destination must be part of this age's accessible graph.
        # A distant route to Hyrule Field cannot prove that the starting room
        # (notably a shuffled small-fairy grotto) exposes its own checks.
        landing_region = world.get_region(region_name(target['target']))
        if not _reachable_as_age(world, probe, landing_region, age):
            return False
        if not _spawn_return_is_usable(world, probe, target, edges, age):
            return False
        # Door checks in a closed component are not a usable way out. The
        # other age is tested with its own root and physical exit predicates.
        if not _reachable_as_age(world, probe, world.get_region(str(Regions.HYRULE_FIELD)), age):
            return False

    if not fill_locations:
        return True
    return any(loc.parent_region.name != str(Regions.ROOT)
               and loc.progress_type != LocationProgressType.EXCLUDED
               and _reachable_as_age(world, state, loc, starting_age)
               for loc in fill_locations)


def _physical_start_is_connected(world, inventory, age=None):
    """Keep one age's start connected to the physical overworld.

    A small isolated room component can appear connected when a full-inventory
    probe assumes all warp songs, notes and buttons. Require a route to Hyrule
    Field without Ocarina in this private structural probe. Real starting-item,
    return-path and safe-water checks remain separate and are still mandatory.
    """
    starting_age = Ages.ADULT if world.options.starting_age == 'adult' else Ages.CHILD
    if age is None:
        age = starting_age
    state = inventory.copy()
    if age != starting_age:
        # This structural probe starts after that age has become available;
        # it must not need an instrument just to activate the other age's root.
        state.collect(SohItem(str(Events.TIME_TRAVEL), ItemClassification.progression,
                              None, world.player), True)
    ocarina_name = str(Items.PROGRESSIVE_OCARINA)
    if state.has(ocarina_name, world.player):
        ocarina = world.create_item(ocarina_name)
        while state.has(ocarina_name, world.player):
            state.remove(ocarina)
    # Do not regain an instrument from prefill while sweeping. This also keeps
    # the probe independent of remote players' future sends. Each candidate gets
    # a new unswept inventory copy, so rejected topology/events cannot leak in.
    local_events = getattr(world, '_er_local_seed_no_ocarina', None)
    if local_events is None:
        local_events = [loc for loc in world.get_locations()
                        if loc.item is not None and loc.item.player == world.player
                        and loc.item.name != ocarina_name]
    state.sweep_for_advancements(locations=local_events)
    return _reachable_as_age(world, state, world.get_region(str(Regions.HYRULE_FIELD)), age)


def connect(world):
    if not enabled(world):
        world._er_mapping = {}; return
    rows = _eligible(world)
    # Other APWorlds (notably Link's Awakening Switch) may have deferred
    # dungeon entrances until their own connect_entrances() runs. During
    # SOH-EXTREME entrance shuffling, ignore only these not-yet-connected
    # *other-world* edges; all local route safety tests still run.
    goal_only = _is_goal_reachability(world)
    if goal_only:
        # The goal-only setting never evaluates vanilla-reachable checks or
        # destination regions. Avoid constructing the expensive baseline
        # full-inventory state entirely; the candidate/final inventory is
        # prepared below once per generation.
        required = []
        required_destinations = []
    else:
        baseline = world.multiworld.get_all_state(False, allow_partial_entrances=True)
        required = [loc for loc in world.get_locations()
                    if loc.address is not None and loc.can_reach(baseline)]
        required_destinations = _reachable_stock_destinations(world, rows, baseline)
    # Include blue warps: defeating a shuffled boss must lead back through its
    # paired route, including a boss chamber reached from a house or room door.
    blue = [e for e in CATALOG if e['category'] == 'blue_warps']
    # Old maps share their land destinations with the omitted water crossings.
    # Materialize both physical sources for their own Swim/check rules while
    # keeping the saved map and its coupled land returns unchanged.
    legacy_water = ([ENDPOINTS[endpoint] for endpoint in RIVER_WATER_ALIASES]
                    if _river_path_revision(world) == 0 and 'overworld' in enabled_categories(world) else [])
    sources = rows + blue + legacy_water
    rules = {e['id']: _source_rule(world, e) for e in sources}
    for row in sources:
        if rules[row['id']] is None: continue
        for location in SceneTransitions.locations_for_base(world, row['check_id']):
            location.parent_region.locations.remove(location)
            location.parent_region = world.get_region(region_name(row['source']))
            location.parent_region.locations.append(location)
            location.access_rule = rules[row['id']]
    edges = {}
    # Multiple physical doorways can share an AP edge. Replace that aggregate
    # with one edge per actual source endpoint, retaining every source gate.
    for row in sources:
        if rules[row['id']] is None: continue
        source = world.get_region(region_name(row['source']))
        target = world.get_region(region_name(row['target']))
        for edge in list(source.exits):
            if edge.connected_region is target and not edge.name.startswith('EXTREME Shuffled Entrance '):
                _disconnect(edge)
        edge = source.create_exit('EXTREME Shuffled Entrance '+str(row['id']))
        edge.access_rule = rules[row['id']]
        for dependency in getattr(edge.access_rule, '_er_dependencies', ()):
            world._register_rule_indirects(dependency, edge)
        edge.connect(target)
        edges[row['id']] = edge
    arrival_rules = {row['id']: _arrival_rule(world, row) for row in CATALOG
                     if row['id'] in WATER_ARRIVAL_LEVELS
                     or row['id'] in WATER_SUBMERGED_ENDPOINTS
                     or row.get('arrival_gate')}
    routed_rules = {}
    installed_destinations = {}
    def apply(mapping, *, update_labels=False):
        routes = dict(mapping)
        for warp in blue:
            boss = next((e for e in CATALOG if e['category'] == 'bosses' and e['primary']
                         and e['target'] == warp['source']), None)
            if boss and boss['reverse'] in mapping:
                routes[warp['id']] = mapping[boss['reverse']]
            elif 'dungeons' in enabled_categories(world):
                # Vanilla boss chamber in a shuffled dungeon: its blue warp
                # exits through the dungeon's paired overworld connection.
                entry = next((e for e in CATALOG if e['category'] == 'dungeons' and not e['primary']
                              and boss and e['source_scene'] == boss['source_scene']), None)
                if entry and entry['id'] in mapping: routes[warp['id']] = mapping[entry['id']]
        # This is called for hundreds of tentative pair swaps with the same
        # 721-edge graph. A pair swap changes at most a few destinations.
        # Reconnecting every edge invalidates expensive graph machinery and
        # regenerates indirect-rule bindings for no logical change.
        candidate_destinations = {
            source_id: _routed_destination(world, routes, source_id)
            for source_id in edges
        }
        for id in _changed_route_ids(installed_destinations, candidate_destinations):
            edge = edges[id]
            destination = candidate_destinations[id]
            edge.connected_region.entrances.remove(edge)
            edge.connect(world.get_region(region_name(ENDPOINTS[destination]['target'])))
            key = (id, destination)
            if key not in routed_rules:
                # Keep physical source predicates immutable and compose each
                # source/destination pair's arrival gate once.
                rule = _routed_rule(rules[id], arrival_rules.get(destination))
                for dependency in getattr(rule, '_er_dependencies', ()):
                    world._register_rule_indirects(dependency, edge)
                routed_rules[key] = rule
            edge.access_rule = routed_rules[key]
            installed_destinations[id] = destination
        # Every new candidate still invalidates reachability state and runs
        # *all* the original safety, age, return and item checks. No relaxed
        # logic or unvalidated entrance map is emitted.
        world.multiworld._all_state_cache = None
        world._er_mapping = routes
        if update_labels:
            # Labels are only consumed after the final, validated map. Do not
            # reformat hundreds of labels for each discarded probe.
            display_routes = dict(routes)
            display_routes.update({row['id']: _routed_destination(world, routes, row['id'])
                                   for row in legacy_water})
            world._er_labels = {}
            for k, v in display_routes.items():
                original_check = ENDPOINTS[k]['check_id']
                if not original_check:
                    continue
                label = shuffled_check_label(ENDPOINTS[k], ENDPOINTS[v])
                variants = SceneTransitions.locations_for_base(world, original_check)
                for check in variants:
                    suffix = (' [Child]' if getattr(check, 'transition_age', None) == Ages.CHILD else
                              ' [Adult]' if getattr(check, 'transition_age', None) == Ages.ADULT else '')
                    world._er_labels[check.address] = label + suffix
    def assert_installed_topology():
        """Fail closed if AP's final entrance graph differs from the exported map.

        This checks every active *physical* shuffled source edge, including
        synthetic dungeon room doors and legacy Zora River water aliases.
        Synthetic boss return rows may legitimately have no physical exit.
        The native client independently validates the byte-level slot map.
        """
        expected = {}
        actual = {}
        for source_id, edge in edges.items():
            source_row = ENDPOINTS[source_id]
            destination_id = _routed_destination(world, world._er_mapping, source_id)
            expected[source_id] = (
                region_name(source_row['source']),
                region_name(ENDPOINTS[destination_id]['target']),
            )
            actual[source_id] = (
                edge.parent_region.name,
                edge.connected_region.name if edge.connected_region else None,
            )
        # No pool is allowed to silently drop a physical source just because
        # an old stock entrance or a relocated check still resolves elsewhere.
        try:
            TopologyAudit.validate_edges(expected, actual)
        except ValueError as exc:
            raise OptionError('Installed shuffled entrance graph does not match the '
                              'published entrance map: ' + str(exc)) from exc
        for row in sources:
            source_id = row['id']
            source_rule = rules[source_id]
            if source_rule is None:
                continue
            for check in SceneTransitions.locations_for_base(world, row['check_id']):
                if (check.parent_region.name != region_name(row['source'])
                        or check.access_rule is not source_rule):
                    raise OptionError('Entrance crossing check is not tied to its physical '
                                      f'source: {row["name"]} (endpoint {source_id})')

    if world.using_ut:
        saved = world.passthrough.get('entrance_randomizer', {})
        if saved.get('revision') != REVISION: raise OptionError('Unsupported entrance mapping revision')
        if saved.get('destination_policy_revision', Safety.POLICY_REVISION) != Safety.POLICY_REVISION:
            raise OptionError('Unsupported entrance destination safety policy')
        pool_revision = saved.get('pool_policy_revision', 0)
        if type(pool_revision) is not int or pool_revision not in (0, POOL_POLICY_REVISION):
            raise OptionError('Unsupported dungeon entrance pool policy')
        mapping = {int(k): v for k, v in saved.get('connections', {}).items() if int(k) in {e['id'] for e in rows}}
        validate_mapping(world, mapping, legacy_dungeon_pools=pool_revision == 0); apply(mapping, update_labels=True)
        assert_installed_topology()
        if world._er_mapping != {int(k): v for k, v in saved['connections'].items()}:
            raise OptionError('Entrance mapping blue-warp return data differs from this world')
        state = world.multiworld.get_all_state(False, allow_partial_entrances=True,
                                               perform_sweep=False).copy()
        state.sweep_for_advancements()
        if not _age_routes_are_safe(world, world._er_mapping, edges, state):
            raise OptionError('This entrance map can reach an age-incompatible arrival. '
                              'Generate a new seed with the matching SOH-EXTREME APWorld.')
        return
    # These fresh-generation guards never rewrite or reject an older saved
    # spawn merely because it legitimately used a default-home destination.
    _validate_spawn_pools(world, rows)
    # Use the actual fully configured AP rules, including abilities/souls and
    # native action events. A topological graph-only check is insufficient.
    # Start with the known connected topology and randomize by validated pair
    # swaps. This avoids exponentially unlikely whole-pool retries when many
    # interiors have age restrictions or several physical exits.
    mapping = {e['id']: e['id'] for e in rows}
    mixed = mixed_categories(world)
    pools = defaultdict(list)
    for e in rows:
        if (e['primary'] and e['reverse'] >= 0 and e['id'] not in LOCAL_CARRIER_DOORS
                and not (_fence_pair_must_stay_vanilla(world)
                         and e['id'] == HF_FENCE_TO_LAKE)):
            pools[_paired_pool_key(e, mixed)].append(e['id'])
    accepted = 0
    # Validate every paired source at least once. For normal seeds, revisit
    # only sources still at their original entrance after the first pass,
    # rather than blindly retrying every pair for two more complete passes.
    # For SlotLock, retain the previously bounded single pass. Every proposed
    # swap continues through all physical safety/accessibility predicates.
    slot_lock_mode = _slot_lock_targets_soh(world)

    # Fixed event sites do not change as entrance destinations are tested;
    # compute their advancement filters once. In a normal seed, the global
    # filter is exactly the event set that CollectionState.sweep_for_advancements
    # would discover anew on each call (including all remote progression).
    # SlotLock can continue using the more conservative SOH-local event set.
    world._er_local_seed_events = [
        loc for loc in world.get_locations()
        if loc.item is not None and loc.item.player == world.player and loc.advancement
    ]
    world._er_local_seed_no_ocarina = [
        loc for loc in world._er_local_seed_events
        if loc.item.name != str(Items.PROGRESSIVE_OCARINA)
    ]
    local_advancement_events = world._er_local_seed_events
    all_advancement_events = (None if slot_lock_mode else [
        loc for loc in world.multiworld.get_locations() if loc.advancement
    ])
    inventory = world.multiworld.get_all_state(False, allow_partial_entrances=True,
                                               perform_sweep=False)
    fill_locations = [loc for loc in world.get_locations()
                      if loc.address is not None and loc.item is None]
    probe_ages = {Ages.ADULT if world.options.starting_age == 'adult' else Ages.CHILD}
    probe_ages.update(Ages.CHILD if row['category'] == 'child_spawn' else Ages.ADULT
                      for row in rows if row['category'] in ('child_spawn', 'adult_spawn'))
    # A location with the identical parent and identical access rule has the
    # same reachability result. Only BaseClasses' unmodified can_reach method
    # participates; custom subclasses are always checked individually.
    required_probes = [] if goal_only else _distinct_reachability_probes(required)
    logging.info('SOH-EXTREME entrance validation mode: %s',
                 'Goal Reachable' if goal_only else 'All Destinations')
    if goal_only and _is_full_accessibility(world):
        logging.info('SOH-EXTREME: Goal Reachable + Full accessibility: validating '
                     'safe starts and goal during entrance shuffle; before item '
                     'placement, unreachable optional checks will be retired so '
                     'AP Full applies to every remaining enabled location.')
    if slot_lock_mode:
        logging.info('SOH-EXTREME: SlotLock targets %s; using one validated '
                     'entrance-swap pass', world.multiworld.player_name[world.player])
    if not goal_only:
        logging.info('SOH-EXTREME entrance generation: %d required checks '
                     'represented by %d equivalent reachability probes, '
                     '%d stock-reachable destination regions',
                     len(required), len(required_probes), len(required_destinations))
    attempts = 0
    progress_start = monotonic()
    last_progress = progress_start
    def viable(candidate):
        nonlocal attempts, last_progress
        attempts += 1
        now = monotonic()
        if now - last_progress >= 30:
            logging.info('SOH-EXTREME entrance shuffle: %d candidates checked, '
                         '%d accepted, %.1f seconds elapsed (full safety validation active)',
                         attempts, accepted, now - progress_start)
            last_progress = now
        if any(not Safety.allowed_route(source, target) for source, target in candidate.items()):
            return False
        apply(candidate)
        if not _starting_state_is_viable(world, candidate, edges, fill_locations):
            return False
        if any(not _physical_start_is_connected(world, inventory, age) for age in probe_ages):
            return False
        state = inventory.copy()
        if slot_lock_mode:
            state.sweep_for_advancements(locations=local_advancement_events)
        else:
            # Same worldwide advancement events as the original full sweep,
            # without rebuilding the event list for every candidate mapping.
            state.sweep_for_advancements(locations=all_advancement_events)
        return (_age_routes_are_safe(world, world._er_mapping, edges, state)
                and _entrance_objective_met(world, state, goal_only,
                                            required_probes, required_destinations))
    # Choose the real spawns on the connected base graph. Every later accepted
    # swap must preserve their starting access, rather than protecting a house
    # spawn that will be replaced at the end. If restrictive pools need a
    # rearranged graph before an alternate is possible, retain one bounded
    # fallback through the ordinary validated pair pass and retry all targets.
    spawn_mapping = _place_spawns(world, mapping, rows, viable, allow_failure=True)
    if spawn_mapping is not None:
        mapping = spawn_mapping
        accepted += sum(row['category'] in ('child_spawn', 'adult_spawn') for row in rows)
    else:
        apply(mapping)
    for pool in pools.values():
        mapping, added = _shuffle_paired_pool(world, mapping, pool, viable,
                                              slot_lock_mode=slot_lock_mode)
        accepted += added
    logging.info('SOH-EXTREME entrance shuffle: paired pools completed; '
                 '%d validated swaps accepted / %d safety checks', accepted, attempts)
    if spawn_mapping is None:
        mapping = _place_spawns(world, mapping, rows, viable)
        accepted += sum(row['category'] in ('child_spawn', 'adult_spawn') for row in rows)
    optional_one_ways = [e for e in rows if e['reverse'] < 0
                         and e['category'] not in ('child_spawn', 'adult_spawn')]
    # Group independent directed exits; split invalid groups and only retry
    # the failing source, never the entire entrance map.
    mapping, added = _place_optional_one_ways(world, mapping, optional_one_ways,
                                              viable, limit=8)
    accepted += added
    logging.info('SOH-EXTREME entrance shuffle: directed endpoints completed; '
                 '%d accepted / %d safety checks', accepted, attempts)
    validate_mapping(world, mapping)
    apply(mapping, update_labels=True)
    assert_installed_topology()
    final_state = inventory.copy()
    final_state.sweep_for_advancements()
    if not _age_routes_are_safe(world, world._er_mapping, edges, final_state):
        raise OptionError('The entrance map contains a route to an age-incompatible arrival. '
                          'No unsafe entrance map was emitted.')
    # Verify the chosen objective once more on the final installed mapping.
    # Rejected candidate maps temporarily touched the graph, so this must not
    # rely on a prior candidate's cached reachability result.
    if not _entrance_objective_met(world, final_state, goal_only,
                                   required_probes, required_destinations):
        if goal_only:
            raise OptionError("The final entrance map cannot reach SOH-EXTREME's "
                              'completion goal with all available items. '
                              'No unbeatable entrance map was emitted.')
        raise OptionError('The final entrance map lost a stock-reachable entrance '
                          'destination or mandatory reachable check. '
                          'No unsafe entrance map was emitted.')
    if not _starting_state_is_viable(world, mapping, edges, fill_locations):
        raise OptionError(
            'No playable entrance start was found for the selected starting age and inventory. '
            'A start needs a reachable progression check beyond Link\'s Pocket, '
            'and a shuffled spawn must have a usable return and a route to '
            'Hyrule Field with the configured starting inventory.'
        )
    world._er_generation_attempts = accepted
    logging.info('SOH-EXTREME entrance shuffle completed: %d accepted / %d candidates '
                 'in %.1f seconds', accepted, attempts, monotonic() - progress_start)



def slot_data(world):
    return {'revision': REVISION, 'destination_policy_revision': Safety.POLICY_REVISION,
            'pool_policy_revision': _pool_policy_revision(world),
            'river_path_revision': _river_path_revision(world),
            'reachability_mode': 'goal_reachable' if _is_goal_reachability(world) else 'all_destinations',
            'effective_mixed_categories': sorted(mixed_categories(world)),
            'dungeon_door_mixed_outside': int(dungeon_doors_mix_outside(world)),
            'disabled_actions': getattr(world, '_er_disabled_actions', []),
            'connections': {str(k): v for k, v in sorted(getattr(world, '_er_mapping', {}).items())}}


def native_settings(world):
    cats = enabled_categories(world); mixed = mixed_categories(world)
    result = {'EntranceRandomizerRevision': REVISION if cats else 0,
              'EntranceDestinationPolicyRevision': Safety.POLICY_REVISION if cats else 0,
              'EntrancePoolPolicyRevision': _pool_policy_revision(world) if cats else 0,
              'EntranceRiverPathsRevision': _river_path_revision(world) if cats else 0,
              'EntranceMixedPoolMask': sum(MIXED_CATEGORY_BITS[category] for category in mixed),
              'DungeonDoorMixedOutside': int(bool(mixed_categories(world) & {'dungeon_doors', 'bosses'})),
              'DecoupleEntrances': 0,
              'ShuffleInteriorsEntrances': 2 if 'interiors' in cats else 0,
              'ShuffleThievesHideoutEntrances': int('interiors' in cats),
              'ShuffleDungeonsEntrances': 2 if 'dungeons' in cats else 0,
              'ShuffleGanonTowerEntrance': int('dungeons' in cats),
              'ShuffleBossEntrances': 2 if 'bosses' in cats else 0,
              'ShuffleGrottosEntrances': int(bool(cats)),
              'ShuffleOverworldEntrances': int(bool(cats & {'overworld', 'one_ways'})),
              'ShuffleOwlDrops': int('owls' in cats), 'ShuffleWarpSongs': int('warp_songs' in cats),
              'ShuffleOverworldSpawns': int(bool(cats & {'child_spawn', 'adult_spawn'})),
              'MixedEntrances': int(bool(mixed)), 'MixGrottos': int(bool(cats)),
              'ShuffleDungeonDoors': int('dungeon_doors' in cats)}
    mapping = getattr(world, '_er_mapping', {})
    if cats:
        expected = {e['id'] for e in _eligible(world)}
        # Blue warps are calculated by apply() and are in the runtime map even
        # when they were not a separately shuffled candidate source.
        if cats & {'bosses', 'dungeons'}:
            expected.update(e['id'] for e in CATALOG if e['category'] == 'blue_warps')
        try:
            MapIntegrity.validate_complete(mapping, expected)
        except ValueError as exc:
            raise OptionError('Cannot export unverified entrance map: ' + str(exc)) from exc
        result['EntranceMapRouteCount'] = len(mapping)
        result['EntranceMapFingerprint'] = MapIntegrity.fingerprint(mapping)
    result.update({'EntranceMap.'+str(k): v for k, v in mapping.items()})
    return result


def prune_obsolete_actions(world):
    if not enabled(world): return
    internal = {loc.name: loc for loc in world.get_locations()
                if loc.address is None and loc.locked and loc.name not in world.location_name_to_id
                and loc.item and loc.item.name != str(Events.GAME_COMPLETED)}
    if world.using_ut:
        disabled = world.passthrough['entrance_randomizer'].get('disabled_actions', [])
        if set(disabled) - internal.keys(): raise OptionError('Unknown entrance action manifest entry')
    else:
        state = world.multiworld.get_all_state(False)
        disabled = sorted(name for name, loc in internal.items() if not loc.can_reach(state))
    for name in disabled:
        loc = internal[name]
        loc.parent_region.locations.remove(loc)
    world._er_disabled_actions = disabled
